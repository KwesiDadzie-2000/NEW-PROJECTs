"use client";

import { useCallback, useEffect, useState } from "react";
import { ShieldCheck, ShieldX, AlertTriangle, PlayCircle, ScrollText, Download, DatabaseBackup } from "lucide-react";
import { PageHead, api, Badge, Busy, Notice, useToast } from "@/components/ui";

function saveBlob(content: string, name: string, type: string) {
  const url = URL.createObjectURL(new Blob([content], { type }));
  const a = document.createElement("a");
  a.href = url; a.download = name; a.click();
  URL.revokeObjectURL(url);
}

interface Check { id: string; name: string; severity: string; status: "PASS" | "FAIL" | "WARN"; detail: string; affected: string[] }
interface Trail { id: number; companyCode: string | null; actor: string; action: string; detail: string; createdAt: string }

export default function AuditPage() {
  const [checks, setChecks] = useState<Check[]>([]);
  const [trail, setTrail] = useState<Trail[]>([]);
  const [score, setScore] = useState<number | null>(null);
  const [counts, setCounts] = useState({ passed: 0, failed: 0, warnings: 0 });
  const [loading, setLoading] = useState(true);
  const [backingUp, setBackingUp] = useState(false);
  const toast = useToast();

  const exportTrail = () => {
    const rows = [["When", "Ledger", "Actor", "Action", "Detail"], ...trail.map((t) => [new Date(t.createdAt).toISOString(), t.companyCode || "", t.actor, t.action, t.detail])];
    saveBlob(rows.map((r) => r.map((c) => (/[",\n]/.test(String(c)) ? `"${String(c).replace(/"/g, '""')}"` : String(c))).join(",")).join("\n"), `audit-trail-${new Date().toISOString().slice(0, 10)}.csv`, "text/csv");
  };
  const backup = async () => {
    setBackingUp(true);
    const r = await fetch("/api/backup");
    setBackingUp(false);
    if (!r.ok) { const d = await r.json().catch(() => ({})); toast.err(d.error || "Backup requires the System Owner role."); return; }
    saveBlob(await r.text(), `bpz-fiscal-backup-${new Date().toISOString().slice(0, 10)}.json`, "application/json");
    toast.ok("Full practice backup downloaded (credentials excluded). Store it encrypted off-site.");
  };

  const run = useCallback(async () => {
    setLoading(true);
    const d = await api("/api/audit");
    if (d.success) { setChecks(d.checks); setScore(d.score); setCounts({ passed: d.passed, failed: d.failed, warnings: d.warnings }); setTrail(d.trail); }
    setLoading(false);
  }, []);
  useEffect(() => { run(); }, [run]);

  return (
    <div>
      <PageHead
        tcode="AUDIT · System Audit Station"
        title="Prove the books are clean."
        sub="Eleven integrity checks run against the live PostgreSQL ledgers — bank-code ownership, segregation of duties, OB52 period locks, parity, reversals and more."
        actions={<>
          <button className="btn btn-ghost" onClick={exportTrail} disabled={!trail.length}><Download className="w-4 h-4" /> Trail CSV</button>
          <button className="btn btn-ghost" onClick={backup} disabled={backingUp}><DatabaseBackup className="w-4 h-4" /> {backingUp ? "Exporting…" : "Backup (owner)"}</button>
          <button className="btn btn-gold" onClick={run} disabled={loading}><PlayCircle className="w-4 h-4" /> {loading ? "Auditing…" : "Re-run audit"}</button>
        </>}
      />
      {toast.node}

      {loading ? <Busy label="Running integrity checks against all client ledgers…" /> : (
        <>
          <div className="panel p-5 mb-4 rise flex flex-wrap items-center gap-6">
            <div className="relative w-28 h-28 shrink-0">
              <svg viewBox="0 0 100 100" className="w-28 h-28 -rotate-90">
                <circle cx="50" cy="50" r="42" fill="none" stroke="#e7ece6" strokeWidth="10" />
                <circle cx="50" cy="50" r="42" fill="none" stroke={score === 100 ? "#14684b" : "#d9a514"} strokeWidth="10" strokeLinecap="round"
                  strokeDasharray={`${(score || 0) * 2.64} 264`} style={{ transition: "stroke-dasharray 1s cubic-bezier(0.2,0.7,0.2,1)" }} />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="font-display font-black text-[24px]">{score}%</span>
                <span className="text-[9px] uppercase font-bold text-slate-400">integrity</span>
              </div>
            </div>
            <div className="flex-1 min-w-[240px]">
              <div className="font-display font-bold text-[18px]">{counts.failed === 0 ? "System healthy — safe for real client books." : `${counts.failed} critical finding(s) require attention.`}</div>
              <div className="flex gap-2 mt-2">
                <Badge tone="green">{counts.passed} passed</Badge>
                <Badge tone={counts.failed ? "red" : "slate"}>{counts.failed} failed</Badge>
                <Badge tone={counts.warnings ? "gold" : "slate"}>{counts.warnings} warnings</Badge>
              </div>
              <p className="text-[12.5px] text-slate-500 mt-2">The COMPANY_CODE_INTEGRITY and BANK_ROUTING checks directly verify the fix for the reported bank-code confusion.</p>
            </div>
          </div>

          {counts.failed > 0 && <div className="mb-4"><Notice kind="err">Failed checks list the affected documents below — reverse and re-post them through the Document Desk with the correct client ledger.</Notice></div>}

          <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-3">
            {checks.map((c, i) => (
              <div key={c.id} className={`panel panel-hover p-4 rise rise-${(i % 4) + 1} ${c.status === "FAIL" ? "!border-[#efc4bb]" : ""}`}>
                <div className="flex items-start justify-between gap-2">
                  <span className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${c.status === "PASS" ? "bg-leaf-soft text-leaf" : c.status === "WARN" ? "bg-gold-soft text-[#8a6a08]" : "bg-[#fbeae6] text-clay"}`}>
                    {c.status === "PASS" ? <ShieldCheck className="w-4 h-4" /> : c.status === "WARN" ? <AlertTriangle className="w-4 h-4" /> : <ShieldX className="w-4 h-4" />}
                  </span>
                  <Badge tone={c.severity === "CRITICAL" ? "red" : c.severity === "HIGH" ? "gold" : "slate"}>{c.severity}</Badge>
                </div>
                <div className="font-mono text-[10px] text-slate-400 mt-2">{c.id}</div>
                <div className="font-bold text-[13.5px] leading-snug mt-0.5">{c.name}</div>
                <p className="text-[12px] text-slate-600 mt-1 leading-relaxed">{c.detail}</p>
                {c.affected.length > 0 && <div className="mt-2 font-mono text-[10.5px] text-clay break-all">{c.affected.slice(0, 6).join(" · ")}</div>}
              </div>
            ))}
          </div>

          <div className="panel p-5 mt-4 rise rise-3">
            <h2 className="font-display font-bold text-[15px] flex items-center gap-2 mb-3"><ScrollText className="w-4 h-4 text-leaf" /> Audit trail (latest 30)</h2>
            <table className="ledger-table">
              <thead><tr><th>When</th><th>Ledger</th><th>Actor</th><th>Action</th><th>Detail</th></tr></thead>
              <tbody>
                {trail.map((t) => (
                  <tr key={t.id}>
                    <td className="font-mono text-[11px] whitespace-nowrap">{new Date(t.createdAt).toLocaleString("en-GB")}</td>
                    <td>{t.companyCode ? <Badge tone="blue">{t.companyCode}</Badge> : "—"}</td>
                    <td className="font-mono text-[11.5px]">{t.actor}</td>
                    <td><Badge tone="slate">{t.action}</Badge></td>
                    <td className="text-slate-600 text-[12px]">{t.detail}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  );
}