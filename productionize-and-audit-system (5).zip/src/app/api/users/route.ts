import { db } from "@/db";
import { users, auditLog } from "@/db/schema";
import { eq } from "drizzle-orm";
import { requireUser, hashPassword, ROLES, type Role } from "@/lib/server/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  const auth = await requireUser();
  if (auth instanceof Response) return auth;
  const rows = await db.select({ id: users.id, username: users.username, fullName: users.fullName, role: users.role, status: users.status, lastLogin: users.lastLogin, createdAt: users.createdAt }).from(users);
  return Response.json({ success: true, users: rows, roles: ROLES, canManage: auth.role === "SYSTEM_OWNER" });
}

export async function POST() {
  return Response.json({ success: false, error: "Use the users console." }, { status: 405 });
}

export async function PUT(req: Request) {
  const auth = await requireUser(["SYSTEM_OWNER"]);
  if (auth instanceof Response) return auth;
  const body = await req.json().catch(() => ({}));
  if (body.action === "CREATE") {
    const username = String(body.username || "").trim().toLowerCase();
    if (!/^[a-z0-9_.]{3,30}$/.test(username)) return Response.json({ success: false, error: "Username must be 3–30 chars (a-z, 0-9, _ .)." }, { status: 400 });
    if (!ROLES.includes(body.role)) return Response.json({ success: false, error: "Invalid role." }, { status: 400 });
    const pw = String(body.password || "");
    if (pw.length < 10 || !/[0-9]/.test(pw) || !/[A-Za-z]/.test(pw)) return Response.json({ success: false, error: "Password must be at least 10 characters with letters and numbers." }, { status: 400 });
    const [existing] = await db.select().from(users).where(eq(users.username, username));
    if (existing) return Response.json({ success: false, error: "Username already exists." }, { status: 400 });
    const [u] = await db.insert(users).values({ username, fullName: String(body.fullName || username), role: body.role as Role, passwordHash: hashPassword(pw) }).returning();
    await db.insert(auditLog).values({ actor: auth.username, action: "USER_CREATE", detail: `${username} (${body.role}) created by ${auth.username}` });
    return Response.json({ success: true, user: { id: u.id, username: u.username, role: u.role } });
  }
  if (body.action === "SET_STATUS" || body.action === "SET_ROLE" || body.action === "RESET_PASSWORD") {
    const [u] = await db.select().from(users).where(eq(users.id, Number(body.userId)));
    if (!u) return Response.json({ success: false, error: "User not found." }, { status: 404 });
    if (u.id === auth.id && body.action !== "RESET_PASSWORD") return Response.json({ success: false, error: "You cannot demote or deactivate your own account." }, { status: 400 });
    if (body.action === "SET_STATUS") {
      if (!["ACTIVE", "DISABLED"].includes(body.status)) return Response.json({ success: false, error: "Invalid status." }, { status: 400 });
      await db.update(users).set({ status: body.status }).where(eq(users.id, u.id));
    } else if (body.action === "SET_ROLE") {
      if (!ROLES.includes(body.role)) return Response.json({ success: false, error: "Invalid role." }, { status: 400 });
      await db.update(users).set({ role: body.role }).where(eq(users.id, u.id));
    } else {
      const pw = String(body.password || "");
      if (pw.length < 10 || !/[0-9]/.test(pw) || !/[A-Za-z]/.test(pw)) return Response.json({ success: false, error: "Password must be at least 10 characters with letters and numbers." }, { status: 400 });
      await db.update(users).set({ passwordHash: hashPassword(pw), failedAttempts: 0, lockedUntil: null }).where(eq(users.id, u.id));
    }
    await db.insert(auditLog).values({ actor: auth.username, action: `USER_${body.action}`, detail: `${u.username} updated by ${auth.username}` });
    return Response.json({ success: true });
  }
  return Response.json({ success: false, error: "Unknown action." }, { status: 400 });
}