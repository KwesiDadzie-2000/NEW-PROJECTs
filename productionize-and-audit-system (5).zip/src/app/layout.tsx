import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Archivo, Public_Sans, IBM_Plex_Mono } from "next/font/google";
import "./globals.css";
import Shell from "@/components/shell";

const archivo = Archivo({ subsets: ["latin"], variable: "--font-archivo", weight: ["500", "600", "700", "800", "900"] });
const publicSans = Public_Sans({ subsets: ["latin"], variable: "--font-public" });
const plexMono = IBM_Plex_Mono({ subsets: ["latin"], variable: "--font-plexmono", weight: ["400", "500", "600", "700"] });

export const metadata: Metadata = {
  title: "BPZ Fiscal Ledger — Client Books, Ghana Statutory Engine",
  description: "Production practice-management ledger for real client books: document intelligence, double-entry posting, Ghana VAT Act 1151, PAYE Act 1178, system audit and cross-sector regression suite.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className={`${archivo.variable} ${publicSans.variable} ${plexMono.variable}`}>
      <body className="antialiased">
        <Shell>{children}</Shell>
      </body>
    </html>
  );
}