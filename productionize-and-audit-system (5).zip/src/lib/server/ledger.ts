import { db } from "@/db";
import { accounts, journalEntries, journalLines, auditLog, clients, periods } from "@/db/schema";
import { and, eq, sql } from "drizzle-orm";
import { r2 } from "./ghana-tax";
import { getClientByCompany } from "./coa";

export interface PostLine { accountCode: string; side: "D" | "C"; amount: number; itemText?: string }
export interface PostInput {
  companyCode: string; docType: string; postingDate: string; headerText: string;
  reference?: string; lines: PostLine[]; source?: string; createdBy?: string;
}

export const OPEN_FISCAL_YEAR = 2026; // FY2025 and earlier are closed (OB52)

// ---------------- OB52 posting period control ----------------
export async function getPeriods(companyCode: string, fiscalYear = OPEN_FISCAL_YEAR) {
  const rows = await db.select().from(periods).where(and(eq(periods.companyCode, companyCode), eq(periods.fiscalYear, fiscalYear)));
  const map = new Map(rows.map((r) => [r.period, r]));
  return Array.from({ length: 12 }, (_, i) => {
    const p = i + 1;
    const row = map.get(p);
    return { period: p, fiscalYear, status: row?.status || "OPEN", closedBy: row?.closedBy || "", closedAt: row?.closedAt || null };
  });
}

async function periodStatus(companyCode: string, dateStr: string): Promise<string> {
  const fy = Number(dateStr.slice(0, 4));
  const p = Number(dateStr.slice(5, 7));
  const [row] = await db.select().from(periods).where(and(eq(periods.companyCode, companyCode), eq(periods.fiscalYear, fy), eq(periods.period, p)));
  return row?.status || "OPEN";
}

export async function setPeriodStatus(companyCode: string, fiscalYear: number, period: number, status: "OPEN" | "CLOSED", actor: string) {
  const client = await getClientByCompany(companyCode);
  if (!client) return { ok: false as const, error: "Unknown client ledger." };
  if (fiscalYear !== OPEN_FISCAL_YEAR || period < 1 || period > 12) return { ok: false as const, error: `Only FY${OPEN_FISCAL_YEAR} periods 1–12 can be managed.` };
  const existing = await db.select().from(periods).where(and(eq(periods.companyCode, companyCode), eq(periods.fiscalYear, fiscalYear), eq(periods.period, period)));
  if (existing.length) {
    await db.update(periods).set({ status, closedBy: actor, closedAt: status === "CLOSED" ? new Date() : null }).where(eq(periods.id, existing[0].id));
  } else {
    await db.insert(periods).values({ companyCode, fiscalYear, period, status, closedBy: actor, closedAt: status === "CLOSED" ? new Date() : null });
  }
  await db.insert(auditLog).values({ companyCode, actor, action: status === "CLOSED" ? "PERIOD_CLOSE" : "PERIOD_REOPEN", detail: `FY${fiscalYear}/${String(period).padStart(2, "0")} → ${status} (OB52)` });
  return { ok: true as const };
}

// ---------------- Atomic posting engine ----------------
export async function postEntry(input: PostInput): Promise<{ ok: true; entry: typeof journalEntries.$inferSelect; docNumber: string } | { ok: false; error: string }> {
  const { companyCode, postingDate, lines } = input;
  const client = await getClientByCompany(companyCode);
  if (!client) return { ok: false, error: `Company code "${companyCode}" is not a registered client ledger. Postings must use the client's own company code.` };
  if (client.status === "SUSPENDED") return { ok: false, error: `Client ${companyCode} is suspended — postings blocked.` };
  if (!/^\d{4}-\d{2}-\d{2}$/.test(postingDate)) return { ok: false, error: "Posting date must be YYYY-MM-DD." };
  const year = Number(postingDate.slice(0, 4));
  if (year < OPEN_FISCAL_YEAR) return { ok: false, error: `Posting date ${postingDate} falls in CLOSED fiscal year ${year} (OB52). Open periods start FY${OPEN_FISCAL_YEAR}.` };
  if (year > OPEN_FISCAL_YEAR + 1) return { ok: false, error: `Fiscal year ${year} is not yet opened for ${companyCode}.` };
  if ((await periodStatus(companyCode, postingDate)) === "CLOSED") {
    return { ok: false, error: `Period ${postingDate.slice(0, 7)} is CLOSED for ${companyCode} (OB52). A controller must reopen it before posting.` };
  }
  if (!lines || lines.length < 2) return { ok: false, error: "A document needs at least two line items (double entry)." };

  const coa = await db.select().from(accounts).where(eq(accounts.companyCode, companyCode));
  const valid = new Set(coa.map((a) => a.code));
  for (const l of lines) {
    if (!valid.has(l.accountCode)) return { ok: false, error: `Account ${l.accountCode} does not exist in ${companyCode}'s chart of accounts.` };
    if (l.side !== "D" && l.side !== "C") return { ok: false, error: `Invalid debit/credit indicator on ${l.accountCode}.` };
    if (!(Number(l.amount) > 0)) return { ok: false, error: `Line amount on ${l.accountCode} must be greater than zero.` };
  }
  const totalD = r2(lines.filter((l) => l.side === "D").reduce((t, l) => t + Number(l.amount), 0));
  const totalC = r2(lines.filter((l) => l.side === "C").reduce((t, l) => t + Number(l.amount), 0));
  if (Math.abs(totalD - totalC) > 0.005) return { ok: false, error: `Document does not balance: Dr ${totalD.toFixed(2)} vs Cr ${totalC.toFixed(2)}.` };

  // Atomic: header + lines + audit trail commit together or not at all.
  // Race-safe numbering: max(doc)+1 inside the transaction, retry on unique collision.
  for (let attempt = 0; attempt < 5; attempt++) {
    try {
      const entry = await db.transaction(async (tx) => {
        const [{ next }] = await tx
          .select({ next: sql<number>`coalesce(max(${journalEntries.docNumber}::bigint), 1000000000) + 1` })
          .from(journalEntries)
          .where(eq(journalEntries.companyCode, companyCode));
        const docNumber = String(next);
        const [e] = await tx.insert(journalEntries).values({
          companyCode, docNumber, docType: input.docType, postingDate,
          headerText: input.headerText, reference: input.reference || "",
          totalDebit: totalD.toFixed(2), totalCredit: totalC.toFixed(2),
          source: input.source || "MANUAL", createdBy: input.createdBy || "system",
        }).returning();
        await tx.insert(journalLines).values(lines.map((l) => ({
          entryId: e.id, accountCode: l.accountCode, side: l.side, amount: r2(Number(l.amount)).toFixed(2), itemText: l.itemText || "",
        })));
        await tx.insert(auditLog).values({ companyCode, actor: input.createdBy || "system", action: "POST_DOCUMENT", detail: `${docNumber} ${input.docType} ${input.headerText} (${totalD.toFixed(2)})` });
        return e;
      });
      return { ok: true, entry, docNumber: entry.docNumber };
    } catch (err) {
      const code = (err as { code?: string }).code;
      if (code === "23505" && attempt < 4) continue; // concurrent numbering collision — retry
      throw err;
    }
  }
  return { ok: false, error: "Could not allocate a document number after 5 attempts — retry." };
}

export async function reverseEntry(entryId: number, reason: string, actor = "system") {
  const [orig] = await db.select().from(journalEntries).where(eq(journalEntries.id, entryId));
  if (!orig) return { ok: false as const, error: "Document not found." };
  if (orig.status === "REVERSED") return { ok: false as const, error: `Document ${orig.docNumber} is already reversed.` };
  // Segregation of duties: the preparer can never reverse their own document.
  if (orig.createdBy === actor) {
    return { ok: false as const, error: `Segregation of duties: ${actor} prepared document ${orig.docNumber} and cannot reverse it. A different controller must perform the reversal.` };
  }
  const lines = await db.select().from(journalLines).where(eq(journalLines.entryId, entryId));
  const res = await postEntry({
    companyCode: orig.companyCode, docType: "AB", postingDate: orig.postingDate,
    headerText: `Reversal of ${orig.docNumber}: ${reason}`, reference: `REV-${orig.docNumber}`,
    lines: lines.map((l) => ({ accountCode: l.accountCode, side: l.side === "D" ? "C" as const : "D" as const, amount: Number(l.amount), itemText: `Reversal — ${l.itemText}` })),
    source: orig.source, createdBy: actor,
  });
  if (!res.ok) return res;
  await db.update(journalEntries).set({ status: "REVERSED" }).where(eq(journalEntries.id, entryId));
  await db.update(journalEntries).set({ reversalOf: entryId }).where(eq(journalEntries.id, res.entry.id));
  await db.insert(auditLog).values({ companyCode: orig.companyCode, actor, action: "REVERSE_DOCUMENT", detail: `${orig.docNumber} (by ${orig.createdBy}) reversed by ${res.docNumber} — ${reason}` });
  return { ok: true as const, docNumber: res.docNumber };
}

export async function trialBalance(companyCode: string) {
  const coa = await db.select().from(accounts).where(eq(accounts.companyCode, companyCode));
  const rows = await db
    .select({
      accountCode: journalLines.accountCode,
      debit: sql<string>`coalesce(sum(case when ${journalLines.side} = 'D' then ${journalLines.amount}::numeric else 0 end), 0)`,
      credit: sql<string>`coalesce(sum(case when ${journalLines.side} = 'C' then ${journalLines.amount}::numeric else 0 end), 0)`,
    })
    .from(journalLines)
    .innerJoin(journalEntries, eq(journalLines.entryId, journalEntries.id))
    .where(eq(journalEntries.companyCode, companyCode))
    .groupBy(journalLines.accountCode);
  const map = new Map(rows.map((r) => [r.accountCode, r]));
  const out = coa
    .map((a) => {
      const r = map.get(a.code);
      const d = r2(Number(r?.debit || 0));
      const c = r2(Number(r?.credit || 0));
      const balance = r2(d - c);
      return { code: a.code, name: a.name, type: a.type, debit: d, credit: c, balance, netDebit: Math.max(0, balance), netCredit: Math.max(0, -balance) };
    })
    .sort((a, b) => a.code.localeCompare(b.code));
  const totalDebit = r2(out.reduce((t, r) => t + r.netDebit, 0));
  const totalCredit = r2(out.reduce((t, r) => t + r.netCredit, 0));
  const revenue = r2(out.filter((r) => r.type === "REVENUE").reduce((t, r) => t - r.balance, 0));
  const expense = r2(out.filter((r) => r.type === "EXPENSE").reduce((t, r) => t + r.balance, 0));
  return { rows: out, totalDebit, totalCredit, isBalanced: Math.abs(totalDebit - totalCredit) < 0.01, profit: r2(revenue - expense), revenue, expense };
}

export async function accountBalance(companyCode: string, accountCode: string) {
  const [row] = await db
    .select({ balance: sql<string>`coalesce(sum(case when ${journalLines.side} = 'D' then ${journalLines.amount}::numeric else -${journalLines.amount}::numeric end), 0)` })
    .from(journalLines)
    .innerJoin(journalEntries, eq(journalLines.entryId, journalEntries.id))
    .where(and(eq(journalEntries.companyCode, companyCode), eq(journalLines.accountCode, accountCode)));
  return r2(Number(row?.balance || 0));
}

export async function listClients(includeTest = false) {
  const all = await db.select().from(clients);
  return includeTest ? all : all.filter((c) => !c.isTest);
}