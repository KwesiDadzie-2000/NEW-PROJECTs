"use client";

import { useCallback, useEffect, useState } from "react";
import { Plus, Landmark, ReceiptText, Upload, X, Banknote, Link2 } from "lucide-react";
import { PageHead, useClients, useToast, api, fmt, num, Badge, ClientPicker, Busy, Empty } from "@/components/ui";

interface Invoice { id: number; invoiceNo: string; kind: string; partner: string; invoiceDate: string; dueDate: string; netAmount: string; vatAmount: string; nhilAmount: string; getfundAmount: string; whtRate: string; whtAmount: string; grossTotal: string; amountPaid: string; balance: string; status: string; description: string }
interface BankAcct { id: number; bankName: string; sortCode: string; accountNumber: string; accountName: string; glAccount: string; ledgerBalance: number }
interface StmtLine { id: number; bankAccountId: number; lineDate: string; description: string; debit: string; credit: string; suggestedAccount: string; status: string }
interface WhtRate { code: string; rate: number; label: string }
interface Account { code: string; name: string }

export default function OperationsPage() {
  const { clients } = useClients();
  const toast = useToast();
  const [cc, setCc] = useState("");
  const [tab, setTab] = useState<"invoices" | "banking">("invoices");
  const [invs, setInvs] = useState<Invoice[]>([]);
  const [whtRates, setWhtRates] = useState<WhtRate[]>([]);
  const [accts, setAccts] = useState<BankAcct[]>([]);
  const [stmt, setStmt] = useState<StmtLine[]>([]);
  const [coa, setCoa] = useState<Account[]>([]);
  const [loading, setLoading] = useState(false);
  const [invModal, setInvModal] = useState(false);
  const [payModal, setPayModal] = useState<Invoice | null>(null);
  const [importText, setImportText] = useState("2026-02-18,E-VAT SALES RECEIPT — customer settlement,0,12500\n2026-02-19,BANK CHARGES + COT,180,0\n2026-02-19,GRA VAT REMITTANCE,2000,0");
  const [selAcct, setSelAcct] = useState<number | null>(null);
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({ kind: "AR", partner: "", invoiceDate: "2026-02-15", dueDate: "2026-03-15", netAmount: "", treatment: "STANDARD", whtRate: "7.5", description: "" });
  const [pay, setPay] = useState({ amount: "", paymentDate: "2026-02-20", applyWht: true, withholdVat: false });
  const [settle, setSettle] = useState<{ line: StmtLine; invoiceId: string } | null>(null);
  const [overrideAcct, setOverrideAcct] = useState<Record<number, string>>({});

  useEffect(() => { if (!cc && clients.length) setCc(clients[0].companyCode); }, [clients, cc]);

  const load = useCallback(async () => {
    if (!cc) return;
    setLoading(true);
    const [i, b, j] = await Promise.all([api(`/api/invoices?companyCode=${cc}`), api(`/api/banking?companyCode=${cc}`), api(`/api/journal?companyCode=${cc}`)]);
    if (i.success) { setInvs(i.invoices); setWhtRates(i.whtRates); }
    if (b.success) { setAccts(b.accounts); setStmt(b.lines); if (!selAcct && b.accounts.length) setSelAcct(b.accounts[0].id); }
    if (j.success) setCoa(j.accounts);
    setLoading(false);
  }, [cc, selAcct]);
  useEffect(() => { load(); }, [load]);

  const createInv = async (e: React.FormEvent) => {
    e.preventDefault(); setBusy(true);
    const d = await api("/api/invoices", "POST", { ...form, companyCode: cc, netAmount: Number(form.netAmount), whtRate: Number(form.whtRate) });
    setBusy(false);
    if (d.success) { toast.ok(`${d.invoice.invoiceNo} posted as document ${d.docNumber}.`); setInvModal(false); load(); } else toast.err(d.error);
  };
  const doPay = async (e: React.FormEvent) => {
    e.preventDefault(); if (!payModal) return; setBusy(true);
    const d = await api("/api/invoices", "POST", { action: "PAY", invoiceId: payModal.id, amount: Number(pay.amount), paymentDate: pay.paymentDate, applyWht: pay.applyWht, withholdVat: pay.withholdVat });
    setBusy(false);
    if (d.success) { toast.ok(`Applied ${fmt(d.applied)} — cash ${fmt(d.cash)}, WHT ${fmt(d.whtNow)}${d.vatWNow ? `, VAT WHT ${fmt(d.vatWNow)}` : ""}. Status ${d.status}.`); setPayModal(null); load(); } else toast.err(d.error);
  };
  const doImport = async () => {
    if (!selAcct) return;
    const rows = importText.split("\n").map((l) => l.trim()).filter(Boolean).map((l) => {
      const parts = l.split(",");
      const credit = Number(parts.pop() || 0); const debit = Number(parts.pop() || 0);
      return { date: parts.shift()?.trim() || "", description: parts.join(",").trim(), debit, credit };
    });
    setBusy(true);
    const d = await api("/api/banking", "POST", { action: "IMPORT", bankAccountId: selAcct, rows });
    setBusy(false);
    if (d.success) { toast.ok(`${d.count} line(s) imported → routed to client ledger ${d.companyCode} (the account owner, never the bank).`); load(); } else toast.err(d.error);
  };
  const postLine = async (line: StmtLine) => {
    const d = await api("/api/banking", "POST", { action: "POST_LINE", lineId: line.id, overrideAccount: overrideAcct[line.id] || undefined });
    if (d.success) { toast.ok(`Statement line posted — document ${d.docNumber}.`); load(); } else toast.err(d.error);
  };
  const doSettle = async () => {
    if (!settle) return; setBusy(true);
    const d = await api("/api/banking", "POST", { action: "SETTLE", lineId: settle.line.id, invoiceId: Number(settle.invoiceId) });
    setBusy(false);
    if (d.success) { toast.ok(`Invoice settled from bank line — ${d.status}.`); setSettle(null); load(); } else toast.err(d.error);
  };

  const client = clients.find((c) => c.companyCode === cc);
  const previewNet = Number(form.netAmount || 0);
  const previewLevies = form.treatment === "STANDARD" ? previewNet * 0.2 : 0;
  const acctLines = stmt.filter((l) => l.bankAccountId === selAcct);

  return (
    <div>
      {toast.node}
      <PageHead
        tcode="F-28 / FF67 · Billing & Banking"
        title={client ? client.businessName : "Billing & Banking"}
        sub="AR/AP invoices carry the Act 1151 levy split, income WHT and 7% VAT withholding. Bank statements always post into the account owner's ledger."
        actions={<ClientPicker clients={clients} value={cc} onChange={(v) => { setCc(v); setSelAcct(null); }} />}
      />

      <div className="flex gap-2 mb-4">
        <button onClick={() => setTab("invoices")} className={`btn ${tab === "invoices" ? "btn-gold" : "btn-ghost"}`}><ReceiptText className="w-4 h-4" /> Invoices ({invs.length})</button>
        <button onClick={() => setTab("banking")} className={`btn ${tab === "banking" ? "btn-gold" : "btn-ghost"}`}><Landmark className="w-4 h-4" /> Bank statements</button>
        {tab === "invoices" && cc && <button onClick={() => setInvModal(true)} className="btn btn-primary ml-auto"><Plus className="w-4 h-4" /> New invoice</button>}
      </div>

      {!cc ? <Empty title="Select a client ledger" /> : loading ? <Busy /> : tab === "invoices" ? (
        <div className="panel p-5 rise">
          <div className="overflow-x-auto">
            <table className="ledger-table">
              <thead><tr><th>Invoice</th><th>Kind</th><th>Partner</th><th>Date → Due</th><th className="!text-right">Net</th><th className="!text-right">Levies</th><th className="!text-right">WHT</th><th className="!text-right">Gross</th><th className="!text-right">Balance</th><th>Status</th><th></th></tr></thead>
              <tbody>
                {invs.length === 0 && <tr><td colSpan={11} className="text-center py-8 text-slate-500">No invoices yet — create the first AR or AP invoice.</td></tr>}
                {invs.map((i) => (
                  <tr key={i.id}>
                    <td className="font-mono font-semibold">{i.invoiceNo}<div className="text-[10.5px] text-slate-400 max-w-[160px] truncate">{i.description}</div></td>
                    <td><Badge tone={i.kind === "AR" ? "green" : "gold"}>{i.kind}</Badge></td>
                    <td className="max-w-[160px] truncate">{i.partner}</td>
                    <td className="font-mono text-[11.5px]">{i.invoiceDate}<br />→ {i.dueDate}</td>
                    <td className="text-right font-mono tnum">{num(i.netAmount)}</td>
                    <td className="text-right font-mono tnum">{num(Number(i.vatAmount) + Number(i.nhilAmount) + Number(i.getfundAmount))}</td>
                    <td className="text-right font-mono tnum">{num(i.whtAmount)}<div className="text-[10px] text-slate-400">{i.whtRate}%</div></td>
                    <td className="text-right font-mono tnum font-semibold">{num(i.grossTotal)}</td>
                    <td className="text-right font-mono tnum font-bold">{num(i.balance)}</td>
                    <td><Badge tone={i.status === "PAID" ? "green" : i.status === "PARTIALLY_PAID" ? "gold" : "slate"}>{i.status.replace("_", " ")}</Badge></td>
                    <td>{Number(i.balance) > 0.01 && <button className="btn btn-primary !px-2.5 !py-1 !text-[11.5px]" onClick={() => { setPayModal(i); setPay({ amount: i.balance, paymentDate: "2026-02-20", applyWht: Number(i.whtRate) > 0, withholdVat: false }); }}><Banknote className="w-3.5 h-3.5" /> {i.kind === "AR" ? "Receive" : "Pay"}</button>}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="grid lg:grid-cols-5 gap-4">
          <div className="lg:col-span-2 space-y-3">
            {accts.map((a) => (
              <button key={a.id} onClick={() => setSelAcct(a.id)} className={`panel panel-hover p-4 w-full text-left rise ${selAcct === a.id ? "!border-leaf ring-2 ring-leaf/20" : ""}`}>
                <div className="flex justify-between items-start">
                  <div>
                    <div className="font-bold text-[14px]">{a.bankName}</div>
                    <div className="font-mono text-[11.5px] text-slate-500 mt-0.5">A/C {a.accountNumber} · sort {a.sortCode || "—"}</div>
                    <div className="text-[11px] mt-1"><Badge tone="blue">owner {cc}</Badge> <Badge tone="slate">GL {a.glAccount}</Badge></div>
                  </div>
                  <div className="text-right">
                    <div className="font-mono font-bold tnum text-[15px]">{fmt(a.ledgerBalance, client?.currency)}</div>
                    <div className="text-[10px] uppercase font-bold text-slate-400">ledger balance</div>
                  </div>
                </div>
              </button>
            ))}
            <div className="panel p-4 rise rise-2">
              <div className="font-bold text-[13px] flex items-center gap-2 mb-2"><Upload className="w-4 h-4 text-leaf" /> Import statement (CSV: date, description, debit, credit)</div>
              <textarea className="field font-mono !text-[11.5px]" rows={5} value={importText} onChange={(e) => setImportText(e.target.value)} />
              <button className="btn btn-primary mt-2 w-full justify-center" onClick={doImport} disabled={busy || !selAcct}>{busy ? "Importing…" : "Import & analyse lines"}</button>
              <p className="text-[11px] text-slate-500 mt-2">Routing rule: the ledger is taken from the <b>account owner</b> ({cc}); the bank's own codes never become the company code.</p>
            </div>
          </div>
          <div className="lg:col-span-3 panel p-5 rise rise-1">
            <h3 className="font-display font-bold text-[15px] mb-3">Statement lines</h3>
            {acctLines.length === 0 ? <p className="text-[13px] text-slate-500 py-6 text-center">No statement lines — import a statement to begin reconciliation.</p> : (
              <table className="ledger-table">
                <thead><tr><th>Date</th><th>Description</th><th className="!text-right">Out</th><th className="!text-right">In</th><th>Contra account</th><th>Status / action</th></tr></thead>
                <tbody>
                  {acctLines.map((l) => (
                    <tr key={l.id}>
                      <td className="font-mono text-[11.5px]">{l.lineDate}</td>
                      <td className="max-w-[200px]"><div className="truncate">{l.description}</div></td>
                      <td className="text-right font-mono tnum">{Number(l.debit) > 0 ? num(l.debit) : ""}</td>
                      <td className="text-right font-mono tnum text-leaf font-semibold">{Number(l.credit) > 0 ? num(l.credit) : ""}</td>
                      <td>
                        {l.status === "UNMATCHED" ? (
                          <select className="field !py-1 !text-[11.5px] !w-[190px]" value={overrideAcct[l.id] || l.suggestedAccount} onChange={(e) => setOverrideAcct({ ...overrideAcct, [l.id]: e.target.value })}>
                            {coa.map((a) => <option key={a.code} value={a.code}>{a.code} — {a.name}</option>)}
                          </select>
                        ) : <span className="font-mono text-[11.5px]">{l.suggestedAccount}</span>}
                      </td>
                      <td>
                        {l.status === "POSTED" ? <Badge tone="green">POSTED</Badge> : (
                          <div className="flex gap-1">
                            <button className="btn btn-primary !px-2 !py-1 !text-[11px]" onClick={() => postLine(l)}>Post</button>
                            {Number(l.credit) > 0 && <button className="btn btn-ghost !px-2 !py-1 !text-[11px]" onClick={() => setSettle({ line: l, invoiceId: "" })}><Link2 className="w-3 h-3" /> Settle AR</button>}
                          </div>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>
      )}

      {invModal && (
        <div className="fixed inset-0 z-50 bg-ink/60 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setInvModal(false)}>
          <div className="bg-white rounded-xl max-w-xl w-full p-6 shadow-2xl rise max-h-[92vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <div className="flex justify-between items-center"><h3 className="font-display font-black text-[18px]">New invoice — {cc}</h3><button onClick={() => setInvModal(false)} className="text-slate-400 hover:text-ink"><X className="w-5 h-5" /></button></div>
            <form onSubmit={createInv} className="grid grid-cols-2 gap-3 mt-4">
              <div><label className="flabel">Type</label><select className="field" value={form.kind} onChange={(e) => setForm({ ...form, kind: e.target.value })}><option value="AR">AR — customer invoice</option><option value="AP">AP — supplier bill</option></select></div>
              <div><label className="flabel">Partner *</label><input className="field" required value={form.partner} onChange={(e) => setForm({ ...form, partner: e.target.value })} /></div>
              <div><label className="flabel">Invoice date</label><input className="field" type="date" required value={form.invoiceDate} onChange={(e) => setForm({ ...form, invoiceDate: e.target.value })} /></div>
              <div><label className="flabel">Due date</label><input className="field" type="date" value={form.dueDate} onChange={(e) => setForm({ ...form, dueDate: e.target.value })} /></div>
              <div><label className="flabel">Net amount (excl. VAT) *</label><input className="field font-mono" type="number" step="0.01" min="0.01" required value={form.netAmount} onChange={(e) => setForm({ ...form, netAmount: e.target.value })} /></div>
              <div><label className="flabel">VAT treatment</label><select className="field" value={form.treatment} onChange={(e) => setForm({ ...form, treatment: e.target.value })}><option value="STANDARD">Standard 20% (Act 1151)</option><option value="ZERO">Zero-rated</option><option value="EXEMPT">Exempt</option></select></div>
              <div className="col-span-2"><label className="flabel">Income WHT</label><select className="field" value={form.whtRate} onChange={(e) => setForm({ ...form, whtRate: e.target.value })}>{whtRates.map((w) => <option key={w.code} value={w.rate}>{w.label}</option>)}</select></div>
              <div className="col-span-2"><label className="flabel">Description</label><input className="field" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></div>
              <div className="col-span-2 bg-[#f6f8f5] rounded-lg p-3 grid grid-cols-4 gap-2 text-center">
                {[["Net", previewNet], ["VAT+levies", previewLevies], ["WHT", previewNet * Number(form.whtRate) / 100], ["Gross", previewNet + previewLevies]].map(([l, v]) => (
                  <div key={l as string}><div className="text-[10px] uppercase font-bold text-slate-500">{l}</div><div className="font-mono font-bold text-[13px] tnum">{num(v as number)}</div></div>
                ))}
              </div>
              <div className="col-span-2 flex justify-end gap-2"><button type="button" className="btn btn-ghost" onClick={() => setInvModal(false)}>Cancel</button><button className="btn btn-primary" disabled={busy}>{busy ? "Posting…" : "Post invoice"}</button></div>
            </form>
          </div>
        </div>
      )}

      {payModal && (
        <div className="fixed inset-0 z-50 bg-ink/60 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setPayModal(null)}>
          <div className="bg-white rounded-xl max-w-md w-full p-6 shadow-2xl rise" onClick={(e) => e.stopPropagation()}>
            <div className="flex justify-between items-center"><h3 className="font-display font-black text-[17px]">{payModal.kind === "AR" ? "Receive payment" : "Pay supplier"} — {payModal.invoiceNo}</h3><button onClick={() => setPayModal(null)} className="text-slate-400 hover:text-ink"><X className="w-5 h-5" /></button></div>
            <p className="text-[12.5px] text-slate-500 mt-1">{payModal.partner} · balance <b className="font-mono">{fmt(payModal.balance)}</b></p>
            <form onSubmit={doPay} className="space-y-3 mt-4">
              <div className="grid grid-cols-2 gap-3">
                <div><label className="flabel">Amount to apply</label><input className="field font-mono" type="number" step="0.01" min="0.01" required value={pay.amount} onChange={(e) => setPay({ ...pay, amount: e.target.value })} /></div>
                <div><label className="flabel">Payment date</label><input className="field" type="date" required value={pay.paymentDate} onChange={(e) => setPay({ ...pay, paymentDate: e.target.value })} /></div>
              </div>
              <label className="flex items-center gap-2 text-[13px] font-semibold"><input type="checkbox" checked={pay.applyWht} onChange={(e) => setPay({ ...pay, applyWht: e.target.checked })} /> Apply income WHT ({payModal.whtRate}%) {payModal.kind === "AR" ? "— customer withholds, we book tax credit" : "— we withhold for GRA"}</label>
              <label className="flex items-center gap-2 text-[13px] font-semibold"><input type="checkbox" checked={pay.withholdVat} onChange={(e) => setPay({ ...pay, withholdVat: e.target.checked })} /> 7% VAT withholding applies (GRA-appointed agent)</label>
              <button className="btn btn-primary w-full justify-center" disabled={busy}>{busy ? "Processing…" : "Post payment"}</button>
            </form>
          </div>
        </div>
      )}

      {settle && (
        <div className="fixed inset-0 z-50 bg-ink/60 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setSettle(null)}>
          <div className="bg-white rounded-xl max-w-md w-full p-6 shadow-2xl rise" onClick={(e) => e.stopPropagation()}>
            <h3 className="font-display font-black text-[17px]">Settle AR from bank line</h3>
            <p className="text-[12.5px] text-slate-500 mt-1">{settle.line.description} · inflow <b className="font-mono">{fmt(settle.line.credit)}</b></p>
            <label className="flabel mt-4">Open AR invoice</label>
            <select className="field" value={settle.invoiceId} onChange={(e) => setSettle({ ...settle, invoiceId: e.target.value })}>
              <option value="">Select invoice…</option>
              {invs.filter((i) => i.kind === "AR" && Number(i.balance) > 0.01).map((i) => <option key={i.id} value={i.id}>{i.invoiceNo} — {i.partner} (bal {num(i.balance)})</option>)}
            </select>
            <div className="flex justify-end gap-2 mt-4">
              <button className="btn btn-ghost" onClick={() => setSettle(null)}>Cancel</button>
              <button className="btn btn-primary" onClick={doSettle} disabled={busy || !settle.invoiceId}>{busy ? "Settling…" : "Settle invoice"}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}