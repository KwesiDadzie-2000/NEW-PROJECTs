import { db } from "@/db";
import { accounts, bankAccounts, clients, auditLog } from "@/db/schema";
import { eq } from "drizzle-orm";

// Standard BPZ operational chart of accounts (INT1) — one copy per client company code.
export const STANDARD_COA: Array<{ code: string; name: string; type: string; isBank?: boolean }> = [
  { code: "100200", name: "Bank — Main Operating", type: "ASSET", isBank: true },
  { code: "100300", name: "Cash on Hand / Petty Cash", type: "ASSET" },
  { code: "110000", name: "Trade Receivables (AR Control)", type: "ASSET" },
  { code: "115000", name: "WHT Receivable (Tax Credits)", type: "ASSET" },
  { code: "120000", name: "Input VAT Recoverable", type: "ASSET" },
  { code: "130000", name: "Inventory / Stock", type: "ASSET" },
  { code: "140000", name: "Work In Progress / Contracts", type: "ASSET" },
  { code: "150000", name: "Property, Plant & Equipment", type: "ASSET" },
  { code: "151000", name: "Accumulated Depreciation", type: "ASSET" },
  { code: "200000", name: "Trade Payables (AP Control)", type: "LIABILITY" },
  { code: "210000", name: "Retention Payable", type: "LIABILITY" },
  { code: "220000", name: "Output VAT / Levies Payable", type: "LIABILITY" },
  { code: "225000", name: "WHT Payable (GRA)", type: "LIABILITY" },
  { code: "226000", name: "VAT Withheld Payable (7%)", type: "LIABILITY" },
  { code: "230000", name: "PAYE Payable (GRA)", type: "LIABILITY" },
  { code: "231000", name: "SSNIT Payable (Tier 1+2)", type: "LIABILITY" },
  { code: "240000", name: "Royalties Payable", type: "LIABILITY" },
  { code: "250000", name: "Loans / Borrowings", type: "LIABILITY" },
  { code: "300000", name: "Share Capital", type: "EQUITY" },
  { code: "310000", name: "Retained Earnings", type: "EQUITY" },
  { code: "400000", name: "Revenue — Principal Activity", type: "REVENUE" },
  { code: "410000", name: "Other Operating Income", type: "REVENUE" },
  { code: "500000", name: "Cost of Sales / Direct Costs", type: "EXPENSE" },
  { code: "610000", name: "Salaries & Wages", type: "EXPENSE" },
  { code: "611000", name: "Employer SSNIT Contribution", type: "EXPENSE" },
  { code: "620000", name: "Administrative Expenses", type: "EXPENSE" },
  { code: "630000", name: "Bank Charges & COT", type: "EXPENSE" },
  { code: "640000", name: "Depreciation Expense", type: "EXPENSE" },
  { code: "650000", name: "Royalty Expense", type: "EXPENSE" },
];

export const SECTORS: Array<{ code: string; name: string; icon: string; vat: string; wht: string }> = [
  { code: "AGRI", name: "Agriculture & Agribusiness", icon: "🌾", vat: "Basic foodstuffs exempt; exports zero-rated", wht: "3% produce · 7.5% logistics" },
  { code: "MINING", name: "Mining & Minerals", icon: "⛏️", vat: "Exports zero-rated; imports recoverable", wht: "5% works · 10% royalties · 20% NR" },
  { code: "OILGAS", name: "Oil, Gas & Energy", icon: "🛢️", vat: "Upstream zero-rated; downstream standard", wht: "20% NR services · 7.5% contractors" },
  { code: "MANUF", name: "Manufacturing", icon: "🏭", vat: "Standard-rated; input VAT on materials", wht: "3% goods · 7.5% maintenance" },
  { code: "CONST", name: "Construction & Real Estate", icon: "🏗️", vat: "Commercial standard; residential exempt", wht: "5% works contracts + retention" },
  { code: "TRADING", name: "Trading & Distribution", icon: "🛒", vat: "Standard-rated retail/wholesale", wht: "3% goods · 7.5% haulage" },
  { code: "SERVICES", name: "Professional Services", icon: "💼", vat: "All services register (Act 1151)", wht: "7.5% services · 20% directors" },
  { code: "FINANCE", name: "Banking & Financial Services", icon: "🏦", vat: "Core interest exempt; fees standard; GSL 5%", wht: "Exempt on interest paid" },
  { code: "HEALTH", name: "Healthcare & Pharma", icon: "🏥", vat: "Medical services & drugs exempt", wht: "3% pharma supply · 7.5% locum" },
  { code: "EDUC", name: "Education", icon: "🎓", vat: "Tuition exempt; materials standard", wht: "7.5% consultants" },
  { code: "TRANSPORT", name: "Transport & Logistics", icon: "🚚", vat: "Passenger exempt; haulage standard", wht: "7.5% haulage services" },
  { code: "HOSPITALITY", name: "Hospitality & Tourism", icon: "🏨", vat: "Standard + 1% tourism levy", wht: "7.5% services · 3% supplies" },
  { code: "ICT", name: "ICT & Telecom", icon: "📡", vat: "Standard-rated; CST 5%; GSL 5%", wht: "7.5% resident · 20% NR licences" },
  { code: "NGO", name: "NGO & Public Sector", icon: "🤝", vat: "Donor-funded relief exempt", wht: "Withholding agent — 7% VAT WHT" },
];

/** Provision a client ledger: unique company code + COA + operating bank account. */
export async function provisionClient(input: {
  businessName: string; sector: string; tin?: string; contactPerson?: string; email?: string;
  phone?: string; monthlyFee?: number; currency?: string; isTest?: boolean;
  bankName?: string; sortCode?: string; accountNumber?: string;
}) {
  const existing = await db.select().from(clients);
  const seq = existing.length + 1;
  let n = seq;
  let clientCode = `CLI-${String(n).padStart(3, "0")}`;
  // FIX (root cause): every client receives its OWN company code (C###), never a
  // shared parent/bank code like the legacy "BPZ3" default.
  let companyCode = `C${String(n).padStart(3, "0")}`;
  const taken = new Set(existing.map((c) => c.companyCode));
  const takenCli = new Set(existing.map((c) => c.clientCode));
  while (taken.has(companyCode) || takenCli.has(clientCode)) {
    n += 1;
    companyCode = `C${String(n).padStart(3, "0")}`;
    clientCode = `CLI-${String(n).padStart(3, "0")}`;
  }
  const [client] = await db.insert(clients).values({
    clientCode, companyCode,
    businessName: input.businessName,
    sector: input.sector,
    tin: input.tin || "",
    contactPerson: input.contactPerson || "",
    email: input.email || "",
    phone: input.phone || "",
    currency: input.currency || "GHS",
    monthlyFee: String(input.monthlyFee ?? 2500),
    isTest: input.isTest ?? false,
  }).returning();

  await db.insert(accounts).values(STANDARD_COA.map((a) => ({ companyCode, code: a.code, name: a.name, type: a.type, isBank: a.isBank ?? false })));
  await db.insert(bankAccounts).values({
    companyCode,
    bankName: input.bankName || "GCB Bank PLC",
    sortCode: input.sortCode || "040",
    accountNumber: input.accountNumber || `${String(1400000000 + n * 7919)}`,
    accountName: input.businessName,
    currency: input.currency || "GHS",
    glAccount: "100200",
  });
  await db.insert(auditLog).values({ companyCode, action: "CLIENT_PROVISION", detail: `${clientCode} ${input.businessName} → own company code ${companyCode}, COA + bank account provisioned` });
  return client;
}

export async function getClientByCompany(companyCode: string) {
  const [c] = await db.select().from(clients).where(eq(clients.companyCode, companyCode));
  return c || null;
}