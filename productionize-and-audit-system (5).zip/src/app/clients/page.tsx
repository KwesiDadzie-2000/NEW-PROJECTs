"use client";

import { useState } from "react";
import { Plus, ShieldCheck, X, BadgeCheck, Building2 } from "lucide-react";
import { PageHead, useClients, useToast, api, fmt, Badge, Busy, RefreshBtn } from "@/components/ui";

const SECTOR_OPTIONS = [
  ["AGRI", "Agriculture & Agribusiness"], ["MINING", "Mining & Minerals"], ["OILGAS", "Oil, Gas & Energy"],
  ["MANUF", "Manufacturing"], ["CONST", "Construction & Real Estate"], ["TRADING", "Trading & Distribution"],
  ["SERVICES", "Professional Services"], ["FINANCE", "Banking & Financial Services"], ["HEALTH", "Healthcare & Pharma"],
  ["EDUC", "Education"], ["TRANSPORT", "Transport & Logistics"], ["HOSPITALITY", "Hospitality & Tourism"],
  ["ICT", "ICT & Telecom"], ["NGO", "NGO & Public Sector"],
];

export default function ClientsPage() {
  const { clients, loading, reload } = useClients();
  const toast = useToast();
  const [modal, setModal] = useState(false);
  const [busy, setBusy] = useState(false);
  const [issued, setIssued] = useState<{ clientCode: string; companyCode: string; businessName: string } | null>(null);
  const [form, setForm] = useState({ businessName: "", sector: "SERVICES", tin: "", contactPerson: "", email: "", phone: "", monthlyFee: "2500", bankName: "GCB Bank PLC", accountNumber: "" });
  const set = (k: string, v: string) => setForm((f) => ({ ...f, [k]: v }));

  const create = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    const d = await api("/api/clients", "POST", { ...form, accountNumber: form.accountNumber || undefined, monthlyFee: Number(form.monthlyFee) });
    setBusy(false);
    if (d.success) {
      setIssued(d.client); setModal(false); reload();
      setForm({ businessName: "", sector: "SERVICES", tin: "", contactPerson: "", email: "", phone: "", monthlyFee: "2500", bankName: "GCB Bank PLC", accountNumber: "" });
      toast.ok(d.message);
    } else toast.err(d.error);
  };

  const setStatus = async (clientCode: string, status: string) => {
    const d = await api("/api/clients", "PATCH", { clientCode, status });
    if (d.success) { toast.ok(`${clientCode} → ${status}`); reload(); } else toast.err(d.error);
  };

  return (
    <div>
      {toast.node}
      <PageHead
        tcode="BPZ-CLI · Client Workspaces"
        title="Real clients. Real ledgers."
        sub="Each client is provisioned with an exclusive company code, a full chart of accounts and an operating bank account. Bank identifiers stay attached to the bank — never to the ledger identity."
        actions={<><RefreshBtn onClick={reload} busy={loading} /><button className="btn btn-primary" onClick={() => setModal(true)}><Plus className="w-4 h-4" /> Create client</button></>}
      />

      {issued && (
        <div className="panel p-5 mb-4 border-l-4 !border-l-leaf rise">
          <div className="flex items-start justify-between">
            <div className="flex gap-3">
              <BadgeCheck className="w-6 h-6 text-leaf shrink-0" />
              <div>
                <div className="font-display font-bold text-[15px]">Workspace issued — {issued.businessName}</div>
                <p className="text-[13px] text-slate-600 mt-1">
                  Client reference <b className="font-mono">{issued.clientCode}</b> now owns company code{" "}
                  <span className="font-mono font-bold text-leaf bg-leaf-soft px-2 py-0.5 rounded">{issued.companyCode}</span>.
                  All documents, invoices, payroll and statements for this client post under this code only.
                </p>
              </div>
            </div>
            <button onClick={() => setIssued(null)} className="text-slate-400 hover:text-ink"><X className="w-4 h-4" /></button>
          </div>
        </div>
      )}

      <div className="panel p-5 rise rise-1">
        {loading ? <Busy label="Loading client ledgers…" /> : (
          <div className="overflow-x-auto">
            <table className="ledger-table">
              <thead><tr>
                <th>Client</th><th>Company code</th><th>Sector</th><th>TIN</th><th className="!text-right">Docs</th>
                <th className="!text-right">AR open</th><th className="!text-right">AP open</th><th>TB</th><th>Status</th>
              </tr></thead>
              <tbody>
                {clients.length === 0 && <tr><td colSpan={9} className="text-center py-8 text-slate-500">No clients yet — create the first workspace.</td></tr>}
                {clients.map((c) => (
                  <tr key={c.id}>
                    <td>
                      <div className="font-bold text-ink">{c.businessName}</div>
                      <div className="text-[11px] text-slate-500 font-mono">{c.clientCode} · {c.email || "—"}</div>
                    </td>
                    <td><span className="font-mono font-bold text-leaf bg-leaf-soft px-2 py-0.5 rounded text-[12px]">{c.companyCode}</span></td>
                    <td className="text-slate-600">{c.sector}</td>
                    <td className="font-mono text-[12px]">{c.tin || "—"}</td>
                    <td className="text-right font-mono">{c.documents}</td>
                    <td className="text-right font-mono tnum">{fmt(c.openAr || 0, c.currency)}</td>
                    <td className="text-right font-mono tnum">{fmt(c.openAp || 0, c.currency)}</td>
                    <td>{c.balanced ? <Badge tone="green"><ShieldCheck className="w-3 h-3" /> balanced</Badge> : <Badge tone="red">imbalance</Badge>}</td>
                    <td>
                      <select value={c.status} onChange={(e) => setStatus(c.clientCode, e.target.value)} className="field !w-auto !py-1 !px-2 text-[11.5px] font-bold">
                        <option>ACTIVE</option><option>ONBOARDING</option><option>SUSPENDED</option>
                      </select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {modal && (
        <div className="fixed inset-0 z-50 bg-ink/60 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setModal(false)}>
          <div className="bg-white rounded-xl max-w-xl w-full p-6 shadow-2xl max-h-[92vh] overflow-y-auto rise" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between">
              <h3 className="font-display font-black text-[18px] flex items-center gap-2"><Building2 className="w-5 h-5 text-leaf" /> Create client workspace</h3>
              <button onClick={() => setModal(false)} className="text-slate-400 hover:text-ink"><X className="w-5 h-5" /></button>
            </div>
            <p className="text-[12.5px] text-slate-500 mt-1">A unique company code is issued automatically — it can never collide with a bank code or another client.</p>
            <form onSubmit={create} className="grid grid-cols-2 gap-3 mt-4">
              <div className="col-span-2"><label className="flabel">Business name *</label><input className="field" required value={form.businessName} onChange={(e) => set("businessName", e.target.value)} placeholder="e.g. Adom Farms & Produce Ltd" /></div>
              <div><label className="flabel">Sector *</label>
                <select className="field" value={form.sector} onChange={(e) => set("sector", e.target.value)}>
                  {SECTOR_OPTIONS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
                </select>
              </div>
              <div><label className="flabel">GRA TIN</label><input className="field" value={form.tin} onChange={(e) => set("tin", e.target.value)} placeholder="C00XXXXXXXX" /></div>
              <div><label className="flabel">Contact person</label><input className="field" value={form.contactPerson} onChange={(e) => set("contactPerson", e.target.value)} /></div>
              <div><label className="flabel">Email</label><input className="field" type="email" value={form.email} onChange={(e) => set("email", e.target.value)} /></div>
              <div><label className="flabel">Operating bank</label>
                <select className="field" value={form.bankName} onChange={(e) => set("bankName", e.target.value)}>
                  {["GCB Bank PLC", "Ecobank Ghana PLC", "Absa Bank Ghana", "Stanbic Bank Ghana", "Fidelity Bank Ghana", "CalBank PLC", "ADB Bank Limited", "Zenith Bank Ghana"].map((b) => <option key={b}>{b}</option>)}
                </select>
              </div>
              <div><label className="flabel">Account number</label><input className="field" value={form.accountNumber} onChange={(e) => set("accountNumber", e.target.value)} placeholder="auto if blank" /></div>
              <div><label className="flabel">Monthly retainer (GHS)</label><input className="field" type="number" value={form.monthlyFee} onChange={(e) => set("monthlyFee", e.target.value)} /></div>
              <div className="col-span-2 flex justify-end gap-2 mt-2">
                <button type="button" className="btn btn-ghost" onClick={() => setModal(false)}>Cancel</button>
                <button className="btn btn-primary" disabled={busy}>{busy ? "Provisioning…" : "Provision ledger"}</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}