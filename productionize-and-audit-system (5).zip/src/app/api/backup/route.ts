import { db } from "@/db";
import { clients, accounts, journalEntries, journalLines, invoices, bankAccounts, statementLines, processedDocs, auditLog, periods, testRuns } from "@/db/schema";
import { requireUser } from "@/lib/server/auth";

export const dynamic = "force-dynamic";

/** Owner-only full practice export (JSON). Credentials & sessions are NEVER exported. */
export async function GET() {
  const auth = await requireUser(["SYSTEM_OWNER"]);
  if (auth instanceof Response) return auth;
  const payload = {
    format: "bpz-fiscal-backup",
    version: 1,
    exportedAt: new Date().toISOString(),
    exportedBy: auth.username,
    data: {
      clients: await db.select().from(clients),
      accounts: await db.select().from(accounts),
      journalEntries: await db.select().from(journalEntries),
      journalLines: await db.select().from(journalLines),
      invoices: await db.select().from(invoices),
      bankAccounts: await db.select().from(bankAccounts),
      statementLines: await db.select().from(statementLines),
      processedDocs: await db.select().from(processedDocs),
      periods: await db.select().from(periods),
      auditLog: await db.select().from(auditLog),
      testRuns: await db.select().from(testRuns),
    },
  };
  return new Response(JSON.stringify(payload, null, 2), {
    headers: {
      "Content-Type": "application/json",
      "Content-Disposition": `attachment; filename="bpz-fiscal-backup-${new Date().toISOString().slice(0, 10)}.json"`,
    },
  });
}