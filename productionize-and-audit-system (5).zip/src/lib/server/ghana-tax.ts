// Ghana fiscal engine — statutory law, ported from BPZ ghana-tax.ts and hardened.
// VAT: Act 1151 (eff. 1 Jan 2026) — unified 20% on the SAME base (15% VAT + 2.5% NHIL + 2.5% GETFund).
//      COVID levy abolished; NHIL/GETFund deductible; flat-rate scheme abolished. Pre-2026 postings are blocked upstream.
// PAYE: Income Tax (Amendment) Act 2026 (Act 1178) — first GH¢588 tax-free monthly.
// SSNIT: 5.5% employee / 13% employer on basic (cap GH¢69,000/month, 2026).

export const r2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;
export const money = (n: number | string, currency = "GHS") =>
  new Intl.NumberFormat("en-GH", { style: "currency", currency, minimumFractionDigits: 2 }).format(Number(n || 0));

export const VAT_ACT1151 = { vat: 0.15, nhil: 0.025, getfund: 0.025, total: 0.2 };
export const VAT_THRESHOLD_GOODS = 750000;
export const VAT_WITHHOLD_RATE = 0.07; // GRA-appointed withholding agents
export const GST_CST_RATE = 0.05;
export const TOURISM_LEVY_RATE = 0.01;
export const GROWTH_SUSTAINABILITY_LEVY = { standard: 0.025, banksTelecom: 0.05 }; // on PBT, banks/telecom 5%

export type VatTreatment = "STANDARD" | "ZERO" | "EXEMPT";

export interface VatCalc {
  base: number; vat: number; nhil: number; getfund: number; leviesTotal: number; gross: number; treatment: VatTreatment;
}

export function calcVAT(base: number, treatment: VatTreatment = "STANDARD"): VatCalc {
  const b = r2(Math.max(0, base));
  if (treatment !== "STANDARD") {
    return { base: b, vat: 0, nhil: 0, getfund: 0, leviesTotal: 0, gross: b, treatment };
  }
  const vat = r2(b * VAT_ACT1151.vat);
  const nhil = r2(b * VAT_ACT1151.nhil);
  const getfund = r2(b * VAT_ACT1151.getfund);
  const leviesTotal = r2(vat + nhil + getfund);
  return { base: b, vat, nhil, getfund, leviesTotal, gross: r2(b + leviesTotal), treatment };
}

/** Reverse-calculate levies from a VAT-inclusive amount (Act 1151: divide by 1.20). */
export function vatFromInclusive(gross: number): VatCalc {
  const base = r2(gross / (1 + VAT_ACT1151.total));
  const calc = calcVAT(base);
  // absorb rounding residue into VAT so levies reconcile to the inclusive gross
  const residue = r2(gross - calc.gross);
  return { ...calc, vat: r2(calc.vat + residue), leviesTotal: r2(calc.leviesTotal + residue), gross: r2(gross) };
}

export interface WhtRate { code: string; rate: number; label: string }
export const GH_WHT_RATES: WhtRate[] = [
  { code: "GOODS", rate: 3, label: "3% — Supply of goods (resident)" },
  { code: "WORKS", rate: 5, label: "5% — Works / construction contracts" },
  { code: "SERVICES", rate: 7.5, label: "7.5% — Services (resident)" },
  { code: "RENT", rate: 8, label: "8% — Rent (residential)" },
  { code: "RENT_COMM", rate: 15, label: "15% — Rent (commercial / non-residential)" },
  { code: "ROYALTY", rate: 10, label: "10% — Royalties / natural resources (final 15% NR)" },
  { code: "DIRECTORS", rate: 20, label: "20% — Directors' fees" },
  { code: "NONRESIDENT", rate: 20, label: "20% — Non-resident services / technical fees" },
  { code: "PRODUCE", rate: 3, label: "3% — Purchase of produce from aggregators" },
  { code: "NONE", rate: 0, label: "0% — Exempt / no withholding" },
];
export const whtAmount = (baseExclVat: number, ratePct: number) => r2(Math.max(0, baseExclVat) * (ratePct / 100));

// ---------------- PAYE (Act 1178, monthly) ----------------
export interface PayeBand { upTo: number; rate: number; label: string }
export const PAYE_MONTHLY: PayeBand[] = [
  { upTo: 588, rate: 0, label: "First 588.00 @ 0%" },
  { upTo: 668, rate: 0.05, label: "Next 80.00 @ 5%" },
  { upTo: 768, rate: 0.1, label: "Next 100.00 @ 10%" },
  { upTo: 3668, rate: 0.175, label: "Next 2,900.00 @ 17.5%" },
  { upTo: 19668, rate: 0.25, label: "Next 16,000.00 @ 25%" },
  { upTo: 50000, rate: 0.3, label: "Next 30,332.00 @ 30%" },
  { upTo: Infinity, rate: 0.35, label: "Excess @ 35%" },
];
export const CASUAL_RATE = 0.05;
export const NONRESIDENT_RATE = 0.25;
export const SSNIT_EMPLOYEE = 0.055;
export const SSNIT_EMPLOYER = 0.13;
export const SSNIT_CAP = 69000;

export function calcPAYE(taxable: number): { tax: number; breakdown: string[] } {
  let remaining = r2(Math.max(0, taxable));
  let prev = 0;
  let total = 0;
  const breakdown: string[] = [];
  for (const b of PAYE_MONTHLY) {
    if (remaining <= 0) break;
    const span = b.upTo === Infinity ? remaining : Math.min(remaining, b.upTo - prev);
    const t = r2(span * b.rate);
    total = r2(total + t);
    if (span > 0) breakdown.push(`GH¢${span.toFixed(2)} @ ${(b.rate * 100).toFixed(1)}% = GH¢${t.toFixed(2)}`);
    remaining = r2(remaining - span);
    prev = b.upTo;
  }
  return { tax: total, breakdown };
}

export interface PayrollInput {
  basic: number; allowances?: number; tier3?: number;
  casual?: boolean; nonResident?: boolean; ssnitExempt?: boolean;
}
export interface PayrollResult {
  gross: number; ssnitEmployee: number; ssnitEmployer: number; tier3: number;
  taxable: number; paye: number; netPay: number; breakdown: string[]; totalEmployerCost: number;
}

export function computePayrollLine(i: PayrollInput): PayrollResult {
  const basic = r2(Math.max(0, i.basic));
  const allowances = r2(Math.max(0, i.allowances || 0));
  const gross = r2(basic + allowances);
  if (i.casual) {
    const paye = r2(gross * CASUAL_RATE);
    return {
      gross, ssnitEmployee: 0, ssnitEmployer: 0, tier3: 0, taxable: gross, paye,
      netPay: r2(gross - paye), breakdown: [`Casual worker: 5% final WHT on GH¢${gross.toFixed(2)}`], totalEmployerCost: gross,
    };
  }
  if (i.nonResident) {
    const paye = r2(gross * NONRESIDENT_RATE);
    return {
      gross, ssnitEmployee: 0, ssnitEmployer: 0, tier3: 0, taxable: gross, paye,
      netPay: r2(gross - paye), breakdown: [`Non-resident: 25% flat on GH¢${gross.toFixed(2)}`], totalEmployerCost: gross,
    };
  }
  const ssnitBase = Math.min(basic, SSNIT_CAP);
  const ssnitEmployee = i.ssnitExempt ? 0 : r2(ssnitBase * SSNIT_EMPLOYEE);
  const ssnitEmployer = i.ssnitExempt ? 0 : r2(ssnitBase * SSNIT_EMPLOYER);
  const tier3 = r2(Math.max(0, i.tier3 || 0));
  const taxable = r2(gross - ssnitEmployee - tier3);
  const { tax, breakdown } = calcPAYE(taxable);
  const netPay = r2(gross - ssnitEmployee - tier3 - tax);
  return {
    gross, ssnitEmployee, ssnitEmployer, tier3, taxable, paye: tax, netPay,
    breakdown: [`SSNIT Tier 1 (5.5% of basic): GH¢${ssnitEmployee.toFixed(2)}`, ...breakdown],
    totalEmployerCost: r2(gross + ssnitEmployer),
  };
}