import { runSectorSuite, latestRuns } from "@/lib/server/suite";
import { requireUser, CONTROL_ROLES } from "@/lib/server/auth";

export const dynamic = "force-dynamic";
export const maxDuration = 300;

export async function GET() {
  const auth = await requireUser();
  if (auth instanceof Response) return auth;
  const runs = await latestRuns();
  return Response.json({ success: true, runs });
}

export async function POST() {
  const auth = await requireUser(CONTROL_ROLES);
  if (auth instanceof Response) return auth;
  const result = await runSectorSuite();
  return Response.json({ success: true, ...result, run: { id: result.run.id, ranAt: result.run.ranAt } });
}