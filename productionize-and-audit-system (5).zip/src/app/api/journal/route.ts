import { db } from "@/db";
import { accounts, journalLines } from "@/db/schema";
import { eq } from "drizzle-orm";
import { postEntry, reverseEntry, trialBalance } from "@/lib/server/ledger";
import { listEntries } from "@/lib/server/operations";
import { requireUser, POSTING_ROLES, CONTROL_ROLES } from "@/lib/server/auth";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const auth = await requireUser();
  if (auth instanceof Response) return auth;
  const url = new URL(req.url);
  const cc = url.searchParams.get("companyCode") || undefined;
  const entryId = url.searchParams.get("entryId");
  if (entryId) {
    const lines = await db.select().from(journalLines).where(eq(journalLines.entryId, Number(entryId)));
    return Response.json({ success: true, lines });
  }
  const entries = await listEntries(cc);
  const tb = cc ? await trialBalance(cc) : null;
  const coa = cc ? await db.select().from(accounts).where(eq(accounts.companyCode, cc)) : [];
  return Response.json({ success: true, entries, trialBalance: tb, accounts: coa });
}

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const auth = await requireUser(body.action === "REVERSE" ? CONTROL_ROLES : POSTING_ROLES);
  if (auth instanceof Response) return auth;
  if (body.action === "REVERSE") {
    const res = await reverseEntry(Number(body.entryId), body.reason || "Correction", auth.username);
    return Response.json(res.ok ? { success: true, docNumber: res.docNumber } : { success: false, error: res.error }, { status: res.ok ? 200 : 400 });
  }
  const res = await postEntry({
    companyCode: body.companyCode, docType: body.docType || "SA", postingDate: body.postingDate,
    headerText: body.headerText || "", reference: body.reference, lines: body.lines || [], source: "MANUAL", createdBy: auth.username,
  });
  return Response.json(res.ok ? { success: true, docNumber: res.docNumber } : { success: false, error: res.error }, { status: res.ok ? 200 : 400 });
}