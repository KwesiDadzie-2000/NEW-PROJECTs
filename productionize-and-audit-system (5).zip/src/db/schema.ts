import {
  pgTable,
  serial,
  text,
  integer,
  numeric,
  boolean,
  timestamp,
  jsonb,
  uniqueIndex,
} from "drizzle-orm/pg-core";

/** Client workspaces — each client owns exactly ONE unique company code. */
export const clients = pgTable(
  "clients",
  {
    id: serial("id").primaryKey(),
    clientCode: text("client_code").notNull(),
    companyCode: text("company_code").notNull(),
    businessName: text("business_name").notNull(),
    sector: text("sector").notNull().default("SERVICES"),
    currency: text("currency").notNull().default("GHS"),
    tin: text("tin").notNull().default(""),
    contactPerson: text("contact_person").notNull().default(""),
    email: text("email").notNull().default(""),
    phone: text("phone").notNull().default(""),
    status: text("status").notNull().default("ACTIVE"),
    monthlyFee: numeric("monthly_fee", { precision: 14, scale: 2 }).notNull().default("0"),
    isTest: boolean("is_test").notNull().default(false),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [uniqueIndex("clients_client_code_uq").on(t.clientCode), uniqueIndex("clients_company_code_uq").on(t.companyCode)]
);

/** Chart of accounts — one ledger per company code. */
export const accounts = pgTable(
  "accounts",
  {
    id: serial("id").primaryKey(),
    companyCode: text("company_code").notNull(),
    code: text("code").notNull(),
    name: text("name").notNull(),
    type: text("type").notNull(), // ASSET | LIABILITY | EQUITY | REVENUE | EXPENSE
    isBank: boolean("is_bank").notNull().default(false),
  },
  (t) => [uniqueIndex("accounts_company_code_uq").on(t.companyCode, t.code)]
);

/** Posted double-entry documents (FB01/FB03/FB08). */
export const journalEntries = pgTable(
  "journal_entries",
  {
    id: serial("id").primaryKey(),
    companyCode: text("company_code").notNull(),
    docNumber: text("doc_number").notNull(),
    docType: text("doc_type").notNull(), // SA DR KR DZ KZ PR RV
    postingDate: text("posting_date").notNull(),
    headerText: text("header_text").notNull().default(""),
    reference: text("reference").notNull().default(""),
    totalDebit: numeric("total_debit", { precision: 16, scale: 2 }).notNull(),
    totalCredit: numeric("total_credit", { precision: 16, scale: 2 }).notNull(),
    status: text("status").notNull().default("POSTED"), // POSTED | REVERSED
    reversalOf: integer("reversal_of"),
    source: text("source").notNull().default("MANUAL"), // MANUAL DOCUMENT BANK INVOICE PAYMENT PAYROLL TEST
    createdBy: text("created_by").notNull().default("owner"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [uniqueIndex("je_company_doc_uq").on(t.companyCode, t.docNumber)]
);

export const journalLines = pgTable("journal_lines", {
  id: serial("id").primaryKey(),
  entryId: integer("entry_id").notNull(),
  accountCode: text("account_code").notNull(),
  side: text("side").notNull(), // D | C
  amount: numeric("amount", { precision: 16, scale: 2 }).notNull(),
  itemText: text("item_text").notNull().default(""),
});

/** AR / AP invoices with Ghana levy + WHT breakdown. */
export const invoices = pgTable("invoices", {
  id: serial("id").primaryKey(),
  companyCode: text("company_code").notNull(),
  invoiceNo: text("invoice_no").notNull(),
  kind: text("kind").notNull(), // AR | AP
  partner: text("partner").notNull(),
  invoiceDate: text("invoice_date").notNull(),
  dueDate: text("due_date").notNull(),
  netAmount: numeric("net_amount", { precision: 16, scale: 2 }).notNull(),
  vatAmount: numeric("vat_amount", { precision: 16, scale: 2 }).notNull().default("0"),
  nhilAmount: numeric("nhil_amount", { precision: 16, scale: 2 }).notNull().default("0"),
  getfundAmount: numeric("getfund_amount", { precision: 16, scale: 2 }).notNull().default("0"),
  whtRate: numeric("wht_rate", { precision: 6, scale: 2 }).notNull().default("0"),
  whtAmount: numeric("wht_amount", { precision: 16, scale: 2 }).notNull().default("0"),
  vatWithheld: numeric("vat_withheld", { precision: 16, scale: 2 }).notNull().default("0"),
  grossTotal: numeric("gross_total", { precision: 16, scale: 2 }).notNull(),
  amountPaid: numeric("amount_paid", { precision: 16, scale: 2 }).notNull().default("0"),
  balance: numeric("balance", { precision: 16, scale: 2 }).notNull(),
  status: text("status").notNull().default("OPEN"), // OPEN PARTIALLY_PAID PAID
  entryId: integer("entry_id"),
  description: text("description").notNull().default(""),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

/** Bank accounts belong to a CLIENT company code — never to the bank itself. */
export const bankAccounts = pgTable("bank_accounts", {
  id: serial("id").primaryKey(),
  companyCode: text("company_code").notNull(),
  bankName: text("bank_name").notNull(),
  sortCode: text("sort_code").notNull().default(""),
  accountNumber: text("account_number").notNull(),
  accountName: text("account_name").notNull(),
  currency: text("currency").notNull().default("GHS"),
  glAccount: text("gl_account").notNull().default("100200"),
});

export const statementLines = pgTable("statement_lines", {
  id: serial("id").primaryKey(),
  bankAccountId: integer("bank_account_id").notNull(),
  lineDate: text("line_date").notNull(),
  description: text("description").notNull().default(""),
  debit: numeric("debit", { precision: 16, scale: 2 }).notNull().default("0"),
  credit: numeric("credit", { precision: 16, scale: 2 }).notNull().default("0"),
  suggestedAccount: text("suggested_account").notNull().default("100200"),
  status: text("status").notNull().default("UNMATCHED"), // UNMATCHED POSTED MATCHED
  entryId: integer("entry_id"),
});

/** Documents processed by the intelligence desk (extraction evidence kept). */
export const processedDocs = pgTable("processed_docs", {
  id: serial("id").primaryKey(),
  companyCode: text("company_code"),
  docType: text("doc_type").notNull().default("UNKNOWN"),
  sourceText: text("source_text").notNull(),
  extraction: jsonb("extraction").notNull(),
  status: text("status").notNull().default("EXTRACTED"), // EXTRACTED POSTED REJECTED
  confidence: integer("confidence").notNull().default(0),
  entryId: integer("entry_id"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const auditLog = pgTable("audit_log", {
  id: serial("id").primaryKey(),
  companyCode: text("company_code"),
  actor: text("actor").notNull().default("owner"),
  action: text("action").notNull(),
  detail: text("detail").notNull().default(""),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

/** Practice users — role-based access + segregation of duties. */
export const users = pgTable(
  "users",
  {
    id: serial("id").primaryKey(),
    username: text("username").notNull(),
    fullName: text("full_name").notNull(),
    role: text("role").notNull(), // SYSTEM_OWNER | CONTROLLER | ACCOUNTANT | AUDITOR
    passwordHash: text("password_hash").notNull(), // scrypt salt:hash — never plaintext
    status: text("status").notNull().default("ACTIVE"),
    failedAttempts: integer("failed_attempts").notNull().default(0),
    lockedUntil: timestamp("locked_until"),
    lastLogin: timestamp("last_login"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [uniqueIndex("users_username_uq").on(t.username)]
);

export const sessions = pgTable("sessions", {
  id: serial("id").primaryKey(),
  tokenHash: text("token_hash").notNull(),
  userId: integer("user_id").notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

/** OB52-style posting period control per client ledger. No row = OPEN. */
export const periods = pgTable(
  "periods",
  {
    id: serial("id").primaryKey(),
    companyCode: text("company_code").notNull(),
    fiscalYear: integer("fiscal_year").notNull(),
    period: integer("period").notNull(),
    status: text("status").notNull().default("OPEN"), // OPEN | CLOSED
    closedBy: text("closed_by").notNull().default(""),
    closedAt: timestamp("closed_at"),
  },
  (t) => [uniqueIndex("periods_company_year_period_uq").on(t.companyCode, t.fiscalYear, t.period)]
);

export const testRuns = pgTable("test_runs", {
  id: serial("id").primaryKey(),
  passed: integer("passed").notNull().default(0),
  failed: integer("failed").notNull().default(0),
  total: integer("total").notNull().default(0),
  durationMs: integer("duration_ms").notNull().default(0),
  results: jsonb("results").notNull(),
  ranAt: timestamp("ran_at").notNull().defaultNow(),
});