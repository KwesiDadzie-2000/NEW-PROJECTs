"use client";

import { useCallback, useEffect, useState } from "react";
import { FileBarChart2, Download, Scale, Clock3 } from "lucide-react";
import { PageHead, useClients, api, fmt, num, ClientPicker, Busy, Empty, Badge } from "@/components/ui";

interface Line { code: string; name: string; amount: number }
interface Aging { partner: string; current: number; d30: number; d60: number; d90: number; d90plus: number; total: number; items: number }
interface Report {
  client: { businessName: string; companyCode: string; currency: string; sector: string };
  asOf: string; preparedBy: string;
  balanceSheet: { assets: Line[]; liabilities: Line[]; equity: Line[]; profitForPeriod: number; totalAssets: number; totalLiabilities: number; totalEquity: number; totalEquityAndProfit: number; balances: boolean };
  incomeStatement: { revenueLines: Line[]; expenseLines: Line[]; revenue: number; expense: number; profit: number; margin: number };
  arAging: Aging[]; apAging: Aging[];
}

function downloadCsv(name: string, rows: (string | number)[][]) {
  const csv = rows.map((r) => r.map((c) => (/[",\n]/.test(String(c)) ? `"${String(c).replace(/"/g, '""')}"` : String(c))).join(",")).join("\n");
  const url = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
  const a = document.createElement("a");
  a.href = url; a.download = name; a.click();
  URL.revokeObjectURL(url);
}

function Section({ title, lines, total, totalLabel, currency, negative = false }: { title: string; lines: Line[]; total: number; totalLabel: string; currency: string; negative?: boolean }) {
  return (
    <div>
      <div className="font-display font-bold text-[13px] uppercase tracking-wide text-leaf border-b-2 border-ink pb-1 mb-1">{title}</div>
      <table className="ledger-table">
        <tbody>
          {lines.length === 0 && <tr><td className="text-slate-400 text-[12px]">No balances</td><td></td></tr>}
          {lines.map((l) => (
            <tr key={l.code}><td><span className="font-mono text-[11px] text-slate-400 mr-2">{l.code}</span>{l.name}</td><td className="text-right font-mono tnum">{num(negative ? -l.amount : l.amount)}</td></tr>
          ))}
          <tr className="font-bold"><td className="font-display border-t-2 border-ink">{totalLabel}</td><td className="text-right font-mono tnum border-t-2 border-ink">{fmt(total, currency)}</td></tr>
        </tbody>
      </table>
    </div>
  );
}

function AgingTable({ title, rows, currency }: { title: string; rows: Aging[]; currency: string }) {
  const totals = rows.reduce((t, r) => ({ current: t.current + r.current, d30: t.d30 + r.d30, d60: t.d60 + r.d60, d90: t.d90 + r.d90, d90plus: t.d90plus + r.d90plus, total: t.total + r.total }), { current: 0, d30: 0, d60: 0, d90: 0, d90plus: 0, total: 0 });
  const max = Math.max(1, ...rows.map((r) => r.total));
  return (
    <div className="panel p-5 rise rise-3">
      <h3 className="font-display font-bold text-[15px] flex items-center gap-2 mb-3"><Clock3 className="w-4 h-4 text-leaf" /> {title}</h3>
      {rows.length === 0 ? <p className="text-[13px] text-slate-500 py-4 text-center">No open items.</p> : (
        <div className="overflow-x-auto">
          <table className="ledger-table">
            <thead><tr><th>Partner</th><th className="!text-right">Current</th><th className="!text-right">1–30</th><th className="!text-right">31–60</th><th className="!text-right">61–90</th><th className="!text-right">90+</th><th className="!text-right">Total</th><th className="w-28">Weight</th></tr></thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.partner}>
                  <td className="font-semibold max-w-[180px] truncate">{r.partner}<div className="text-[10px] text-slate-400">{r.items} item(s)</div></td>
                  {[r.current, r.d30, r.d60, r.d90, r.d90plus].map((v, i) => (
                    <td key={i} className={`text-right font-mono tnum ${i >= 3 && v > 0 ? "text-clay font-bold" : ""}`}>{v > 0 ? num(v) : "·"}</td>
                  ))}
                  <td className="text-right font-mono tnum font-bold">{num(r.total)}</td>
                  <td><div className="h-2 bg-slate-100 rounded-full overflow-hidden"><div className={`h-full barfill ${r.d90plus > 0 ? "bg-clay" : "bg-leaf"}`} style={{ width: `${(r.total / max) * 100}%` }} /></div></td>
                </tr>
              ))}
              <tr className="font-bold">
                <td className="font-display border-t-2 border-ink">TOTAL ({currency})</td>
                {[totals.current, totals.d30, totals.d60, totals.d90, totals.d90plus, totals.total].map((v, i) => (
                  <td key={i} className="text-right font-mono tnum border-t-2 border-ink">{num(v)}</td>
                ))}
                <td className="border-t-2 border-ink"></td>
              </tr>
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export default function ReportsPage() {
  const { clients } = useClients();
  const [cc, setCc] = useState("");
  const [asOf, setAsOf] = useState("2026-02-28");
  const [r, setR] = useState<Report | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => { if (!cc && clients.length) setCc(clients[0].companyCode); }, [clients, cc]);
  const load = useCallback(async () => {
    if (!cc) return;
    setLoading(true);
    const d = await api(`/api/reports?companyCode=${cc}&asOf=${asOf}`);
    if (d.success) setR(d);
    setLoading(false);
  }, [cc, asOf]);
  useEffect(() => { load(); }, [load]);

  const exportBs = () => {
    if (!r) return;
    const rows: (string | number)[][] = [[`${r.client.businessName} — Statement of Financial Position`, r.asOf], [], ["ASSETS"], ...r.balanceSheet.assets.map((l) => [l.code, l.name, l.amount]), ["", "Total assets", r.balanceSheet.totalAssets], [], ["LIABILITIES"], ...r.balanceSheet.liabilities.map((l) => [l.code, l.name, l.amount]), ["", "Total liabilities", r.balanceSheet.totalLiabilities], [], ["EQUITY"], ...r.balanceSheet.equity.map((l) => [l.code, l.name, l.amount]), ["", "Profit for period", r.balanceSheet.profitForPeriod], ["", "Total equity + profit", r.balanceSheet.totalEquityAndProfit], [], ["Prepared by", r.preparedBy]];
    downloadCsv(`SFP_${cc}_${r.asOf}.csv`, rows);
  };
  const exportPl = () => {
    if (!r) return;
    const rows: (string | number)[][] = [[`${r.client.businessName} — Statement of Profit or Loss`, r.asOf], [], ["REVENUE"], ...r.incomeStatement.revenueLines.map((l) => [l.code, l.name, l.amount]), ["", "Total revenue", r.incomeStatement.revenue], [], ["EXPENSES"], ...r.incomeStatement.expenseLines.map((l) => [l.code, l.name, l.amount]), ["", "Total expenses", r.incomeStatement.expense], [], ["", "Profit / (loss)", r.incomeStatement.profit], ["", "Margin %", r.incomeStatement.margin], ["Prepared by", r.preparedBy]];
    downloadCsv(`SPL_${cc}_${r.asOf}.csv`, rows);
  };

  return (
    <div>
      <PageHead
        tcode="FS01 · Financial Statements"
        title="Statements a partner can sign."
        sub="Statement of Financial Position, Profit or Loss and AR/AP ageing — derived live from the double-entry ledger, with one-click CSV working papers."
        actions={<>
          <ClientPicker clients={clients} value={cc} onChange={setCc} />
          <input className="field !w-auto" type="date" value={asOf} onChange={(e) => setAsOf(e.target.value)} title="Ageing as-of date" />
        </>}
      />

      {!cc ? <Empty title="Select a client ledger" /> : loading || !r ? <Busy label="Compiling statements from the ledger…" /> : (
        <>
          <div className="panel p-5 mb-4 rise flex flex-wrap items-center gap-4">
            <div>
              <div className="font-mono text-[10.5px] text-slate-400 uppercase tracking-widest">{r.client.companyCode} · {r.client.sector} · as at {r.asOf}</div>
              <div className="font-display font-black text-[22px] tracking-tight">{r.client.businessName}</div>
              <div className="text-[12px] text-slate-500 mt-0.5">Prepared from posted documents only · compiler: {r.preparedBy}</div>
            </div>
            <div className="ml-auto flex items-center gap-2">
              {r.balanceSheet.balances ? <Badge tone="green"><Scale className="w-3 h-3" /> SFP balances</Badge> : <Badge tone="red">SFP imbalance</Badge>}
              <Badge tone={r.incomeStatement.profit >= 0 ? "green" : "red"}>margin {r.incomeStatement.margin}%</Badge>
            </div>
          </div>

          <div className="grid lg:grid-cols-2 gap-4">
            <div className="panel p-5 rise rise-1">
              <div className="flex items-center justify-between mb-3">
                <h2 className="font-display font-bold text-[16px] flex items-center gap-2"><FileBarChart2 className="w-4 h-4 text-leaf" /> Statement of Financial Position</h2>
                <button className="btn btn-ghost !px-2.5 !py-1 !text-[11.5px]" onClick={exportBs}><Download className="w-3.5 h-3.5" /> CSV</button>
              </div>
              <div className="space-y-4">
                <Section title="Assets" lines={r.balanceSheet.assets} total={r.balanceSheet.totalAssets} totalLabel="TOTAL ASSETS" currency={r.client.currency} />
                <Section title="Liabilities" lines={r.balanceSheet.liabilities} total={r.balanceSheet.totalLiabilities} totalLabel="TOTAL LIABILITIES" currency={r.client.currency} />
                <div>
                  <Section title="Equity" lines={[...r.balanceSheet.equity, { code: "P&L", name: "Profit / (loss) for the period", amount: r.balanceSheet.profitForPeriod }]} total={r.balanceSheet.totalEquityAndProfit} totalLabel="TOTAL EQUITY" currency={r.client.currency} />
                </div>
                <div className="bg-[#f6f8f5] rounded-lg p-3 flex justify-between font-bold text-[13px]">
                  <span className="font-display">LIABILITIES + EQUITY</span>
                  <span className="font-mono tnum">{fmt(r.balanceSheet.totalLiabilities + r.balanceSheet.totalEquityAndProfit, r.client.currency)}</span>
                </div>
              </div>
            </div>

            <div className="panel p-5 rise rise-2">
              <div className="flex items-center justify-between mb-3">
                <h2 className="font-display font-bold text-[16px] flex items-center gap-2"><FileBarChart2 className="w-4 h-4 text-leaf" /> Statement of Profit or Loss</h2>
                <button className="btn btn-ghost !px-2.5 !py-1 !text-[11.5px]" onClick={exportPl}><Download className="w-3.5 h-3.5" /> CSV</button>
              </div>
              <div className="space-y-4">
                <Section title="Revenue" lines={r.incomeStatement.revenueLines} total={r.incomeStatement.revenue} totalLabel="TOTAL REVENUE" currency={r.client.currency} />
                <Section title="Expenses" lines={r.incomeStatement.expenseLines} total={r.incomeStatement.expense} totalLabel="TOTAL EXPENSES" currency={r.client.currency} />
                <div className={`rounded-lg p-4 flex justify-between items-center ${r.incomeStatement.profit >= 0 ? "bg-leaf-soft" : "bg-[#fbeae6]"}`}>
                  <span className="font-display font-black text-[15px]">PROFIT / (LOSS)</span>
                  <span className={`font-mono font-black text-[20px] tnum ${r.incomeStatement.profit >= 0 ? "text-leaf" : "text-clay"}`}>{fmt(r.incomeStatement.profit, r.client.currency)}</span>
                </div>
                <p className="text-[11.5px] text-slate-500">Growth & Sustainability Levy note: {r.client.sector === "FINANCE" || r.client.sector === "ICT" ? "5% of profit before tax (banks/telecom rate, to 2028)." : "2.5% of profit before tax (standard rate, to 2028)."}</p>
              </div>
            </div>
          </div>

          <div className="grid lg:grid-cols-2 gap-4 mt-4">
            <AgingTable title="Receivables ageing (AR)" rows={r.arAging} currency={r.client.currency} />
            <AgingTable title="Payables ageing (AP)" rows={r.apAging} currency={r.client.currency} />
          </div>
        </>
      )}
    </div>
  );
}