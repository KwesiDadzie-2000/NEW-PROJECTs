import { requireUser, CONTROL_ROLES } from "@/lib/server/auth";
import { getPeriods, setPeriodStatus, OPEN_FISCAL_YEAR } from "@/lib/server/ledger";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const auth = await requireUser();
  if (auth instanceof Response) return auth;
  const cc = new URL(req.url).searchParams.get("companyCode");
  if (!cc) return Response.json({ success: false, error: "companyCode required." }, { status: 400 });
  return Response.json({ success: true, periods: await getPeriods(cc), fiscalYear: OPEN_FISCAL_YEAR, canManage: CONTROL_ROLES.includes(auth.role) });
}

export async function POST(req: Request) {
  const auth = await requireUser(CONTROL_ROLES);
  if (auth instanceof Response) return auth;
  const body = await req.json().catch(() => ({}));
  const res = await setPeriodStatus(body.companyCode, Number(body.fiscalYear), Number(body.period), body.status, auth.username);
  return Response.json(res.ok ? { success: true } : { success: false, error: res.error }, { status: res.ok ? 200 : 400 });
}