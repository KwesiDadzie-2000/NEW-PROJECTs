"use client";

import { useEffect, useState, useCallback } from "react";
import { BookOpenText, Plus, RotateCcw, Scale, X, Eye, Lock, LockOpen, Download } from "lucide-react";

function saveCsv(name: string, rows: (string | number)[][]) {
  const csv = rows.map((r) => r.map((c) => (/[",\n]/.test(String(c)) ? `"${String(c).replace(/"/g, '""')}"` : String(c))).join(",")).join("\n");
  const url = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
  const a = document.createElement("a");
  a.href = url; a.download = name; a.click();
  URL.revokeObjectURL(url);
}
import { PageHead, useClients, useToast, api, fmt, num, Badge, ClientPicker, Busy, Empty } from "@/components/ui";

interface Entry { id: number; docNumber: string; docType: string; postingDate: string; headerText: string; reference: string; totalDebit: string; status: string; source: string; reversalOf: number | null }
interface TbRow { code: string; name: string; type: string; debit: number; credit: number; balance: number; netDebit: number; netCredit: number }
interface TB { rows: TbRow[]; totalDebit: number; totalCredit: number; isBalanced: boolean; profit: number; revenue: number; expense: number }
interface Line { id: number; accountCode: string; side: string; amount: string; itemText: string }
interface Account { code: string; name: string; type: string }

export default function LedgerPage() {
  const { clients } = useClients();
  const toast = useToast();
  const [cc, setCc] = useState("");
  const [tab, setTab] = useState<"docs" | "tb" | "periods">("docs");
  const [periodRows, setPeriodRows] = useState<Array<{ period: number; fiscalYear: number; status: string; closedBy: string }>>([]);
  const [canManagePeriods, setCanManagePeriods] = useState(false);
  const [entries, setEntries] = useState<Entry[]>([]);
  const [tb, setTb] = useState<TB | null>(null);
  const [coa, setCoa] = useState<Account[]>([]);
  const [loading, setLoading] = useState(false);
  const [detail, setDetail] = useState<{ entry: Entry; lines: Line[] } | null>(null);
  const [modal, setModal] = useState(false);
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({ postingDate: "2026-02-15", headerText: "", reference: "" });
  const [lines, setLines] = useState<Array<{ accountCode: string; side: "D" | "C"; amount: string }>>([
    { accountCode: "620000", side: "D", amount: "" }, { accountCode: "100200", side: "C", amount: "" },
  ]);

  useEffect(() => { if (!cc && clients.length) setCc(clients[0].companyCode); }, [clients, cc]);

  const load = useCallback(async () => {
    if (!cc) return;
    setLoading(true);
    const d = await api(`/api/journal?companyCode=${cc}`);
    if (d.success) { setEntries(d.entries); setTb(d.trialBalance); setCoa(d.accounts); }
    const p = await api(`/api/periods?companyCode=${cc}`);
    if (p.success) { setPeriodRows(p.periods); setCanManagePeriods(p.canManage); }
    setLoading(false);
  }, [cc]);

  const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const togglePeriod = async (period: number, status: string) => {
    const d = await api("/api/periods", "POST", { companyCode: cc, fiscalYear: 2026, period, status });
    if (d.success) { toast.ok(`Period ${MONTHS[period - 1]} 2026 → ${status}.`); load(); } else toast.err(d.error);
  };
  useEffect(() => { load(); }, [load]);

  const openDetail = async (entry: Entry) => {
    const d = await api(`/api/journal?entryId=${entry.id}`);
    if (d.success) setDetail({ entry, lines: d.lines });
  };
  const reverse = async () => {
    if (!detail) return;
    const reason = prompt("Reversal reason (FB08):", "Incorrect allocation");
    if (!reason) return;
    const d = await api("/api/journal", "POST", { action: "REVERSE", entryId: detail.entry.id, reason });
    if (d.success) { toast.ok(`Reversal ${d.docNumber} posted.`); setDetail(null); load(); } else toast.err(d.error);
  };
  const postManual = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    const d = await api("/api/journal", "POST", {
      companyCode: cc, docType: "SA", postingDate: form.postingDate, headerText: form.headerText, reference: form.reference,
      lines: lines.filter((l) => l.amount).map((l) => ({ accountCode: l.accountCode, side: l.side, amount: Number(l.amount) })),
    });
    setBusy(false);
    if (d.success) { toast.ok(`Document ${d.docNumber} posted.`); setModal(false); setForm({ postingDate: "2026-02-15", headerText: "", reference: "" }); setLines([{ accountCode: "620000", side: "D", amount: "" }, { accountCode: "100200", side: "C", amount: "" }]); load(); }
    else toast.err(d.error);
  };

  const drSum = lines.reduce((t, l) => t + (l.side === "D" ? Number(l.amount || 0) : 0), 0);
  const crSum = lines.reduce((t, l) => t + (l.side === "C" ? Number(l.amount || 0) : 0), 0);
  const client = clients.find((c) => c.companyCode === cc);

  return (
    <div>
      {toast.node}
      <PageHead
        tcode="FB03 / FB08 · General Ledger"
        title={client ? client.businessName : "General Ledger"}
        sub="Every document is double-entry, period-guarded and tied to the client's exclusive company code. Reversals post an offsetting FB08 document — nothing is ever deleted."
        actions={<>
          <ClientPicker clients={clients} value={cc} onChange={setCc} />
          <button className="btn btn-ghost" disabled={!entries.length} onClick={() => saveCsv(`journal-${cc}.csv`, [["Doc #", "Type", "Date", "Narration", "Reference", "Source", "Preparer status", "Debit", "Status"], ...entries.map((e) => [e.docNumber, e.docType, e.postingDate, e.headerText, e.reference, e.source, "", e.totalDebit, e.status])])}><Download className="w-4 h-4" /> CSV</button>
          <button className="btn btn-primary" onClick={() => setModal(true)} disabled={!cc}><Plus className="w-4 h-4" /> Post entry</button>
        </>}
      />

      {!cc ? <Empty title="Select a client ledger" sub="Choose a client above, or create one in Client Workspaces." /> : loading ? <Busy label="Loading ledger…" /> : (
        <>
          <div className="flex gap-2 mb-4">
            {([["docs", `Documents (${entries.length})`], ["tb", "Trial Balance"], ["periods", "Period Close (OB52)"]] as const).map(([k, l]) => (
              <button key={k} onClick={() => setTab(k)} className={`btn ${tab === k ? "btn-gold" : "btn-ghost"}`}>{l}</button>
            ))}
            {tb && (
              <span className="ml-auto flex items-center gap-2 text-[12.5px] font-semibold">
                <Scale className="w-4 h-4 text-leaf" />
                {tb.isBalanced ? <Badge tone="green">BALANCED · Dr = Cr {num(tb.totalDebit)}</Badge> : <Badge tone="red">OUT OF BALANCE</Badge>}
                <Badge tone={tb.profit >= 0 ? "green" : "red"}>P/L {fmt(tb.profit)}</Badge>
              </span>
            )}
          </div>

          {tab === "docs" && (
            <div className="panel p-5 rise">
              <div className="overflow-x-auto">
                <table className="ledger-table">
                  <thead><tr><th>Doc #</th><th>Type</th><th>Date</th><th>Narration</th><th>Source</th><th className="!text-right">Amount</th><th>Status</th><th></th></tr></thead>
                  <tbody>
                    {entries.length === 0 && <tr><td colSpan={8} className="text-center py-8 text-slate-500">No documents in this ledger yet.</td></tr>}
                    {entries.map((e) => (
                      <tr key={e.id}>
                        <td className="font-mono font-semibold">{e.docNumber}</td>
                        <td><Badge tone="slate">{e.docType}</Badge></td>
                        <td className="font-mono text-[12px]">{e.postingDate}</td>
                        <td className="max-w-[300px]"><div className="truncate">{e.headerText}</div>{e.reference && <div className="text-[11px] text-slate-400 font-mono">{e.reference}</div>}</td>
                        <td><Badge tone="blue">{e.source}</Badge></td>
                        <td className="text-right font-mono tnum font-semibold">{fmt(e.totalDebit, client?.currency)}</td>
                        <td><Badge tone={e.status === "REVERSED" ? "red" : "green"}>{e.status}</Badge></td>
                        <td><button className="btn btn-ghost !px-2 !py-1" onClick={() => openDetail(e)} title="Display document"><Eye className="w-3.5 h-3.5" /></button></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {tab === "periods" && (
            <div className="panel p-5 rise">
              <div className="flex items-center justify-between mb-1">
                <h2 className="font-display font-bold text-[16px]">FY2026 posting periods — {cc}</h2>
                {!canManagePeriods && <Badge tone="gold">read-only · controller role required to lock/unlock</Badge>}
              </div>
              <p className="text-[12.5px] text-slate-500 mb-4">A CLOSED period rejects every posting — invoices, payroll, bank lines and manual journals alike. FY2025 and earlier are permanently closed.</p>
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                {periodRows.map((p) => (
                  <div key={p.period} className={`panel panel-hover p-4 ${p.status === "CLOSED" ? "!border-[#efc4bb] bg-[#fffaf9]" : ""}`}>
                    <div className="flex items-center justify-between">
                      <span className="font-display font-black text-[16px]">{MONTHS[p.period - 1]} <span className="text-slate-400 font-mono text-[11px]">2026/{String(p.period).padStart(2, "0")}</span></span>
                      {p.status === "CLOSED" ? <Lock className="w-4 h-4 text-clay" /> : <LockOpen className="w-4 h-4 text-leaf" />}
                    </div>
                    <div className="mt-1.5"><Badge tone={p.status === "CLOSED" ? "red" : "green"}>{p.status}</Badge></div>
                    {p.status === "CLOSED" && p.closedBy && <div className="text-[10.5px] text-slate-400 mt-1 font-mono">by {p.closedBy}</div>}
                    {canManagePeriods && (
                      <button className={`btn w-full justify-center mt-3 !py-1.5 !text-[11.5px] ${p.status === "CLOSED" ? "btn-ghost" : "btn-danger"}`} onClick={() => togglePeriod(p.period, p.status === "CLOSED" ? "OPEN" : "CLOSED")}>
                        {p.status === "CLOSED" ? "Reopen period" : "Close period"}
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {tab === "tb" && tb && (
            <div className="panel p-5 rise">
              <div className="overflow-x-auto">
                <table className="ledger-table">
                  <thead><tr><th>Account</th><th>Name</th><th>Class</th><th className="!text-right">Debit</th><th className="!text-right">Credit</th></tr></thead>
                  <tbody>
                    {tb.rows.filter((r) => r.debit !== 0 || r.credit !== 0).map((r) => (
                      <tr key={r.code}>
                        <td className="font-mono font-semibold">{r.code}</td>
                        <td>{r.name}</td>
                        <td><Badge tone={r.type === "ASSET" ? "blue" : r.type === "LIABILITY" ? "gold" : r.type === "REVENUE" ? "green" : r.type === "EXPENSE" ? "red" : "slate"}>{r.type}</Badge></td>
                        <td className="text-right font-mono tnum">{r.netDebit ? num(r.netDebit) : ""}</td>
                        <td className="text-right font-mono tnum">{r.netCredit ? num(r.netCredit) : ""}</td>
                      </tr>
                    ))}
                    <tr className="!border-t-2 border-ink font-bold">
                      <td colSpan={3} className="font-display">TOTALS</td>
                      <td className="text-right font-mono tnum border-t-2 border-ink">{num(tb.totalDebit)}</td>
                      <td className="text-right font-mono tnum border-t-2 border-ink">{num(tb.totalCredit)}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <div className="grid sm:grid-cols-3 gap-3 mt-4">
                <div className="bg-[#f6f8f5] rounded-lg p-3"><div className="flabel">Revenue</div><div className="font-mono font-bold text-[16px] tnum text-leaf">{fmt(tb.revenue)}</div></div>
                <div className="bg-[#f6f8f5] rounded-lg p-3"><div className="flabel">Expenses</div><div className="font-mono font-bold text-[16px] tnum text-clay">{fmt(tb.expense)}</div></div>
                <div className="bg-[#f6f8f5] rounded-lg p-3"><div className="flabel">Profit / (Loss)</div><div className={`font-mono font-bold text-[16px] tnum ${tb.profit >= 0 ? "text-leaf" : "text-clay"}`}>{fmt(tb.profit)}</div></div>
              </div>
            </div>
          )}
        </>
      )}

      {detail && (
        <div className="fixed inset-0 z-50 bg-ink/60 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setDetail(null)}>
          <div className="bg-white rounded-xl max-w-2xl w-full p-6 shadow-2xl rise max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-start justify-between">
              <div>
                <div className="font-mono text-[11px] text-slate-500">DOCUMENT {detail.entry.docNumber} · {detail.entry.docType} · {detail.entry.postingDate}</div>
                <h3 className="font-display font-bold text-[17px] mt-0.5">{detail.entry.headerText}</h3>
              </div>
              <button onClick={() => setDetail(null)} className="text-slate-400 hover:text-ink"><X className="w-5 h-5" /></button>
            </div>
            <table className="ledger-table mt-4">
              <thead><tr><th>Account</th><th>Item</th><th>Dr/Cr</th><th className="!text-right">Amount</th></tr></thead>
              <tbody>
                {detail.lines.map((l) => (
                  <tr key={l.id}>
                    <td className="font-mono font-semibold">{l.accountCode}</td>
                    <td className="text-slate-600">{l.itemText}</td>
                    <td><Badge tone={l.side === "D" ? "blue" : "gold"}>{l.side === "D" ? "Debit" : "Credit"}</Badge></td>
                    <td className="text-right font-mono tnum">{fmt(l.amount, client?.currency)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div className="flex justify-between items-center mt-4">
              <Badge tone={detail.entry.status === "REVERSED" ? "red" : "green"}>{detail.entry.status}</Badge>
              {detail.entry.status === "POSTED" && detail.entry.docType !== "AB" && (
                <button className="btn btn-danger" onClick={reverse}><RotateCcw className="w-4 h-4" /> Reverse (FB08)</button>
              )}
            </div>
          </div>
        </div>
      )}

      {modal && (
        <div className="fixed inset-0 z-50 bg-ink/60 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setModal(false)}>
          <div className="bg-white rounded-xl max-w-2xl w-full p-6 shadow-2xl rise max-h-[92vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between">
              <h3 className="font-display font-black text-[18px] flex items-center gap-2"><BookOpenText className="w-5 h-5 text-leaf" /> Manual journal — {cc}</h3>
              <button onClick={() => setModal(false)} className="text-slate-400 hover:text-ink"><X className="w-5 h-5" /></button>
            </div>
            <form onSubmit={postManual} className="mt-4 space-y-3">
              <div className="grid grid-cols-3 gap-3">
                <div><label className="flabel">Posting date</label><input className="field" type="date" required value={form.postingDate} onChange={(e) => setForm({ ...form, postingDate: e.target.value })} /></div>
                <div className="col-span-2"><label className="flabel">Header text</label><input className="field" required value={form.headerText} onChange={(e) => setForm({ ...form, headerText: e.target.value })} placeholder="e.g. February rent accrual" /></div>
              </div>
              <div className="space-y-2">
                {lines.map((l, i) => (
                  <div key={i} className="grid grid-cols-[1fr_90px_130px_32px] gap-2 items-center">
                    <select className="field" value={l.accountCode} onChange={(e) => setLines(lines.map((x, j) => j === i ? { ...x, accountCode: e.target.value } : x))}>
                      {coa.map((a) => <option key={a.code} value={a.code}>{a.code} — {a.name}</option>)}
                    </select>
                    <select className="field" value={l.side} onChange={(e) => setLines(lines.map((x, j) => j === i ? { ...x, side: e.target.value as "D" | "C" } : x))}>
                      <option value="D">Debit</option><option value="C">Credit</option>
                    </select>
                    <input className="field text-right font-mono" type="number" step="0.01" min="0" placeholder="0.00" value={l.amount} onChange={(e) => setLines(lines.map((x, j) => j === i ? { ...x, amount: e.target.value } : x))} />
                    <button type="button" className="text-slate-400 hover:text-clay" onClick={() => setLines(lines.filter((_, j) => j !== i))}><X className="w-4 h-4" /></button>
                  </div>
                ))}
              </div>
              <div className="flex items-center justify-between">
                <button type="button" className="btn btn-ghost !text-[12px]" onClick={() => setLines([...lines, { accountCode: "620000", side: "D", amount: "" }])}><Plus className="w-3.5 h-3.5" /> Add line</button>
                <div className="font-mono text-[12.5px] tnum">
                  Dr <b>{num(drSum)}</b> · Cr <b>{num(crSum)}</b>{" "}
                  {Math.abs(drSum - crSum) < 0.005 && drSum > 0 ? <Badge tone="green">balanced</Badge> : <Badge tone="red">Δ {num(drSum - crSum)}</Badge>}
                </div>
              </div>
              <div className="flex justify-end gap-2">
                <button type="button" className="btn btn-ghost" onClick={() => setModal(false)}>Cancel</button>
                <button className="btn btn-primary" disabled={busy || Math.abs(drSum - crSum) > 0.005 || drSum <= 0}>{busy ? "Posting…" : "Post document"}</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}