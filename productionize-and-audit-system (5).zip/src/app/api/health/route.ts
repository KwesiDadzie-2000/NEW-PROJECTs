import { ensureDatabase } from "@/db/ensure";

export const dynamic = "force-dynamic";

/** Public diagnostic endpoint: reports env var NAMES and deployment identity, never secret values. */
export async function GET() {
  const s = await ensureDatabase();
  const base = { app: s.deployment.app, deployment: s.deployment, node: process.version, checkedAt: new Date().toISOString() };
  if (s.ok) {
    return Response.json({ ok: true, database: "connected", schema: s.bootstrapped ? "created on this boot" : "ready", envVar: s.envVar, ...base });
  }
  return Response.json({ ok: false, code: s.code, error: s.error, hint: s.hint, envVar: s.envVar, similarEnvNames: s.similarEnvNames, ...base }, { status: 503 });
}