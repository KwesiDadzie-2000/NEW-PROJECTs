import { db } from "@/db";
import { bankAccounts, invoices, journalEntries, statementLines, auditLog } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { calcVAT, r2, whtAmount, VAT_WITHHOLD_RATE, type VatTreatment } from "./ghana-tax";
import { postEntry } from "./ledger";
import { getClientByCompany } from "./coa";

// ------------------------------- INVOICES ---------------------------------
export async function createInvoice(input: {
  companyCode: string; kind: "AR" | "AP"; partner: string; invoiceDate: string; dueDate?: string;
  netAmount: number; treatment?: VatTreatment; whtRate?: number; description?: string; createdBy?: string;
}) {
  const client = await getClientByCompany(input.companyCode);
  if (!client) return { ok: false as const, error: `Unknown company code "${input.companyCode}" — invoices must post to a registered client ledger.` };
  if (!(input.netAmount > 0)) return { ok: false as const, error: "Net amount must be positive." };
  const calc = calcVAT(input.netAmount, input.treatment || "STANDARD");
  const rate = input.whtRate ?? 0;
  const wht = whtAmount(calc.base, rate);
  const gross = calc.gross;
  const lines = input.kind === "AR"
    ? [
        { accountCode: "110000", side: "D" as const, amount: gross, itemText: `Receivable — ${input.partner}` },
        { accountCode: "400000", side: "C" as const, amount: calc.base, itemText: "Revenue" },
        ...(calc.leviesTotal > 0 ? [{ accountCode: "220000", side: "C" as const, amount: calc.leviesTotal, itemText: "Output VAT + levies (Act 1151)" }] : []),
      ]
    : [
        { accountCode: "500000", side: "D" as const, amount: calc.base, itemText: `Cost — ${input.partner}` },
        ...(calc.leviesTotal > 0 ? [{ accountCode: "120000", side: "D" as const, amount: calc.leviesTotal, itemText: "Input VAT recoverable (NHIL/GETFund deductible)" }] : []),
        { accountCode: "200000", side: "C" as const, amount: gross, itemText: `Payable — ${input.partner}` },
      ];
  const posted = await postEntry({
    companyCode: input.companyCode, docType: input.kind === "AR" ? "DR" : "KR",
    postingDate: input.invoiceDate, headerText: `${input.kind} invoice — ${input.partner}`,
    reference: input.description || "", lines, source: "INVOICE", createdBy: input.createdBy,
  });
  if (!posted.ok) return posted;
  const all = await db.select().from(invoices).where(eq(invoices.companyCode, input.companyCode));
  const invoiceNo = `${input.kind}-${input.invoiceDate.slice(0, 4)}-${String(all.length + 101)}`;
  const dueDate = input.dueDate || input.invoiceDate;
  const [inv] = await db.insert(invoices).values({
    companyCode: input.companyCode, invoiceNo, kind: input.kind, partner: input.partner,
    invoiceDate: input.invoiceDate, dueDate,
    netAmount: calc.base.toFixed(2), vatAmount: calc.vat.toFixed(2), nhilAmount: calc.nhil.toFixed(2), getfundAmount: calc.getfund.toFixed(2),
    whtRate: rate.toFixed(2), whtAmount: wht.toFixed(2), grossTotal: gross.toFixed(2),
    amountPaid: "0.00", balance: gross.toFixed(2), status: "OPEN", entryId: posted.entry.id,
    description: input.description || "",
  }).returning();
  return { ok: true as const, invoice: inv, docNumber: posted.docNumber, calc };
}

export async function payInvoice(input: {
  invoiceId: number; amount: number; paymentDate: string; applyWht?: boolean; withholdVat?: boolean; createdBy?: string;
}) {
  const [inv] = await db.select().from(invoices).where(eq(invoices.id, input.invoiceId));
  if (!inv) return { ok: false as const, error: "Invoice not found." };
  const balance = Number(inv.balance);
  if (balance < 0.01) return { ok: false as const, error: `Invoice ${inv.invoiceNo} is already fully settled.` };
  const applied = r2(Math.min(input.amount, balance));
  if (!(applied > 0)) return { ok: false as const, error: "Payment amount must be positive." };
  const frac = applied / Number(inv.grossTotal);
  const applyWht = input.applyWht !== false && Number(inv.whtRate) > 0;
  const whtNow = applyWht ? r2(Number(inv.whtAmount) * frac) : 0;
  const levies = r2(Number(inv.vatAmount) + Number(inv.nhilAmount) + Number(inv.getfundAmount));
  const vatWNow = input.withholdVat && levies > 0 ? r2(levies * VAT_WITHHOLD_RATE * frac) : 0;
  const cash = r2(applied - whtNow - vatWNow);
  if (cash < 0) return { ok: false as const, error: "Withholding exceeds payment applied." };

  const lines = inv.kind === "AR"
    ? [
        { accountCode: "100200", side: "D" as const, amount: cash, itemText: `Receipt — ${inv.partner}` },
        ...(whtNow > 0 ? [{ accountCode: "115000", side: "D" as const, amount: whtNow, itemText: `WHT credit certificate (${inv.whtRate}%)` }] : []),
        ...(vatWNow > 0 ? [{ accountCode: "115000", side: "D" as const, amount: vatWNow, itemText: "7% VAT withheld by customer — credit" }] : []),
        { accountCode: "110000", side: "C" as const, amount: applied, itemText: `Clear AR ${inv.invoiceNo}` },
      ]
    : [
        { accountCode: "200000", side: "D" as const, amount: applied, itemText: `Clear AP ${inv.invoiceNo}` },
        ...(cash > 0 ? [{ accountCode: "100200", side: "C" as const, amount: cash, itemText: `Payment — ${inv.partner}` }] : []),
        ...(whtNow > 0 ? [{ accountCode: "225000", side: "C" as const, amount: whtNow, itemText: `WHT payable to GRA (${inv.whtRate}%)` }] : []),
        ...(vatWNow > 0 ? [{ accountCode: "226000", side: "C" as const, amount: vatWNow, itemText: "7% VAT withheld — remit by 15th" }] : []),
      ];
  const posted = await postEntry({
    companyCode: inv.companyCode, docType: inv.kind === "AR" ? "DZ" : "KZ",
    postingDate: input.paymentDate, headerText: `${inv.kind === "AR" ? "Receipt" : "Payment"} — ${inv.partner} (${inv.invoiceNo})`,
    reference: inv.invoiceNo, lines, source: "PAYMENT", createdBy: input.createdBy,
  });
  if (!posted.ok) return posted;
  const newPaid = r2(Number(inv.amountPaid) + applied);
  const newBal = r2(Number(inv.grossTotal) - newPaid);
  const status = newBal < 0.01 ? "PAID" : "PARTIALLY_PAID";
  await db.update(invoices).set({
    amountPaid: newPaid.toFixed(2), balance: Math.max(0, newBal).toFixed(2), status,
    vatWithheld: r2(Number(inv.vatWithheld) + vatWNow).toFixed(2),
  }).where(eq(invoices.id, inv.id));
  return { ok: true as const, docNumber: posted.docNumber, applied, cash, whtNow, vatWNow, status, balance: Math.max(0, newBal) };
}

// ------------------------------- BANKING -----------------------------------
export async function createBankAccount(input: { companyCode: string; bankName: string; sortCode?: string; accountNumber: string; accountName: string; currency?: string }) {
  const client = await getClientByCompany(input.companyCode);
  if (!client) return { ok: false as const, error: "Bank accounts can only be opened under a registered client's own company code." };
  const [acct] = await db.insert(bankAccounts).values({
    companyCode: input.companyCode, bankName: input.bankName, sortCode: input.sortCode || "",
    accountNumber: input.accountNumber, accountName: input.accountName, currency: input.currency || "GHS", glAccount: "100200",
  }).returning();
  await db.insert(auditLog).values({ companyCode: input.companyCode, action: "BANK_CREATE", detail: `${input.bankName} ${input.accountNumber} owned by ${input.companyCode}` });
  return { ok: true as const, account: acct };
}

export function suggestAccount(description: string, isCredit: boolean) {
  const t = description.toLowerCase();
  if (/salary|payroll|wages/.test(t)) return { code: "610000", label: "Salaries & Wages" };
  if (/ssnit/.test(t)) return { code: "231000", label: "SSNIT Payable" };
  if (/paye|income tax/.test(t)) return { code: "230000", label: "PAYE Payable" };
  if (/gra|vat remitt|tax payment/.test(t)) return { code: "220000", label: "VAT / Levies Payable" };
  if (/charge|cot|commission|fee/.test(t)) return { code: "630000", label: "Bank Charges & COT" };
  if (/loan/.test(t)) return { code: "250000", label: "Loans / Borrowings" };
  if (/rent/.test(t)) return { code: "620000", label: "Administrative Expenses" };
  if (isCredit && /sales|receipt|customer|settlement|invoice/.test(t)) return { code: "110000", label: "Clear Trade Receivable" };
  if (!isCredit && /supplier|vendor|purchase/.test(t)) return { code: "200000", label: "Clear Trade Payable" };
  return isCredit ? { code: "410000", label: "Other Operating Income" } : { code: "620000", label: "Administrative Expenses" };
}

export async function importStatement(input: { bankAccountId: number; rows: Array<{ date: string; description: string; debit: number; credit: number }>; createdBy?: string }) {
  const [acct] = await db.select().from(bankAccounts).where(eq(bankAccounts.id, input.bankAccountId));
  if (!acct) return { ok: false as const, error: "Bank account not found." };
  // FIX: the ledger company code comes from the ACCOUNT OWNER (the client),
  // never from bank identifiers found in the statement text.
  const client = await getClientByCompany(acct.companyCode);
  if (!client) return { ok: false as const, error: "Bank account is not linked to a registered client ledger." };
  if (!input.rows?.length) return { ok: false as const, error: "No statement rows supplied." };
  const inserted = [];
  for (const row of input.rows) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(row.date)) return { ok: false as const, error: `Invalid statement date "${row.date}" — use YYYY-MM-DD.` };
    const debit = r2(Number(row.debit || 0));
    const credit = r2(Number(row.credit || 0));
    if (debit <= 0 && credit <= 0) return { ok: false as const, error: `Statement row "${row.description}" has no amount.` };
    if (debit > 0 && credit > 0) return { ok: false as const, error: `Statement row "${row.description}" has both debit and credit.` };
    const sug = suggestAccount(row.description, credit > 0);
    const [line] = await db.insert(statementLines).values({
      bankAccountId: acct.id, lineDate: row.date, description: row.description,
      debit: debit.toFixed(2), credit: credit.toFixed(2), suggestedAccount: sug.code,
    }).returning();
    inserted.push(line);
  }
  await db.insert(auditLog).values({ companyCode: acct.companyCode, actor: input.createdBy || "owner", action: "BANK_IMPORT", detail: `${inserted.length} line(s) for ${acct.accountName} @ ${acct.bankName} → client ledger ${acct.companyCode}` });
  return { ok: true as const, count: inserted.length, companyCode: acct.companyCode };
}

export async function postStatementLine(input: { lineId: number; overrideAccount?: string; createdBy?: string }) {
  const [line] = await db.select().from(statementLines).where(eq(statementLines.id, input.lineId));
  if (!line) return { ok: false as const, error: "Statement line not found." };
  if (line.status === "POSTED") return { ok: false as const, error: "Line already posted to the ledger." };
  const [acct] = await db.select().from(bankAccounts).where(eq(bankAccounts.id, line.bankAccountId));
  const other = input.overrideAccount || line.suggestedAccount;
  if (other === acct.glAccount) return { ok: false as const, error: "Contra account cannot be the bank GL itself — choose the true expense/revenue/AR account." };
  const isCredit = Number(line.credit) > 0;
  const amount = isCredit ? Number(line.credit) : Number(line.debit);
  const posted = await postEntry({
    companyCode: acct.companyCode, // ← owner client, never the bank
    docType: isCredit ? "DZ" : "KZ", postingDate: line.lineDate,
    headerText: `Bank statement — ${line.description}`, reference: `FF67-${line.id}`,
    lines: isCredit
      ? [{ accountCode: acct.glAccount, side: "D", amount, itemText: "Bank inflow" }, { accountCode: other, side: "C", amount, itemText: line.description }]
      : [{ accountCode: other, side: "D", amount, itemText: line.description }, { accountCode: acct.glAccount, side: "C", amount, itemText: "Bank outflow" }],
    source: "BANK", createdBy: input.createdBy,
  });
  if (!posted.ok) return posted;
  await db.update(statementLines).set({ status: "POSTED", entryId: posted.entry.id }).where(eq(statementLines.id, line.id));
  return { ok: true as const, docNumber: posted.docNumber };
}

export async function settleInvoiceFromLine(input: { lineId: number; invoiceId: number; createdBy?: string }) {
  const [line] = await db.select().from(statementLines).where(eq(statementLines.id, input.lineId));
  if (!line) return { ok: false as const, error: "Statement line not found." };
  if (line.status === "POSTED") return { ok: false as const, error: "Line already posted." };
  const [acct] = await db.select().from(bankAccounts).where(eq(bankAccounts.id, line.bankAccountId));
  const [inv] = await db.select().from(invoices).where(and(eq(invoices.id, input.invoiceId), eq(invoices.companyCode, acct.companyCode)));
  if (!inv) return { ok: false as const, error: "Invoice not found in this client's ledger — cross-client settlement is blocked." };
  const amount = Number(line.credit) || Number(line.debit);
  const res = await payInvoice({ invoiceId: inv.id, amount, paymentDate: line.lineDate, createdBy: input.createdBy });
  if (!res.ok) return res;
  await db.update(statementLines).set({ status: "POSTED", entryId: undefined }).where(eq(statementLines.id, line.id));
  return res;
}

export async function listEntries(companyCode?: string) {
  const rows = companyCode
    ? await db.select().from(journalEntries).where(eq(journalEntries.companyCode, companyCode))
    : await db.select().from(journalEntries);
  return rows.sort((a, b) => b.id - a.id);
}