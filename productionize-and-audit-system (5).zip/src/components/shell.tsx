"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState, type ReactNode } from "react";
import {
  LayoutDashboard, Users, ScanSearch, BookOpenText, Landmark, Calculator, ShieldCheck, FlaskConical, Scale, FileBarChart2, KeyRound, LogOut, Loader2,
} from "lucide-react";
import { api } from "@/components/ui";

const NAV = [
  { href: "/", label: "Practice Overview", icon: LayoutDashboard, tcode: "HOME" },
  { href: "/clients", label: "Client Workspaces", icon: Users, tcode: "BPZ-CLI" },
  { href: "/processing", label: "Document Desk", icon: ScanSearch, tcode: "DOC-AI" },
  { href: "/ledger", label: "General Ledger", icon: BookOpenText, tcode: "FB03" },
  { href: "/operations", label: "Billing & Banking", icon: Landmark, tcode: "F-28" },
  { href: "/reports", label: "Financial Statements", icon: FileBarChart2, tcode: "FS01" },
  { href: "/tax", label: "Tax & Payroll", icon: Calculator, tcode: "TX01" },
  { href: "/audit", label: "System Audit", icon: ShieldCheck, tcode: "AUDIT" },
  { href: "/suite", label: "Sector Test Suite", icon: FlaskConical, tcode: "QA-14" },
  { href: "/users", label: "Access Control", icon: KeyRound, tcode: "IAM" },
];

interface Me { id: number; username: string; fullName: string; role: string }
const ROLE_TONE: Record<string, string> = {
  SYSTEM_OWNER: "bg-gold text-ink",
  CONTROLLER: "bg-leaf text-white",
  ACCOUNTANT: "bg-sky-600 text-white",
  AUDITOR: "bg-slate-500 text-white",
};

export default function Shell({ children }: { children: ReactNode }) {
  const path = usePathname();
  const router = useRouter();
  const [me, setMe] = useState<Me | null>(null);
  const [checked, setChecked] = useState(false);
  const [fault, setFault] = useState<{
    code: string; error: string; hint?: string; similarEnvNames?: string[];
    deployment?: { platform: string; environment: string | null; url: string | null; commit: string | null; branch: string | null; repo: string | null };
  } | null>(null);
  const [copied, setCopied] = useState(false);
  const [attempt, setAttempt] = useState(0);
  const isLogin = path === "/login";

  useEffect(() => {
    let alive = true;
    api("/api/auth").then((d) => {
      if (!alive) return;
      if (d.success) { setMe(d.user); setFault(null); }
      else if (d.code === "UNAUTHENTICATED") { setFault(null); if (!isLogin) router.replace("/login"); }
      else setFault({ code: d.code || "UNKNOWN", error: d.error || "The server could not verify your session.", hint: d.hint, similarEnvNames: d.similarEnvNames, deployment: d.deployment });
      setChecked(true);
    });
    return () => { alive = false; };
  }, [path, isLogin, router, attempt]);

  if (fault) {
    const retry = () => { setChecked(false); setFault(null); setAttempt((n) => n + 1); };
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <div className="panel p-7 max-w-xl w-full rise border-l-4 !border-l-clay">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-ink text-gold flex items-center justify-center shrink-0"><Scale className="w-5 h-5" /></div>
            <div>
              <div className="font-mono text-[10px] tracking-[0.25em] text-clay uppercase font-bold">Deployment check failed · {fault.code}</div>
              <h1 className="font-display font-black text-[20px] leading-tight">The ledger can&apos;t reach its database.</h1>
            </div>
          </div>
          <p className="text-[13px] text-slate-700 mt-4 leading-relaxed bg-[#fbeae6] border border-[#efc4bb] rounded-lg p-3 font-mono break-words">{fault.error}</p>

          {fault.deployment && (
            <div className="mt-3 grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px]">
              {[
                ["Environment", fault.deployment.environment],
                ["Commit", fault.deployment.commit],
                ["Branch", fault.deployment.branch],
                ["Repo", fault.deployment.repo],
              ].map(([k, v]) => (
                <div key={k as string} className="bg-[#f6f8f5] rounded-md px-2 py-1.5 min-w-0">
                  <div className="text-[9.5px] uppercase font-extrabold text-slate-400 tracking-wider">{k}</div>
                  <div className="font-mono font-semibold truncate" title={(v as string) || "—"}>{(v as string) || "—"}</div>
                </div>
              ))}
            </div>
          )}
          {fault.deployment?.url && <p className="text-[11px] text-slate-500 mt-1.5 font-mono">Answering deployment: {fault.deployment.url}. The variable must be on <b>this</b> project.</p>}

          {fault.code === "DB_NOT_CONFIGURED" ? (
            <div className="mt-4">
              <div className="font-display font-bold text-[14px] text-ink">Fix in 3 minutes (Vercel)</div>
              <ol className="text-[12.5px] text-slate-700 mt-2 space-y-2 list-decimal pl-5 leading-relaxed">
                <li>Open <b>vercel.com → this project</b> (check that the repo and branch above match), then the <b>Storage</b> tab.</li>
                <li>Click <b>Create Database → Neon (Serverless Postgres)</b> → Continue → choose a region (Frankfurt is closest to Ghana) → <b>Connect</b> to this project with <b>Production</b> and Preview ticked. Vercel then adds the connection variables for you.</li>
                <li>Already have a database? Go to <b>Settings → Environment Variables</b> → Key <code className="font-mono bg-slate-100 px-1 rounded">DATABASE_URL</code> (exactly, all caps) → paste the URL with <b>no quotes</b> → tick <b>Production</b> → Save.</li>
                <li><b>Deployments → ⋯ on the latest → Redeploy.</b> Saving a variable does <i>not</i> update running deployments.</li>
                <li>Press <b>Retry</b>. The app creates its tables and sign-in accounts on first connection, so there&apos;s nothing to migrate.</li>
              </ol>
              {fault.similarEnvNames && fault.similarEnvNames.length > 0 && (
                <div className="mt-3 text-[12px] bg-gold-soft border border-gold/50 rounded-lg p-2.5 text-[#6d5406]">
                  <b>Found on this deployment:</b> <span className="font-mono">{fault.similarEnvNames.join(", ")}</span>. These names don&apos;t match. Rename the one holding your connection string to <span className="font-mono font-bold">DATABASE_URL</span>.
                </div>
              )}
              <div className="mt-3 flex items-center gap-2">
                <code className="font-mono text-[11px] bg-slate-100 border border-slate-200 rounded px-2 py-1 truncate flex-1">postgresql://USER:PASSWORD@ep-xxxx-pooler.eu-central-1.aws.neon.tech/neondb?sslmode=require</code>
                <button className="btn btn-ghost !py-1 !px-2 !text-[11px]" onClick={() => { navigator.clipboard?.writeText("DATABASE_URL"); setCopied(true); setTimeout(() => setCopied(false), 1500); }}>{copied ? "Copied ✓" : "Copy key name"}</button>
              </div>
              <p className="text-[11px] text-slate-500 mt-1">Example format. Use the <b>pooled</b> host (contains <code className="font-mono">-pooler</code>) on Vercel.</p>
            </div>
          ) : (
            fault.hint && <p className="text-[13px] text-slate-700 mt-3 leading-relaxed"><b>How to fix:</b> {fault.hint}</p>
          )}
          <div className="flex flex-wrap gap-2 mt-5">
            <button onClick={retry} className="btn btn-primary">Retry</button>
            <a href="/api/health" target="_blank" rel="noreferrer" className="btn btn-ghost">Open /api/health diagnosis</a>
          </div>
        </div>
      </div>
    );
  }

  const signOut = async () => {
    await api("/api/auth", "POST", { action: "LOGOUT" });
    setMe(null);
    router.replace("/login");
  };

  if (isLogin) return <>{children}</>;
  if (!checked || !me) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-3 text-slate-500">
        <div className="w-11 h-11 rounded-xl bg-ink text-gold flex items-center justify-center"><Scale className="w-5 h-5" /></div>
        <div className="flex items-center gap-2 text-[13px] font-semibold"><Loader2 className="w-4 h-4 animate-spin text-leaf" /> Verifying session…</div>
      </div>
    );
  }

  const initials = me.fullName.split(/\s+/).slice(0, 2).map((w) => w[0]).join("").toUpperCase();

  return (
    <div className="min-h-screen lg:flex">
      <aside className="lg:w-60 lg:min-h-screen lg:fixed lg:inset-y-0 text-white flex flex-col z-40" style={{ background: "linear-gradient(180deg, #0d1f17 0%, #102419 70%, #0c1d15 100%)" }}>
        <div className="px-5 pt-6 pb-5 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gold text-ink flex items-center justify-center shadow-lg shadow-black/30">
              <Scale className="w-5 h-5" strokeWidth={2.4} />
            </div>
            <div>
              <div className="font-display font-black text-[17px] tracking-tight leading-none">BPZ FISCAL</div>
              <div className="text-[10px] font-mono text-gold/90 tracking-[0.25em] mt-1">CLIENT LEDGER</div>
            </div>
          </div>
          <div className="mt-4 flex items-center gap-2 text-[11px] text-emerald-200/70">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 pulse-dot" />
            PostgreSQL · authenticated session
          </div>
        </div>
        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto grid grid-cols-2 gap-1 lg:block lg:space-y-1">
          {NAV.map((n) => {
            const active = path === n.href;
            return (
              <Link key={n.href} href={n.href} className={`navlink ${active ? "active" : ""}`}>
                <n.icon className="w-4 h-4 shrink-0" strokeWidth={2.2} />
                <span className="flex-1">{n.label}</span>
                <span className={`hidden lg:inline font-mono text-[9px] ${active ? "text-ink/60" : "text-white/25"}`}>{n.tcode}</span>
              </Link>
            );
          })}
        </nav>
        <div className="px-4 py-4 border-t border-white/10">
          <div className="flex items-center gap-2.5">
            <span className="w-9 h-9 rounded-lg bg-white/10 border border-white/15 flex items-center justify-center font-display font-bold text-[12px] text-gold shrink-0">{initials}</span>
            <div className="min-w-0 flex-1">
              <div className="text-[12px] font-bold truncate">{me.fullName.split("(")[0].trim()}</div>
              <span className={`inline-block text-[8.5px] font-black tracking-wider px-1.5 py-px rounded mt-0.5 ${ROLE_TONE[me.role] || "bg-slate-500"}`}>{me.role.replace("_", " ")}</span>
            </div>
            <button onClick={signOut} title="Sign out" className="p-2 rounded-lg text-white/50 hover:text-white hover:bg-white/10 transition cursor-pointer"><LogOut className="w-4 h-4" /></button>
          </div>
          <div className="hidden lg:block mt-3 text-[10px] leading-relaxed text-white/35">
            VAT Act 1151 · PAYE Act 1178 · SSNIT 5.5/13% · SoD enforced
          </div>
        </div>
      </aside>
      <main className="flex-1 lg:ml-60 min-w-0">
        <div className="max-w-[1240px] mx-auto px-4 sm:px-6 py-6">{children}</div>
      </main>
    </div>
  );
}