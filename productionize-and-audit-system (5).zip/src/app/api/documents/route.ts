import { db } from "@/db";
import { processedDocs } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { extractDocument, SAMPLE_DOCS } from "@/lib/server/extract";
import { postEntry } from "@/lib/server/ledger";
import { requireUser, POSTING_ROLES } from "@/lib/server/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  const auth = await requireUser();
  if (auth instanceof Response) return auth;
  const docs = await db.select().from(processedDocs).orderBy(desc(processedDocs.id)).limit(50);
  return Response.json({ success: true, docs, samples: SAMPLE_DOCS });
}

export async function POST(req: Request) {
  const auth = await requireUser(POSTING_ROLES);
  if (auth instanceof Response) return auth;
  const body = await req.json().catch(() => ({}));
  if (body.action === "ANALYZE") {
    if (!body.text || String(body.text).trim().length < 10) return Response.json({ success: false, error: "Paste the document text first (at least 10 characters)." }, { status: 400 });
    const extraction = await extractDocument(String(body.text));
    const [doc] = await db.insert(processedDocs).values({
      companyCode: extraction.companyCode, docType: extraction.docType, sourceText: String(body.text),
      extraction, confidence: extraction.confidence, status: "EXTRACTED",
    }).returning();
    return Response.json({ success: true, doc, extraction });
  }
  if (body.action === "POST") {
    const [doc] = await db.select().from(processedDocs).where(eq(processedDocs.id, Number(body.docId)));
    if (!doc) return Response.json({ success: false, error: "Processed document not found." }, { status: 404 });
    if (doc.status === "POSTED") return Response.json({ success: false, error: "Document already posted to the ledger." }, { status: 400 });
    const companyCode = body.companyCode || doc.companyCode;
    if (!companyCode) return Response.json({ success: false, error: "Resolve a client company code before posting — the system never guesses." }, { status: 400 });
    const ex = doc.extraction as Awaited<ReturnType<typeof extractDocument>>;
    const lines = (body.lines || ex.suggestedLines) as Array<{ accountCode: string; side: "D" | "C"; amount: number; itemText?: string }>;
    if (!lines?.length) return Response.json({ success: false, error: "No posting lines suggested — create the entry manually in the Ledger desk." }, { status: 400 });
    const res = await postEntry({
      companyCode, docType: ex.docType === "TAX_INVOICE" ? "DR" : "DZ",
      postingDate: body.postingDate || ex.date || "2026-02-15",
      headerText: `${ex.docType.replace(/_/g, " ")} — ${ex.partner || ex.clientName || "processed document"}`,
      reference: `DOC-${doc.id}`, lines, source: "DOCUMENT", createdBy: auth.username,
    });
    if (!res.ok) return Response.json({ success: false, error: res.error }, { status: 400 });
    await db.update(processedDocs).set({ status: "POSTED", companyCode, entryId: res.entry.id }).where(eq(processedDocs.id, doc.id));
    return Response.json({ success: true, docNumber: res.docNumber, message: `Posted ${res.docNumber} to client ledger ${companyCode}.` });
  }
  if (body.action === "REJECT") {
    await db.update(processedDocs).set({ status: "REJECTED" }).where(eq(processedDocs.id, Number(body.docId)));
    return Response.json({ success: true });
  }
  return Response.json({ success: false, error: "Unknown action." }, { status: 400 });
}