import Link from "next/link";
import { FileQuestion, ArrowLeft } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-[70vh] flex items-center justify-center p-6">
      <div className="panel p-8 max-w-md w-full text-center rise">
        <div className="mx-auto w-12 h-12 rounded-xl bg-leaf-soft text-leaf flex items-center justify-center"><FileQuestion className="w-6 h-6" /></div>
        <div className="font-mono text-[10px] tracking-[0.25em] text-slate-400 uppercase mt-4">FB03 · Document not found</div>
        <h1 className="font-display font-black text-[24px] mt-1">No such page in the ledger.</h1>
        <p className="text-[13px] text-slate-600 mt-2">The reference you followed doesn't exist — it may have been reversed, or never posted at all.</p>
        <Link href="/" className="btn btn-primary mt-5 mx-auto"><ArrowLeft className="w-4 h-4" /> Back to the practice</Link>
      </div>
    </div>
  );
}