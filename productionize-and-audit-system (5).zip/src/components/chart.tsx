"use client";

import { useEffect, useRef } from "react";
import { Chart, registerables, type ChartConfiguration } from "chart.js";

Chart.register(...registerables);
Chart.defaults.font.family = "'IBM Plex Mono', monospace";
Chart.defaults.font.size = 10.5;
Chart.defaults.color = "#5c6f63";

/** Thin Chart.js wrapper — creates on mount, destroys on unmount/config change. */
export default function ChartCanvas({ config, height = 250 }: { config: ChartConfiguration; height?: number }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    if (!ref.current) return;
    const chart = new Chart(ref.current, config);
    return () => chart.destroy();
  }, [config]);
  return (
    <div style={{ height, position: "relative" }}>
      <canvas ref={ref} />
    </div>
  );
}