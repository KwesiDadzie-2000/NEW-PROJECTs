"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import type { ChartConfiguration } from "chart.js";
import { BookOpenText, ScanSearch, ShieldCheck, FlaskConical, Users, Sparkles, ArrowRight, Landmark, FileText, TrendingUp, PieChart } from "lucide-react";
import { PageHead, Stat, Badge, useClients, useToast, fmt, api, Busy, Empty } from "@/components/ui";
import ChartCanvas from "@/components/chart";

interface Entry { id: number; companyCode: string; docNumber: string; docType: string; postingDate: string; headerText: string; totalDebit: string; status: string; source: string }
interface Insights {
  series: Array<{ month: string; revenue: number; expense: number; profit: number }>;
  byClient: Array<{ companyCode: string; name: string; sector: string; revenue: number; openAr: number }>;
}
const PALETTE = ["#14684b", "#d9a514", "#0e7490", "#c2402a", "#6d28d9", "#4d7c0f", "#be185d"];

export default function Dashboard() {
  const { clients, loading, reload } = useClients();
  const [entries, setEntries] = useState<Entry[]>([]);
  const [auditScore, setAuditScore] = useState<number | null>(null);
  const [seeding, setSeeding] = useState(false);
  const [insights, setInsights] = useState<Insights | null>(null);
  const toast = useToast();

  const loadExtras = async () => {
    const [j, a, ins] = await Promise.all([api("/api/journal"), api("/api/audit"), api("/api/insights")]);
    if (j.success) setEntries(j.entries.slice(0, 8));
    if (a.success) setAuditScore(a.score);
    if (ins.success) setInsights(ins);
  };

  const perfConfig = useMemo<ChartConfiguration | null>(() => {
    if (!insights?.series.length) return null;
    const labels = insights.series.map((s) => s.month);
    return {
      type: "bar",
      data: {
        labels,
        datasets: [
          { label: "Revenue", data: insights.series.map((s) => s.revenue), backgroundColor: "#14684b", borderRadius: 4, maxBarThickness: 34 },
          { label: "Expenses", data: insights.series.map((s) => s.expense), backgroundColor: "#c2402a", borderRadius: 4, maxBarThickness: 34 },
          { label: "Profit", data: insights.series.map((s) => s.profit), type: "line" as const, borderColor: "#d9a514", backgroundColor: "#d9a514", borderWidth: 2.5, pointRadius: 4, pointHoverRadius: 6, tension: 0.35 },
        ],
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        interaction: { mode: "index", intersect: false },
        plugins: { legend: { position: "bottom", labels: { boxWidth: 10, boxHeight: 10, usePointStyle: true } }, tooltip: { backgroundColor: "#0d1f17", padding: 10, callbacks: { label: (c) => ` ${c.dataset.label}: GH₵ ${Number(c.raw).toLocaleString("en-GH", { minimumFractionDigits: 2 })}` } } },
        scales: { x: { grid: { display: false } }, y: { grid: { color: "#eef2ec" }, ticks: { callback: (v) => `${Number(v) / 1000}k` } } },
      },
    };
  }, [insights]);

  const mixConfig = useMemo<ChartConfiguration | null>(() => {
    const rows = (insights?.byClient || []).filter((c) => c.revenue > 0);
    if (!rows.length) return null;
    return {
      type: "doughnut",
      data: {
        labels: rows.map((c) => `${c.companyCode} · ${c.sector}`),
        datasets: [{ data: rows.map((c) => c.revenue), backgroundColor: rows.map((_, i) => PALETTE[i % PALETTE.length]), borderColor: "#ffffff", borderWidth: 3, hoverOffset: 8 }],
      },
      options: {
        responsive: true, maintainAspectRatio: false, cutout: "62%",
        plugins: { legend: { position: "bottom", labels: { boxWidth: 10, boxHeight: 10, usePointStyle: true } }, tooltip: { backgroundColor: "#0d1f17", padding: 10, callbacks: { label: (c) => ` GH₵ ${Number(c.raw).toLocaleString("en-GH", { minimumFractionDigits: 2 })}` } } },
      },
    };
  }, [insights]);
  useEffect(() => { loadExtras(); }, [clients.length]);

  const seed = async () => {
    setSeeding(true);
    const d = await api("/api/clients", "POST", { action: "SEED_DEMO" });
    setSeeding(false);
    if (d.success) { toast.ok(d.message); reload(); loadExtras(); } else toast.err(d.error);
  };

  const totalDocs = clients.reduce((t, c) => t + (c.documents || 0), 0);
  const totalAr = clients.reduce((t, c) => t + (c.openAr || 0), 0);
  const totalAp = clients.reduce((t, c) => t + (c.openAp || 0), 0);
  const allBalanced = clients.every((c) => c.balanced !== false);

  return (
    <div>
      {toast.node}
      <PageHead
        tcode="Practice Overview"
        title="The books, at a glance."
        sub="Every client keeps an exclusive company code and an isolated double-entry ledger in PostgreSQL. Bank codes are counterparty metadata — they can never own a ledger."
        actions={
          <>
            <Link href="/processing" className="btn btn-gold"><ScanSearch className="w-4 h-4" /> Process a document</Link>
            <Link href="/clients" className="btn btn-primary"><Users className="w-4 h-4" /> New client</Link>
          </>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <Stat label="Client ledgers" value={clients.length} note="unique company codes" delay="rise-1" />
        <Stat label="Posted documents" value={totalDocs} note={allBalanced ? "all trial balances ✓ balanced" : "⚠ imbalance detected"} tone={allBalanced ? "text-leaf" : "text-clay"} delay="rise-2" />
        <Stat label="Receivables open" value={fmt(totalAr)} note="AR across the practice" tone="text-ink" delay="rise-3" />
        <Stat label="System audit" value={auditScore == null ? "…" : `${auditScore}%`} note="integrity score" tone={auditScore === 100 ? "text-leaf" : "text-[#8a6a08]"} delay="rise-4" />
      </div>

      {!loading && clients.length === 0 ? (
        <div className="mt-5">
          <Empty
            icon={<Sparkles className="w-5 h-5" />}
            title="No client ledgers yet"
            sub="Create your first real client, or load a demo practice (3 sector clients with opening capital and live invoices) to explore the document desk, tax engine and audit station."
            action={<button className="btn btn-gold" onClick={seed} disabled={seeding}><Sparkles className="w-4 h-4" /> {seeding ? "Provisioning ledgers…" : "Load demo practice"}</button>}
          />
        </div>
      ) : (
        <>
        {(perfConfig || mixConfig) && (
          <div className="grid lg:grid-cols-5 gap-4 mt-5">
            <div className="lg:col-span-3 panel p-5 rise rise-1">
              <div className="flex items-center justify-between mb-3">
                <h2 className="font-display font-bold text-[15px] text-ink flex items-center gap-2"><TrendingUp className="w-4 h-4 text-leaf" /> Practice performance</h2>
                <span className="text-[11px] font-mono text-slate-400">posted documents only · GHS</span>
              </div>
              {perfConfig ? <ChartCanvas config={perfConfig} height={250} /> : <p className="text-[13px] text-slate-500 py-8 text-center">Post revenue documents to see the trend.</p>}
            </div>
            <div className="lg:col-span-2 panel p-5 rise rise-2">
              <div className="flex items-center justify-between mb-3">
                <h2 className="font-display font-bold text-[15px] text-ink flex items-center gap-2"><PieChart className="w-4 h-4 text-leaf" /> Revenue mix by client</h2>
              </div>
              {mixConfig ? <ChartCanvas config={mixConfig} height={250} /> : <p className="text-[13px] text-slate-500 py-8 text-center">No revenue posted yet.</p>}
            </div>
          </div>
        )}
        <div className="grid lg:grid-cols-5 gap-4 mt-5">
          <div className="lg:col-span-3 panel p-5 rise rise-2">
            <div className="flex items-center justify-between mb-3">
              <h2 className="font-display font-bold text-[15px] text-ink flex items-center gap-2"><FileText className="w-4 h-4 text-leaf" /> Latest postings</h2>
              <Link href="/ledger" className="text-[12px] font-bold text-leaf hover:underline flex items-center gap-1">General Ledger <ArrowRight className="w-3 h-3" /></Link>
            </div>
            {loading ? <Busy /> : entries.length === 0 ? <p className="text-[13px] text-slate-500 py-6 text-center">No documents posted yet.</p> : (
              <table className="ledger-table">
                <thead><tr><th>Doc #</th><th>Ledger</th><th>Narration</th><th>Type</th><th className="!text-right">Amount</th></tr></thead>
                <tbody>
                  {entries.map((e) => (
                    <tr key={e.id}>
                      <td className="font-mono font-semibold">{e.docNumber}</td>
                      <td><Badge tone="blue">{e.companyCode}</Badge></td>
                      <td className="max-w-[260px]"><div className="truncate">{e.headerText}</div><div className="text-[11px] text-slate-400">{e.postingDate} · {e.source}</div></td>
                      <td><Badge tone={e.status === "REVERSED" ? "red" : "slate"}>{e.docType}</Badge></td>
                      <td className="text-right font-mono tnum font-semibold">{fmt(e.totalDebit)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
          <div className="lg:col-span-2 space-y-3">
            {[
              { href: "/processing", icon: ScanSearch, title: "Document Desk", desc: "Company-code resolution that never confuses a bank's sort code with the client's ledger.", tone: "bg-gold-soft text-[#8a6a08]" },
              { href: "/operations", icon: Landmark, title: "Billing & Banking", desc: "AR/AP with Act 1151 levies, WHT, 7% VAT withholding, statement import & settlement.", tone: "bg-leaf-soft text-leaf" },
              { href: "/audit", icon: ShieldCheck, title: "System Audit", desc: "11 integrity checks: routing, parity, reversals, SoD, period locks and code ownership.", tone: "bg-sky-50 text-sky-800" },
              { href: "/suite", icon: FlaskConical, title: "Sector Test Suite", desc: "A standard transaction cycle across all 14 sectors, run on isolated QA ledgers.", tone: "bg-[#fbeae6] text-[#a33322]" },
            ].map((c, i) => (
              <Link key={c.href} href={c.href} className={`panel panel-hover p-4 flex gap-3 rise rise-${i + 1}`}>
                <span className={`w-10 h-10 rounded-lg flex items-center justify-center shrink-0 ${c.tone}`}><c.icon className="w-5 h-5" /></span>
                <span>
                  <span className="font-display font-bold text-[14px] text-ink flex items-center gap-1.5">{c.title} <ArrowRight className="w-3.5 h-3.5 text-slate-400" /></span>
                  <span className="block text-[12.5px] text-slate-600 mt-0.5 leading-relaxed">{c.desc}</span>
                </span>
              </Link>
            ))}
          </div>
        </div>
        </>
      )}

      {clients.length > 0 && (
        <div className="panel p-5 mt-4 rise rise-3">
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-display font-bold text-[15px] text-ink flex items-center gap-2"><BookOpenText className="w-4 h-4 text-leaf" /> Client ledgers</h2>
            <span className="text-[12px] text-slate-500">Open AP: <b className="font-mono">{fmt(totalAp)}</b></span>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {clients.map((c) => (
              <Link href="/ledger" key={c.id} className="panel panel-hover p-4">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-[12px] font-bold text-leaf">{c.companyCode}</span>
                  <Badge tone={c.status === "ACTIVE" ? "green" : c.status === "SUSPENDED" ? "red" : "gold"}>{c.status}</Badge>
                </div>
                <div className="font-display font-bold text-[14.5px] text-ink mt-1.5 leading-snug">{c.businessName}</div>
                <div className="text-[11.5px] text-slate-500 mt-0.5">{c.sector} · {c.documents} docs · TB {c.balanced ? "✓" : "✗"}</div>
                <div className="mt-2 flex justify-between text-[12px] font-mono tnum">
                  <span className="text-slate-500">AR open</span><span className="font-bold">{fmt(c.openAr || 0, c.currency)}</span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}