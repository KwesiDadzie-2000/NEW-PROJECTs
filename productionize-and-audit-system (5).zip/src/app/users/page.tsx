"use client";

import { useCallback, useEffect, useState } from "react";
import { KeyRound, Plus, ShieldCheck, UserCog, X, Lock } from "lucide-react";
import { PageHead, useToast, api, Badge, Busy, Notice } from "@/components/ui";

interface UserRow { id: number; username: string; fullName: string; role: string; status: string; lastLogin: string | null; createdAt: string }
const ROLE_DESC: Record<string, string> = {
  SYSTEM_OWNER: "Everything, plus user management. Cannot demote self.",
  CONTROLLER: "Posting + reversals + period close/reopen + QA suite.",
  ACCOUNTANT: "Posting documents, invoices, payments and banking. No reversals or period control.",
  AUDITOR: "Read-only across all ledgers, statements and the audit trail.",
};
const ROLE_TONE: Record<string, "gold" | "green" | "blue" | "slate"> = { SYSTEM_OWNER: "gold", CONTROLLER: "green", ACCOUNTANT: "blue", AUDITOR: "slate" };

export default function UsersPage() {
  const toast = useToast();
  const [users, setUsers] = useState<UserRow[]>([]);
  const [canManage, setCanManage] = useState(false);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState(false);
  const [reset, setReset] = useState<UserRow | null>(null);
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({ username: "", fullName: "", role: "ACCOUNTANT", password: "" });
  const [newPw, setNewPw] = useState("");
  const [pwModal, setPwModal] = useState(false);
  const [pwForm, setPwForm] = useState({ currentPassword: "", newPassword: "", confirm: "" });
  const [pwBusy, setPwBusy] = useState(false);

  const changeOwn = async (e: React.FormEvent) => {
    e.preventDefault();
    if (pwForm.newPassword !== pwForm.confirm) { toast.err("New password and confirmation do not match."); return; }
    setPwBusy(true);
    const d = await api("/api/auth", "POST", { action: "CHANGE_PASSWORD", currentPassword: pwForm.currentPassword, newPassword: pwForm.newPassword });
    setPwBusy(false);
    if (d.success) { toast.ok("Password changed. Use it at your next sign-in."); setPwModal(false); setPwForm({ currentPassword: "", newPassword: "", confirm: "" }); }
    else toast.err(d.error);
  };

  const load = useCallback(async () => {
    setLoading(true);
    const d = await api("/api/users");
    if (d.success) { setUsers(d.users); setCanManage(d.canManage); }
    setLoading(false);
  }, []);
  useEffect(() => { load(); }, [load]);

  const act = async (body: Record<string, unknown>, okMsg: string) => {
    setBusy(true);
    const d = await api("/api/users", "PUT", body);
    setBusy(false);
    if (d.success) { toast.ok(okMsg); setModal(false); setReset(null); setNewPw(""); load(); }
    else toast.err(d.error);
  };

  return (
    <div>
      {toast.node}
      <PageHead
        tcode="IAM · Access Control"
        title="Who may touch the books."
        sub="scrypt-hashed credentials, 12-hour httpOnly sessions, four roles, and hard segregation of duties: the preparer of a document can never reverse it."
        actions={<>
          <button className="btn btn-ghost" onClick={() => setPwModal(true)}><Lock className="w-4 h-4" /> Change my password</button>
          {canManage && <button className="btn btn-primary" onClick={() => setModal(true)}><Plus className="w-4 h-4" /> Add user</button>}
        </>}
      />

      {pwModal && (
        <div className="fixed inset-0 z-50 bg-ink/60 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setPwModal(false)}>
          <div className="bg-white rounded-xl max-w-sm w-full p-6 shadow-2xl rise" onClick={(e) => e.stopPropagation()}>
            <div className="flex justify-between items-center"><h3 className="font-display font-black text-[17px]">Change my password</h3><button onClick={() => setPwModal(false)} className="text-slate-400 hover:text-ink"><X className="w-5 h-5" /></button></div>
            <form className="space-y-3 mt-4" onSubmit={changeOwn}>
              <div><label className="flabel">Current password</label><input className="field" type="password" required value={pwForm.currentPassword} onChange={(e) => setPwForm({ ...pwForm, currentPassword: e.target.value })} /></div>
              <div><label className="flabel">New password (min 10, letters + numbers)</label><input className="field" type="password" required value={pwForm.newPassword} onChange={(e) => setPwForm({ ...pwForm, newPassword: e.target.value })} /></div>
              <div><label className="flabel">Confirm new password</label><input className="field" type="password" required value={pwForm.confirm} onChange={(e) => setPwForm({ ...pwForm, confirm: e.target.value })} /></div>
              <button className="btn btn-primary w-full justify-center" disabled={pwBusy}>{pwBusy ? "Changing…" : "Change password"}</button>
            </form>
          </div>
        </div>
      )}

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
        {Object.entries(ROLE_DESC).map(([role, desc], i) => (
          <div key={role} className={`panel panel-hover p-4 rise rise-${i + 1}`}>
            <Badge tone={ROLE_TONE[role]}>{role.replace("_", " ")}</Badge>
            <p className="text-[12px] text-slate-600 mt-2 leading-relaxed">{desc}</p>
          </div>
        ))}
      </div>

      {!canManage && <div className="mb-4"><Notice kind="info">You have read-only visibility of the access register. Only the System Owner can create users, change roles or reset passwords.</Notice></div>}

      <div className="panel p-5 rise rise-2">
        {loading ? <Busy /> : (
          <div className="overflow-x-auto">
            <table className="ledger-table">
              <thead><tr><th>User</th><th>Username</th><th>Role</th><th>Status</th><th>Last sign-in</th>{canManage && <th>Actions</th>}</tr></thead>
              <tbody>
                {users.map((u) => (
                  <tr key={u.id}>
                    <td className="font-bold">{u.fullName}</td>
                    <td className="font-mono text-[12px]">{u.username}</td>
                    <td>
                      {canManage ? (
                        <select className="field !w-auto !py-1 !px-2 !text-[11.5px] font-bold" value={u.role} onChange={(e) => act({ action: "SET_ROLE", userId: u.id, role: e.target.value }, `${u.username} → ${e.target.value}`)}>
                          {Object.keys(ROLE_DESC).map((r) => <option key={r}>{r}</option>)}
                        </select>
                      ) : <Badge tone={ROLE_TONE[u.role] || "slate"}>{u.role.replace("_", " ")}</Badge>}
                    </td>
                    <td><Badge tone={u.status === "ACTIVE" ? "green" : "red"}>{u.status}</Badge></td>
                    <td className="font-mono text-[11.5px] text-slate-500">{u.lastLogin ? new Date(u.lastLogin).toLocaleString("en-GB") : "never"}</td>
                    {canManage && (
                      <td>
                        <div className="flex gap-1.5">
                          <button className="btn btn-ghost !px-2 !py-1 !text-[11px]" onClick={() => setReset(u)} title="Reset password (also clears any lockout)"><Lock className="w-3 h-3" /> Password</button>
                          <button className={`btn !px-2 !py-1 !text-[11px] ${u.status === "ACTIVE" ? "btn-danger" : "btn-primary"}`} onClick={() => act({ action: "SET_STATUS", userId: u.id, status: u.status === "ACTIVE" ? "DISABLED" : "ACTIVE" }, `${u.username} ${u.status === "ACTIVE" ? "disabled" : "activated"}`)}>
                            <UserCog className="w-3 h-3" /> {u.status === "ACTIVE" ? "Disable" : "Activate"}
                          </button>
                        </div>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        <div className="mt-4 flex items-start gap-2 text-[12px] text-slate-500 bg-[#f6f8f5] rounded-lg p-3">
          <ShieldCheck className="w-4 h-4 text-leaf shrink-0 mt-0.5" />
          Every user management action, sign-in and sign-out is written to the immutable audit trail. Passwords are stored as scrypt salt:hash — plaintext never touches the database.
        </div>
      </div>

      {modal && (
        <div className="fixed inset-0 z-50 bg-ink/60 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setModal(false)}>
          <div className="bg-white rounded-xl max-w-md w-full p-6 shadow-2xl rise" onClick={(e) => e.stopPropagation()}>
            <div className="flex justify-between items-center"><h3 className="font-display font-black text-[18px] flex items-center gap-2"><KeyRound className="w-5 h-5 text-leaf" /> Add practice user</h3><button onClick={() => setModal(false)} className="text-slate-400 hover:text-ink"><X className="w-5 h-5" /></button></div>
            <form className="space-y-3 mt-4" onSubmit={(e) => { e.preventDefault(); act({ action: "CREATE", ...form }, `User ${form.username} created.`); }}>
              <div><label className="flabel">Full name</label><input className="field" required value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} /></div>
              <div><label className="flabel">Username</label><input className="field font-mono" required value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} placeholder="a-z 0-9 _ ." /></div>
              <div><label className="flabel">Role</label><select className="field" value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })}>{Object.keys(ROLE_DESC).map((r) => <option key={r}>{r}</option>)}</select></div>
              <div><label className="flabel">Password (min 10 chars, letters + numbers)</label><input className="field" type="password" required value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} /></div>
              <button className="btn btn-primary w-full justify-center" disabled={busy}>{busy ? "Creating…" : "Create user"}</button>
            </form>
          </div>
        </div>
      )}

      {reset && (
        <div className="fixed inset-0 z-50 bg-ink/60 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setReset(null)}>
          <div className="bg-white rounded-xl max-w-sm w-full p-6 shadow-2xl rise" onClick={(e) => e.stopPropagation()}>
            <h3 className="font-display font-black text-[17px]">Reset password — {reset.username}</h3>
            <form className="space-y-3 mt-4" onSubmit={(e) => { e.preventDefault(); act({ action: "RESET_PASSWORD", userId: reset.id, password: newPw }, `Password reset for ${reset.username}.`); }}>
              <div><label className="flabel">New password</label><input className="field" type="password" required value={newPw} onChange={(e) => setNewPw(e.target.value)} placeholder="min 10 chars, letters + numbers" /></div>
              <button className="btn btn-primary w-full justify-center" disabled={busy}>{busy ? "Resetting…" : "Reset password"}</button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}