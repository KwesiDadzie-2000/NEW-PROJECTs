import { db } from "@/db";
import { invoices } from "@/db/schema";
import { eq } from "drizzle-orm";
import { createInvoice, payInvoice } from "@/lib/server/operations";
import { GH_WHT_RATES } from "@/lib/server/ghana-tax";
import { requireUser, POSTING_ROLES } from "@/lib/server/auth";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const auth = await requireUser();
  if (auth instanceof Response) return auth;
  const cc = new URL(req.url).searchParams.get("companyCode");
  const rows = cc ? await db.select().from(invoices).where(eq(invoices.companyCode, cc)) : await db.select().from(invoices);
  return Response.json({ success: true, invoices: rows.sort((a, b) => b.id - a.id), whtRates: GH_WHT_RATES });
}

export async function POST(req: Request) {
  const auth = await requireUser(POSTING_ROLES);
  if (auth instanceof Response) return auth;
  const body = await req.json().catch(() => ({}));
  if (body.action === "PAY") {
    const res = await payInvoice({ invoiceId: Number(body.invoiceId), amount: Number(body.amount), paymentDate: body.paymentDate, applyWht: body.applyWht, withholdVat: body.withholdVat, createdBy: auth.username });
    return Response.json(res.ok ? { success: true, ...res } : { success: false, error: res.error }, { status: res.ok ? 200 : 400 });
  }
  const res = await createInvoice({
    companyCode: body.companyCode, kind: body.kind, partner: body.partner, invoiceDate: body.invoiceDate,
    dueDate: body.dueDate, netAmount: Number(body.netAmount), treatment: body.treatment, whtRate: Number(body.whtRate ?? 0),
    description: body.description, createdBy: auth.username,
  });
  return Response.json(res.ok ? { success: true, invoice: res.invoice, docNumber: res.docNumber, calc: res.calc } : { success: false, error: res.error }, { status: res.ok ? 200 : 400 });
}