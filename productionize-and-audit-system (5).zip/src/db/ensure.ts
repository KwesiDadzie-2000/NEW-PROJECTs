import { pool, dbConfigError, databaseEnvVar, similarEnvNames, deploymentInfo } from "./index";
import { BOOTSTRAP_SQL } from "./bootstrap-sql";

type Diag = { envVar: string | null; similarEnvNames: string[]; deployment: typeof deploymentInfo };
export type DbStatus =
  | ({ ok: true; bootstrapped: boolean } & Diag)
  | ({ ok: false; code: "DB_NOT_CONFIGURED" | "DB_UNREACHABLE" | "DB_SCHEMA_FAILED"; error: string; hint: string } & Diag);

const g = globalThis as typeof globalThis & { __bpzSchemaReady?: Promise<DbStatus> };
const diag = (): Diag => ({ envVar: databaseEnvVar, similarEnvNames, deployment: deploymentInfo });

function classify(err: unknown): { code: "DB_UNREACHABLE" | "DB_SCHEMA_FAILED"; error: string; hint: string } {
  const e = err as { code?: string; message?: string };
  const msg = e?.message || String(err);
  if (["ECONNREFUSED", "ENOTFOUND", "ETIMEDOUT", "EAI_AGAIN", "28P01", "28000", "3D000"].includes(e?.code || "") || /timeout|password authentication|does not exist|getaddrinfo|SSL|self.signed|certificate|ENOTFOUND/i.test(msg)) {
    return {
      code: "DB_UNREACHABLE",
      error: msg,
      hint: "The connection string was found, but the database rejected or could not be reached. Re-copy it from your provider. On Vercel use the POOLED URL (Neon host containing '-pooler', or Supabase port 6543) with ?sslmode=require. Check that the database is not paused.",
    };
  }
  return { code: "DB_SCHEMA_FAILED", error: msg, hint: "Connected, but creating tables failed. Give the database user CREATE privileges, or run `npx drizzle-kit migrate` once against this database." };
}

async function run(): Promise<DbStatus> {
  if (dbConfigError) {
    const platformHint = deploymentInfo.platform === "netlify"
      ? "Netlify → Site configuration → Environment variables → add DATABASE_URL → Deploys → Trigger deploy (clear cache)."
      : "Vercel → this project → Storage → Create/Connect a Neon database (injects the variable automatically), OR Settings → Environment Variables → add DATABASE_URL with Production ticked. Then Deployments → ⋯ → Redeploy. Variables only apply to NEW deployments.";
    return { ok: false, code: "DB_NOT_CONFIGURED", error: dbConfigError, hint: platformHint, ...diag() };
  }
  try {
    const { rows } = await pool.query<{ exists: boolean }>("select to_regclass('public.users') is not null as exists");
    const hadUsers = rows[0]?.exists === true;
    for (const stmt of BOOTSTRAP_SQL) await pool.query(stmt);
    return { ok: true, bootstrapped: !hadUsers, ...diag() };
  } catch (err) {
    return { ...classify(err), ok: false, ...diag() };
  }
}

/** Ensure the database is configured, reachable and has the schema. Memoised per instance; failures retry. */
export async function ensureDatabase(): Promise<DbStatus> {
  if (!g.__bpzSchemaReady) g.__bpzSchemaReady = run();
  const status = await g.__bpzSchemaReady;
  if (!status.ok) g.__bpzSchemaReady = undefined;
  return status;
}

/** Route helper: returns a JSON 503 Response if the DB is not usable, else null. */
export async function dbGuard(): Promise<Response | null> {
  const s = await ensureDatabase();
  if (s.ok) return null;
  return Response.json({ success: false, code: s.code, error: s.error, hint: s.hint, similarEnvNames: s.similarEnvNames, deployment: s.deployment }, { status: 503 });
}