"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Scale, ShieldCheck, KeyRound, Fingerprint, LockKeyhole, ArrowRight } from "lucide-react";
import { api } from "@/components/ui";

const PERSONAS = [
  { username: "owner", password: "BpzOwner#2026", label: "System Owner", desc: "full control + user management" },
  { username: "controller", password: "Control#2026", label: "Controller", desc: "reversals · period close · QA suite" },
  { username: "accountant", password: "Accounts#2026", label: "Accountant", desc: "posting · billing · banking" },
  { username: "auditor", password: "Audit#2026", label: "External Auditor", desc: "read-only assurance access" },
];

export default function LoginPage() {
  const router = useRouter();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true); setError("");
    const d = await api("/api/auth", "POST", { username, password });
    setBusy(false);
    if (d.success) { router.replace("/"); router.refresh(); }
    else setError(d.error || "Sign-in failed.");
  };

  return (
    <div className="min-h-screen grid lg:grid-cols-2">
      <div className="hidden lg:flex flex-col justify-between p-12 text-white relative overflow-hidden" style={{ background: "linear-gradient(160deg, #0d1f17 0%, #123324 60%, #0c1d15 100%)" }}>
        <div className="absolute inset-0 opacity-[0.05]" style={{ backgroundImage: "repeating-linear-gradient(0deg, transparent, transparent 34px, #d9a514 34px, #d9a514 35px)" }} />
        <div className="relative rise">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gold text-ink flex items-center justify-center shadow-xl shadow-black/40"><Scale className="w-6 h-6" strokeWidth={2.4} /></div>
            <div>
              <div className="font-display font-black text-[22px] tracking-tight leading-none">BPZ FISCAL</div>
              <div className="font-mono text-[10px] text-gold tracking-[0.3em] mt-1">PRACTICE EDITION</div>
            </div>
          </div>
          <h1 className="font-display font-black text-[44px] leading-[1.04] tracking-tight mt-14 max-w-md">
            The ledger<br />answers to<br /><span className="text-gold">named people.</span>
          </h1>
          <p className="text-[14px] text-emerald-100/70 mt-5 max-w-sm leading-relaxed">
            Every posting carries its preparer. Reversals demand a second pair of hands. Periods lock at the controller's command. This is what audit-grade means.
          </p>
        </div>
        <div className="relative space-y-3 rise rise-2">
          {[
            [ShieldCheck, "Role-based access — owner, controller, accountant, auditor"],
            [Fingerprint, "Segregation of duties — no self-reversals, ever"],
            [LockKeyhole, "scrypt-hashed credentials · httpOnly sessions · OB52 period locks"],
          ].map(([Icon, text], i) => {
            const I = Icon as typeof ShieldCheck;
            return <div key={i} className="flex items-center gap-3 text-[13px] text-emerald-100/80"><span className="w-8 h-8 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center"><I className="w-4 h-4 text-gold" /></span>{text as string}</div>;
          })}
        </div>
      </div>

      <div className="flex items-center justify-center p-6 sm:p-12">
        <div className="w-full max-w-md rise">
          <div className="lg:hidden flex items-center gap-2 mb-8">
            <div className="w-9 h-9 rounded-lg bg-ink text-gold flex items-center justify-center"><Scale className="w-4 h-4" /></div>
            <span className="font-display font-black text-[18px]">BPZ FISCAL</span>
          </div>
          <div className="font-mono text-[10.5px] font-bold tracking-[0.2em] text-leaf uppercase flex items-center gap-2"><span className="w-6 h-[2px] bg-gold" /> Secure sign-in</div>
          <h2 className="font-display font-black text-[28px] tracking-tight mt-2">Open the practice books</h2>
          <p className="text-[13px] text-slate-500 mt-1">Sessions expire after 12 hours. All access is written to the audit trail.</p>

          <form onSubmit={submit} className="mt-6 space-y-3">
            <div><label className="flabel">Username</label><input className="field !py-2.5" autoComplete="username" required value={username} onChange={(e) => setUsername(e.target.value)} placeholder="e.g. controller" /></div>
            <div><label className="flabel">Password</label><input className="field !py-2.5" type="password" autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••••••" /></div>
            {error && <div className="text-[12.5px] font-semibold text-clay bg-[#fbeae6] border border-[#efc4bb] rounded-lg px-3 py-2 rise">{error}</div>}
            <button className="btn btn-primary w-full justify-center !py-3 !text-[14px]" disabled={busy}>
              <KeyRound className="w-4 h-4" /> {busy ? "Verifying credentials…" : "Sign in"} <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          <div className="mt-8">
            <div className="text-[10.5px] uppercase tracking-widest font-extrabold text-slate-400 mb-2">Preview personas — one click fills credentials</div>
            <div className="grid grid-cols-2 gap-2">
              {PERSONAS.map((p) => (
                <button key={p.username} onClick={() => { setUsername(p.username); setPassword(p.password); setError(""); }}
                  className={`panel panel-hover p-3 text-left ${username === p.username ? "!border-leaf ring-2 ring-leaf/20" : ""}`}>
                  <div className="font-bold text-[12.5px]">{p.label}</div>
                  <div className="font-mono text-[10.5px] text-leaf">{p.username}</div>
                  <div className="text-[10.5px] text-slate-500 mt-0.5 leading-snug">{p.desc}</div>
                </button>
              ))}
            </div>
            <p className="text-[11px] text-slate-400 mt-3">Demo credentials for evaluation. Rotate all passwords in Access Control before onboarding real clients.</p>
          </div>
        </div>
      </div>
    </div>
  );
}