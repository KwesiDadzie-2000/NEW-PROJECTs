"use client";

import { useCallback, useEffect, useState } from "react";
import { Calculator, CalendarClock, Users2 } from "lucide-react";
import { PageHead, useClients, api, fmt, num, ClientPicker, Stat, Badge, Empty } from "@/components/ui";

interface VatSummary {
  period: string; standardSales: number; reliefSales: number; outputVat: number; inputVat: number;
  netPayable: number; vatGlBalance: number; whtCredits: number; whtPayable: number; vatWithheld: number; invoiceCount: number; dueNote: string;
}
interface PayrollResult { gross: number; ssnitEmployee: number; ssnitEmployer: number; taxable: number; paye: number; netPay: number; breakdown: string[]; totalEmployerCost: number }

export default function TaxPage() {
  const { clients } = useClients();
  const [cc, setCc] = useState("");
  const [period, setPeriod] = useState("2026-02");
  const [vat, setVat] = useState<VatSummary | null>(null);
  const [pr, setPr] = useState<PayrollResult | null>(null);
  const [payForm, setPayForm] = useState({ basic: "9500", allowances: "1500", tier3: "0", casual: false, nonResident: false });

  useEffect(() => { if (!cc && clients.length) setCc(clients[0].companyCode); }, [clients, cc]);
  const load = useCallback(async () => {
    if (!cc) return;
    const d = await api(`/api/tax?companyCode=${cc}&period=${period}`);
    if (d.success) setVat(d);
  }, [cc, period]);
  useEffect(() => { load(); }, [load]);

  const calcPayroll = async () => {
    const d = await api("/api/tax", "POST", { action: "PAYROLL", ...payForm, basic: Number(payForm.basic), allowances: Number(payForm.allowances), tier3: Number(payForm.tier3) });
    if (d.success) setPr(d.result);
  };
  useEffect(() => { calcPayroll(); /* initial preview */ // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div>
      <PageHead
        tcode="TX01 · Ghana Statutory Desk"
        title="Tax & payroll, current law."
        sub="VAT Act 1151 (2026): unified 20% on one base — 15% VAT + 2.5% NHIL + 2.5% GETFund, COVID levy abolished, levies deductible. PAYE Act 1178: first GH¢588 tax-free. SSNIT 5.5% / 13%."
        actions={<>
          <ClientPicker clients={clients} value={cc} onChange={setCc} />
          <input className="field !w-auto" type="month" value={period} onChange={(e) => setPeriod(e.target.value)} />
        </>}
      />

      {!cc ? <Empty title="Select a client ledger" /> : (
        <>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            <Stat label="Output VAT + levies" value={fmt(vat?.outputVat || 0)} note={`${vat?.invoiceCount || 0} invoices in ${period}`} delay="rise-1" />
            <Stat label="Input VAT recoverable" value={fmt(vat?.inputVat || 0)} note="incl. deductible NHIL/GETFund" tone="text-leaf" delay="rise-2" />
            <Stat label="Net VAT payable" value={fmt(vat?.netPayable || 0)} note="output − input" tone={(vat?.netPayable || 0) > 0 ? "text-clay" : "text-leaf"} delay="rise-3" />
            <Stat label="VAT GL balance (220000)" value={fmt(vat?.vatGlBalance || 0)} note="ledger control account" delay="rise-4" />
          </div>

          <div className="grid lg:grid-cols-2 gap-4 mt-4">
            <div className="panel p-5 rise rise-2">
              <h2 className="font-display font-bold text-[15px] flex items-center gap-2 mb-3"><Calculator className="w-4 h-4 text-leaf" /> VAT return skeleton — {period}</h2>
              <table className="ledger-table">
                <tbody>
                  {[
                    ["Standard-rated sales (box 1)", vat?.standardSales],
                    ["Zero-rated / exempt supplies (box 2)", vat?.reliefSales],
                    ["Output VAT 15% + NHIL 2.5% + GETFund 2.5%", vat?.outputVat],
                    ["Input VAT + deductible levies", vat?.inputVat],
                    ["WHT credits suffered (AR)", vat?.whtCredits],
                    ["WHT collected for GRA (AP)", vat?.whtPayable],
                    ["7% VAT withheld on supplier payments", vat?.vatWithheld],
                  ].map(([l, v]) => (
                    <tr key={l as string}><td>{l}</td><td className="text-right font-mono tnum font-semibold">{num(v as number || 0)}</td></tr>
                  ))}
                  <tr className="font-bold"><td className="font-display">NET PAYABLE / (CREDIT)</td><td className={`text-right font-mono tnum border-t-2 border-ink ${(vat?.netPayable || 0) >= 0 ? "text-clay" : "text-leaf"}`}>{num(vat?.netPayable || 0)}</td></tr>
                </tbody>
              </table>
              <div className="mt-3 flex items-start gap-2 text-[12px] text-slate-600 bg-gold-soft rounded-lg p-3">
                <CalendarClock className="w-4 h-4 shrink-0 mt-0.5 text-[#8a6a08]" /> {vat?.dueNote}
              </div>
              <div className="mt-2"><Badge tone="blue">REGIME ACT 1151</Badge> <Badge tone="slate">no cascade · no flat rate</Badge></div>
            </div>

            <div className="panel p-5 rise rise-3">
              <h2 className="font-display font-bold text-[15px] flex items-center gap-2 mb-3"><Users2 className="w-4 h-4 text-leaf" /> PAYE & SSNIT calculator (Act 1178)</h2>
              <div className="grid grid-cols-3 gap-2">
                <div><label className="flabel">Basic / mo</label><input className="field font-mono" type="number" value={payForm.basic} onChange={(e) => setPayForm({ ...payForm, basic: e.target.value })} /></div>
                <div><label className="flabel">Allowances</label><input className="field font-mono" type="number" value={payForm.allowances} onChange={(e) => setPayForm({ ...payForm, allowances: e.target.value })} /></div>
                <div><label className="flabel">Tier 3</label><input className="field font-mono" type="number" value={payForm.tier3} onChange={(e) => setPayForm({ ...payForm, tier3: e.target.value })} /></div>
              </div>
              <div className="flex gap-4 mt-2 text-[12.5px] font-semibold">
                <label className="flex items-center gap-1.5"><input type="checkbox" checked={payForm.casual} onChange={(e) => setPayForm({ ...payForm, casual: e.target.checked, nonResident: false })} /> Casual (5% final)</label>
                <label className="flex items-center gap-1.5"><input type="checkbox" checked={payForm.nonResident} onChange={(e) => setPayForm({ ...payForm, nonResident: e.target.checked, casual: false })} /> Non-resident (25%)</label>
                <button className="btn btn-primary !py-1 ml-auto" onClick={calcPayroll}>Compute</button>
              </div>
              {pr && (
                <div className="mt-4 rise">
                  <div className="grid grid-cols-3 gap-2 text-center">
                    {[["Gross", pr.gross], ["PAYE", pr.paye], ["Net pay", pr.netPay], ["SSNIT ee (5.5%)", pr.ssnitEmployee], ["SSNIT er (13%)", pr.ssnitEmployer], ["Employer cost", pr.totalEmployerCost]].map(([l, v]) => (
                      <div key={l as string} className="bg-[#f6f8f5] rounded-lg py-2">
                        <div className="text-[9.5px] uppercase font-bold text-slate-500">{l}</div>
                        <div className="font-mono font-bold text-[13px] tnum">{num(v as number)}</div>
                      </div>
                    ))}
                  </div>
                  <div className="mt-3 text-[11.5px] font-mono text-slate-600 space-y-0.5 bg-[#fbfcfa] border border-[#e7ece6] rounded-lg p-3">
                    {pr.breakdown.map((b, i) => <div key={i}>· {b}</div>)}
                  </div>
                </div>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
}