import { db } from "@/db";
import { accounts, bankAccounts, clients, invoices, journalEntries, journalLines, processedDocs, statementLines, testRuns, auditLog, periods } from "@/db/schema";
import { eq, inArray } from "drizzle-orm";
import { provisionClient } from "./coa";
import { postEntry, reverseEntry, trialBalance, setPeriodStatus } from "./ledger";
import { createInvoice, payInvoice, importStatement, postStatementLine, settleInvoiceFromLine } from "./operations";
import { extractDocument } from "./extract";
import { calcVAT, computePayrollLine, r2, type VatTreatment } from "./ghana-tax";

export interface Assertion { name: string; pass: boolean; detail: string }
export interface SectorResult { sector: string; name: string; icon: string; companyCode: string; assertions: Assertion[]; passed: number; failed: number }

interface SectorScenario {
  code: string; name: string; icon: string;
  treatment: VatTreatment; whtRate: number; withholdVatOnAp: boolean;
  payroll: { basic: number; allowances: number; casual?: boolean; nonResident?: boolean };
  note: string;
}

// Standard transaction set tailored to ALL sectors of the Ghanaian + global economy.
const SCENARIOS: SectorScenario[] = [
  { code: "AGRI", name: "Agriculture & Agribusiness", icon: "🌾", treatment: "EXEMPT", whtRate: 3, withholdVatOnAp: false, payroll: { basic: 1800, allowances: 0, casual: true }, note: "Basic foodstuffs exempt; 3% produce WHT; casual labour 5% final." },
  { code: "MINING", name: "Mining & Minerals", icon: "⛏️", treatment: "ZERO", whtRate: 10, withholdVatOnAp: false, payroll: { basic: 12000, allowances: 3000 }, note: "Gold exports zero-rated; 10% royalty WHT; expatriate-heavy payroll." },
  { code: "OILGAS", name: "Oil, Gas & Energy", icon: "🛢️", treatment: "ZERO", whtRate: 20, withholdVatOnAp: false, payroll: { basic: 25000, allowances: 8000, nonResident: true }, note: "Upstream zero-rated; 20% NR technical fees; rotational payroll." },
  { code: "MANUF", name: "Manufacturing", icon: "🏭", treatment: "STANDARD", whtRate: 3, withholdVatOnAp: true, payroll: { basic: 4200, allowances: 600 }, note: "Standard sales; input VAT recovery; 3% goods WHT." },
  { code: "CONST", name: "Construction & Real Estate", icon: "🏗️", treatment: "STANDARD", whtRate: 5, withholdVatOnAp: true, payroll: { basic: 3500, allowances: 500 }, note: "5% works WHT; retention; IPC-style certified billing." },
  { code: "TRADING", name: "Trading & Distribution", icon: "🛒", treatment: "STANDARD", whtRate: 3, withholdVatOnAp: true, payroll: { basic: 2800, allowances: 400 }, note: "Retail/wholesale standard-rated; 3% goods; 7% VAT WHT agent." },
  { code: "SERVICES", name: "Professional Services", icon: "💼", treatment: "STANDARD", whtRate: 7.5, withholdVatOnAp: true, payroll: { basic: 9500, allowances: 1500 }, note: "7.5% services WHT; all services VAT-register under Act 1151." },
  { code: "FINANCE", name: "Banking & Financial Services", icon: "🏦", treatment: "EXEMPT", whtRate: 0, withholdVatOnAp: false, payroll: { basic: 15000, allowances: 4000 }, note: "Core interest exempt; GSL 5% on PBT; no WHT on interest." },
  { code: "HEALTH", name: "Healthcare & Pharma", icon: "🏥", treatment: "EXEMPT", whtRate: 3, withholdVatOnAp: false, payroll: { basic: 7000, allowances: 2000 }, note: "Medical services exempt; 3% pharma supply WHT." },
  { code: "EDUC", name: "Education", icon: "🎓", treatment: "EXEMPT", whtRate: 7.5, withholdVatOnAp: false, payroll: { basic: 3800, allowances: 300 }, note: "Tuition exempt; 7.5% consultant WHT." },
  { code: "TRANSPORT", name: "Transport & Logistics", icon: "🚚", treatment: "STANDARD", whtRate: 7.5, withholdVatOnAp: true, payroll: { basic: 4800, allowances: 1200 }, note: "Haulage standard-rated 7.5%; passenger exempt." },
  { code: "HOSPITALITY", name: "Hospitality & Tourism", icon: "🏨", treatment: "STANDARD", whtRate: 7.5, withholdVatOnAp: true, payroll: { basic: 2200, allowances: 300 }, note: "Standard VAT + 1% tourism levy tracked separately." },
  { code: "ICT", name: "ICT & Telecom", icon: "📡", treatment: "STANDARD", whtRate: 7.5, withholdVatOnAp: true, payroll: { basic: 11000, allowances: 2500 }, note: "CST 5%, GSL 5%; 20% NR licence fees." },
  { code: "NGO", name: "NGO & Public Sector", icon: "🤝", treatment: "EXEMPT", whtRate: 7.5, withholdVatOnAp: false, payroll: { basic: 5200, allowances: 800 }, note: "Donor relief exempt; MDA is a 7% VAT withholding agent." },
];

async function cleanup(companyCode: string) {
  const entries = await db.select({ id: journalEntries.id }).from(journalEntries).where(eq(journalEntries.companyCode, companyCode));
  const ids = entries.map((e) => e.id);
  if (ids.length) await db.delete(journalLines).where(inArray(journalLines.entryId, ids));
  const bas = await db.select({ id: bankAccounts.id }).from(bankAccounts).where(eq(bankAccounts.companyCode, companyCode));
  const baIds = bas.map((b) => b.id);
  if (baIds.length) await db.delete(statementLines).where(inArray(statementLines.bankAccountId, baIds));
  await db.delete(journalEntries).where(eq(journalEntries.companyCode, companyCode));
  await db.delete(invoices).where(eq(invoices.companyCode, companyCode));
  await db.delete(bankAccounts).where(eq(bankAccounts.companyCode, companyCode));
  await db.delete(accounts).where(eq(accounts.companyCode, companyCode));
  await db.delete(processedDocs).where(eq(processedDocs.companyCode, companyCode));
  await db.delete(periods).where(eq(periods.companyCode, companyCode));
  await db.delete(auditLog).where(eq(auditLog.companyCode, companyCode));
  await db.delete(clients).where(eq(clients.companyCode, companyCode));
}

async function runSector(s: SectorScenario, idx: number): Promise<SectorResult> {
  const assertions: Assertion[] = [];
  const ok = (name: string, pass: boolean, detail: string) => assertions.push({ name, pass, detail });
  const client = await provisionClient({
    businessName: `QA ${s.name} Ltd`, sector: s.code, tin: `C99${String(1000000 + idx * 37).padStart(7, "0")}`,
    isTest: true, bankName: idx % 2 === 0 ? "GCB Bank PLC" : "Ecobank Ghana PLC", sortCode: idx % 2 === 0 ? "040" : "130",
  });
  const cc = client.companyCode;
  try {
    const bas = await db.select().from(bankAccounts).where(eq(bankAccounts.companyCode, cc));
    const ba = bas[0];

    // T1 — capital injection
    const t1 = await postEntry({ companyCode: cc, docType: "SA", postingDate: "2026-01-02", headerText: "Owner capital injection", lines: [{ accountCode: "100200", side: "D", amount: 200000 }, { accountCode: "300000", side: "C", amount: 200000 }], source: "TEST", createdBy: "qa-maker" });
    ok("Capital injection posts (Dr Bank / Cr Capital)", t1.ok, t1.ok ? `Doc ${t1.docNumber}` : t1.error);

    // T2 — AR invoice with sector VAT treatment + WHT
    const ar = await createInvoice({ companyCode: cc, kind: "AR", partner: "QA Customer Enterprises", invoiceDate: "2026-02-03", dueDate: "2026-03-05", netAmount: 50000, treatment: s.treatment, whtRate: s.whtRate, description: `${s.name} standard sale` });
    ok(`AR invoice posts (${s.treatment} VAT, ${s.whtRate}% WHT)`, ar.ok, ar.ok ? `${ar.invoice.invoiceNo} gross ${ar.invoice.grossTotal}` : ar.error);
    const expectedVat = calcVAT(50000, s.treatment);
    ok("VAT computed per Act 1151 sector treatment", ar.ok && Number(ar.invoice.grossTotal) === expectedVat.gross, ar.ok ? `Expected gross ${expectedVat.gross}, got ${ar.invoice.grossTotal} (levies ${expectedVat.leviesTotal})` : "invoice failed");

    // T3 — partial then final receipt with WHT credit
    if (ar.ok) {
      const half = r2(Number(ar.invoice.grossTotal) / 2);
      const p1 = await payInvoice({ invoiceId: ar.invoice.id, amount: half, paymentDate: "2026-02-10" });
      ok("Partial receipt clears AR proportionally (WHT credit tracked)", p1.ok && p1.status === "PARTIALLY_PAID", p1.ok ? `Cash ${p1.cash}, WHT credit ${p1.whtNow}` : p1.error);
      const p2 = await payInvoice({ invoiceId: ar.invoice.id, amount: Number(ar.invoice.grossTotal), paymentDate: "2026-02-20" });
      ok("Final receipt settles invoice to PAID (overpay capped)", p2.ok && p2.status === "PAID", p2.ok ? `Applied ${p2.applied}, balance ${p2.balance}` : p2.error);
      const p3 = await payInvoice({ invoiceId: ar.invoice.id, amount: 100, paymentDate: "2026-02-21" });
      ok("Double payment on settled invoice rejected", !p3.ok, p3.ok ? "BUG: settled invoice accepted payment" : (p3 as { error: string }).error);
    }

    // T4 — AP invoice + payment with income WHT and 7% VAT withholding
    const ap = await createInvoice({ companyCode: cc, kind: "AP", partner: "QA Supplier Works", invoiceDate: "2026-02-05", netAmount: 20000, treatment: "STANDARD", whtRate: s.whtRate > 0 ? s.whtRate : 7.5, description: "Supplier bill" });
    ok("AP invoice posts with deductible input VAT", ap.ok, ap.ok ? `${ap.invoice.invoiceNo} gross ${ap.invoice.grossTotal}` : ap.error);
    if (ap.ok) {
      const pay = await payInvoice({ invoiceId: ap.invoice.id, amount: Number(ap.invoice.grossTotal), paymentDate: "2026-02-25", withholdVat: s.withholdVatOnAp });
      ok("Supplier paid net of WHT" + (s.withholdVatOnAp ? " + 7% VAT withheld" : ""), pay.ok && pay.status === "PAID", pay.ok ? `Cash ${pay.cash}, WHT ${pay.whtNow}, VAT WHT ${pay.vatWNow}` : pay.error);
      if (s.withholdVatOnAp && pay.ok) {
        const expectedVatWht = r2(calcVAT(20000).leviesTotal * 0.07);
        ok("7% VAT withholding computed on levies (not gross)", Math.abs(pay.vatWNow - expectedVatWht) < 0.02, `Expected ${expectedVatWht}, got ${pay.vatWNow}`);
      }
    }

    // T5 — payroll posting (sector workforce)
    const pr = computePayrollLine(s.payroll);
    const payroll = await postEntry({
      companyCode: cc, docType: "SA", postingDate: "2026-02-27", headerText: `Payroll Feb — ${s.code}`,
      lines: [
        { accountCode: "610000", side: "D", amount: pr.gross, itemText: "Gross salaries" },
        ...(pr.ssnitEmployer > 0 ? [{ accountCode: "611000", side: "D" as const, amount: pr.ssnitEmployer, itemText: "Employer SSNIT 13%" }] : []),
        ...(pr.ssnitEmployee + pr.ssnitEmployer > 0 ? [{ accountCode: "231000", side: "C" as const, amount: r2(pr.ssnitEmployee + pr.ssnitEmployer), itemText: "SSNIT payable" }] : []),
        { accountCode: "230000", side: "C", amount: pr.paye, itemText: "PAYE payable" },
        { accountCode: "100200", side: "C", amount: pr.netPay, itemText: "Net pay" },
      ], source: "PAYROLL",
    });
    ok(`Payroll balances (${s.payroll.casual ? "casual 5%" : s.payroll.nonResident ? "NR 25%" : "PAYE Act 1178 + SSNIT"})`, payroll.ok && pr.paye > 0, payroll.ok ? `Gross ${pr.gross}, PAYE ${pr.paye}, net ${pr.netPay}` : payroll.error);

    // T6 — bank statement import: MUST resolve to the client, never the bank
    const imp = await importStatement({ bankAccountId: ba.id, rows: [
      { date: "2026-02-18", description: "E-VAT SALES RECEIPT — customer settlement", debit: 0, credit: 12500 },
      { date: "2026-02-19", description: "BANK CHARGES + COT", debit: 180, credit: 0 },
      { date: "2026-02-19", description: "GRA VAT REMITTANCE FEB", debit: 2000, credit: 0 },
    ] });
    ok("Statement imports route to account OWNER's company code", imp.ok && imp.companyCode === cc, imp.ok ? `Routed to ${imp.companyCode} (bank ${ba.bankName} sort ${ba.sortCode} kept as metadata)` : imp.error);
    if (imp.ok) {
      const lines = await db.select().from(statementLines).where(eq(statementLines.bankAccountId, ba.id));
      const charges = lines.find((l) => l.description.includes("CHARGES"));
      const postedLine = charges ? await postStatementLine({ lineId: charges.id }) : { ok: false as const, error: "line missing" };
      ok("Bank charges post Dr 630000 / Cr Bank in client ledger", postedLine.ok, postedLine.ok ? `Doc ${postedLine.docNumber}` : postedLine.error);
      const dup = charges ? await postStatementLine({ lineId: charges.id }) : { ok: true as const, docNumber: "" };
      ok("Double-posting the same statement line rejected", !dup.ok, dup.ok ? "BUG: line posted twice" : (dup as { error: string }).error);
    }

    // T7 — document intelligence: bank codes must NOT hijack the company code
    const docText = `TAX INVOICE\nFrom: ${client.businessName}\nTIN: ${client.tin}\nCompany Code: ${ba.sortCode}0119\nInvoice No: QA-2026-77\nDate: 2026-02-12\nSubtotal: GHS 8,000.00\nVAT: GHS 1,600.00\nGrand Total: GHS 9,600.00\nBank: ${ba.bankName}, Sort Code ${ba.sortCode}0119, A/C No: ${ba.accountNumber}`;
    const ex = await extractDocument(docText);
    ok("Company code resolves to CLIENT despite bank sort code labelled as company code", ex.companyCode === cc, `Resolved ${ex.companyCode ?? "null"} (expected ${cc}); rejected: ${ex.rejectedCodes.map((r) => r.code).join(", ") || "none"}`);
    ok("Bank identifiers quarantined as counterparty metadata", !!ex.bankInfo && ex.rejectedCodes.length > 0, ex.bankInfo ? `${ex.bankInfo.bankName} flagged ${ex.bankInfo.role}` : "no bank detected");
    ok("Amounts + 20% VAT extracted correctly (gross ≠ subtotal)", ex.netAmount === 8000 && ex.vatAmount === 1600 && ex.grossAmount === 9600, `Net ${ex.netAmount}, VAT ${ex.vatAmount}, gross ${ex.grossAmount}`);

    // T8 — settle a fresh AR invoice straight from a statement line
    const ar2 = await createInvoice({ companyCode: cc, kind: "AR", partner: "QA Walk-in Buyer", invoiceDate: "2026-02-14", netAmount: 5000, treatment: s.treatment, whtRate: 0 });
    if (ar2.ok) {
      const imp2 = await importStatement({ bankAccountId: ba.id, rows: [{ date: "2026-02-21", description: `SETTLEMENT ${ar2.invoice.invoiceNo}`, debit: 0, credit: Number(ar2.invoice.grossTotal) }] });
      const lines2 = await db.select().from(statementLines).where(eq(statementLines.bankAccountId, ba.id));
      const settleLine = lines2.find((l) => l.description.includes(ar2.invoice.invoiceNo) && l.status === "UNMATCHED");
      const settled = imp2.ok && settleLine ? await settleInvoiceFromLine({ lineId: settleLine.id, invoiceId: ar2.invoice.id }) : { ok: false as const, error: "setup failed" };
      ok("Bank-line → invoice settlement workflow completes", settled.ok && settled.status === "PAID", settled.ok ? `Doc ${settled.docNumber}` : settled.error);
    }

    // T9 — guards: closed period, unbalanced entry, unknown account, foreign code
    const closed = await postEntry({ companyCode: cc, docType: "SA", postingDate: "2025-12-15", headerText: "Closed FY attempt", lines: [{ accountCode: "100200", side: "D", amount: 10 }, { accountCode: "300000", side: "C", amount: 10 }], source: "TEST" });
    ok("Closed fiscal year (2025) posting blocked — OB52", !closed.ok && /CLOSED/i.test((closed as { error?: string }).error || ""), closed.ok ? "BUG: closed period accepted" : (closed as { error: string }).error);
    const unbal = await postEntry({ companyCode: cc, docType: "SA", postingDate: "2026-02-15", headerText: "Unbalanced", lines: [{ accountCode: "100200", side: "D", amount: 100 }, { accountCode: "300000", side: "C", amount: 90 }], source: "TEST" });
    ok("Unbalanced document rejected", !unbal.ok, unbal.ok ? "BUG: unbalanced accepted" : (unbal as { error: string }).error);
    const ghost = await postEntry({ companyCode: cc, docType: "SA", postingDate: "2026-02-15", headerText: "Ghost account", lines: [{ accountCode: "999999", side: "D", amount: 10 }, { accountCode: "300000", side: "C", amount: 10 }], source: "TEST" });
    ok("Unknown GL account rejected", !ghost.ok, ghost.ok ? "BUG: ghost account accepted" : (ghost as { error: string }).error);
    const foreign = await postEntry({ companyCode: ba.sortCode, docType: "SA", postingDate: "2026-02-15", headerText: "Bank code attempt", lines: [{ accountCode: "100200", side: "D", amount: 10 }, { accountCode: "300000", side: "C", amount: 10 }], source: "TEST" });
    ok("Posting under a BANK sort code as company code rejected", !foreign.ok, foreign.ok ? "BUG: bank code accepted as ledger" : (foreign as { error: string }).error);

    // T10 — segregation of duties + reversal nets to zero, TB stays balanced
    if (t1.ok) {
      const selfRev = await reverseEntry(t1.entry.id, "SoD probe", "qa-maker");
      ok("SoD: preparer cannot reverse own document", !selfRev.ok && /Segregation of duties/i.test((selfRev as { error?: string }).error || ""), selfRev.ok ? "BUG: self-reversal accepted" : (selfRev as { error: string }).error);
      const rev = await reverseEntry(t1.entry.id, "QA reversal test", "qa-controller");
      const tb = await trialBalance(cc);
      const cap = tb.rows.find((r) => r.code === "300000");
      ok("FB08 reversal by second user nets original to zero", rev.ok && cap?.balance === 0, rev.ok ? `Reversal ${rev.docNumber} by qa-controller, capital balance ${cap?.balance}` : rev.error);
      ok("Trial balance balanced after full sector cycle", tb.isBalanced, `Dr ${tb.totalDebit} = Cr ${tb.totalCredit}`);
    }

    // T11 — OB52 period close blocks posting; controller reopen restores it
    await setPeriodStatus(cc, 2026, 3, "CLOSED", "qa-controller");
    const closedProbe = await postEntry({ companyCode: cc, docType: "SA", postingDate: "2026-03-10", headerText: "Closed period probe", lines: [{ accountCode: "100200", side: "D", amount: 50 }, { accountCode: "300000", side: "C", amount: 50 }], source: "TEST", createdBy: "qa-maker" });
    ok("OB52: CLOSED period 2026-03 blocks posting", !closedProbe.ok && /CLOSED/i.test((closedProbe as { error?: string }).error || ""), closedProbe.ok ? "BUG: closed period accepted" : (closedProbe as { error: string }).error);
    await setPeriodStatus(cc, 2026, 3, "OPEN", "qa-controller");
    const reopenProbe = await postEntry({ companyCode: cc, docType: "SA", postingDate: "2026-03-10", headerText: "Reopened period probe", lines: [{ accountCode: "100200", side: "D", amount: 50 }, { accountCode: "300000", side: "C", amount: 50 }], source: "TEST", createdBy: "qa-maker" });
    ok("OB52: controller reopen restores posting", reopenProbe.ok, reopenProbe.ok ? `Doc ${reopenProbe.docNumber} after reopen` : reopenProbe.error);
  } finally {
    await cleanup(cc);
  }
  return {
    sector: s.code, name: s.name, icon: s.icon, companyCode: cc,
    assertions, passed: assertions.filter((a) => a.pass).length, failed: assertions.filter((a) => !a.pass).length,
  };
}

export async function runSectorSuite() {
  const started = Date.now();
  const results: SectorResult[] = [];
  for (let i = 0; i < SCENARIOS.length; i++) {
    results.push(await runSector(SCENARIOS[i], i));
  }
  const passed = results.reduce((t, r) => t + r.passed, 0);
  const failed = results.reduce((t, r) => t + r.failed, 0);
  const durationMs = Date.now() - started;
  const [run] = await db.insert(testRuns).values({ passed, failed, total: passed + failed, durationMs, results }).returning();
  return { run, results, passed, failed, total: passed + failed, durationMs };
}

export async function latestRuns() {
  const runs = await db.select().from(testRuns);
  return runs.sort((a, b) => b.id - a.id).slice(0, 10);
}