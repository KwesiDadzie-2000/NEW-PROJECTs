import { db } from "@/db";
import { accounts, bankAccounts, clients, invoices, journalEntries, journalLines, processedDocs, statementLines, periods } from "@/db/schema";
import { eq } from "drizzle-orm";
import { trialBalance } from "./ledger";
import { BANK_REGISTRY } from "./extract";
import { r2 } from "./ghana-tax";

export interface AuditCheck {
  id: string; name: string; severity: "CRITICAL" | "HIGH" | "MEDIUM";
  status: "PASS" | "FAIL" | "WARN"; detail: string; affected: string[];
}

export async function runSystemAudit(): Promise<{ checks: AuditCheck[]; passed: number; failed: number; warnings: number; score: number }> {
  const checks: AuditCheck[] = [];
  const allClients = await db.select().from(clients);
  const clientCodes = new Set(allClients.map((c) => c.companyCode));
  const bankCodeSet = new Set(BANK_REGISTRY.flatMap((b) => [...b.sortCodes, b.swift]));

  // 1. Trial balance integrity for every client ledger
  const tbFails: string[] = [];
  for (const c of allClients) {
    const tb = await trialBalance(c.companyCode);
    if (!tb.isBalanced) tbFails.push(`${c.companyCode}: Dr ${tb.totalDebit} vs Cr ${tb.totalCredit}`);
  }
  checks.push({
    id: "TB_BALANCE", name: "Trial balance balances for every client ledger", severity: "CRITICAL",
    status: tbFails.length ? "FAIL" : "PASS",
    detail: tbFails.length ? `${tbFails.length} ledger(s) out of balance.` : `All ${allClients.length} client ledgers balance (debits = credits).`,
    affected: tbFails,
  });

  // 2. Entry-level debit/credit parity + line sums
  const entries = await db.select().from(journalEntries);
  const lines = await db.select().from(journalLines);
  const byEntry = new Map<number, typeof lines>();
  for (const l of lines) byEntry.set(l.entryId, [...(byEntry.get(l.entryId) || []), l]);
  const badEntries: string[] = [];
  for (const e of entries) {
    const ls = byEntry.get(e.id) || [];
    const d = r2(ls.filter((l) => l.side === "D").reduce((t, l) => t + Number(l.amount), 0));
    const c = r2(ls.filter((l) => l.side === "C").reduce((t, l) => t + Number(l.amount), 0));
    if (Math.abs(d - c) > 0.005 || Math.abs(d - Number(e.totalDebit)) > 0.005 || ls.length < 2) badEntries.push(`${e.companyCode}/${e.docNumber}`);
  }
  checks.push({
    id: "ENTRY_PARITY", name: "Every document's lines sum to its header totals", severity: "CRITICAL",
    status: badEntries.length ? "FAIL" : "PASS",
    detail: badEntries.length ? `${badEntries.length} document(s) fail parity.` : `${entries.length} documents verified — lines reconcile to headers.`,
    affected: badEntries,
  });

  // 3. THE REPORTED BUG — company codes must belong to clients, never banks
  const rogue = entries.filter((e) => !clientCodes.has(e.companyCode) || bankCodeSet.has(e.companyCode));
  const rogueDocs = (await db.select().from(processedDocs)).filter((d) => d.status === "POSTED" && (!d.companyCode || !clientCodes.has(d.companyCode) || bankCodeSet.has(d.companyCode)));
  const rogueAffected = [...rogue.map((e) => `${e.companyCode}/${e.docNumber}`), ...rogueDocs.map((d) => `DOC#${d.id}`)];
  checks.push({
    id: "COMPANY_CODE_INTEGRITY", name: "Company codes resolve to client ledgers — never bank codes", severity: "CRITICAL",
    status: rogueAffected.length ? "FAIL" : "PASS",
    detail: rogueAffected.length
      ? `${rogueAffected.length} posting(s) carry a bank/unknown company code — the legacy defect is present.`
      : "Every posted document and processed source document carries a registered CLIENT company code. Bank sort codes/SWIFT are quarantined as counterparty metadata.",
    affected: rogueAffected,
  });

  // 4. Lines reference accounts that exist in the posting company's COA
  const allAccounts = await db.select().from(accounts);
  const coaKeys = new Set(allAccounts.map((a) => `${a.companyCode}:${a.code}`));
  const entryById = new Map(entries.map((e) => [e.id, e]));
  const badLines = lines.filter((l) => {
    const e = entryById.get(l.entryId);
    return !e || !coaKeys.has(`${e.companyCode}:${l.accountCode}`);
  });
  checks.push({
    id: "COA_REFERENCES", name: "All journal lines reference valid accounts in the correct ledger", severity: "HIGH",
    status: badLines.length ? "FAIL" : "PASS",
    detail: badLines.length ? `${badLines.length} orphan line(s).` : `${lines.length} lines verified against per-client charts of accounts.`,
    affected: badLines.map((l) => `line#${l.id}`),
  });

  // 5. Bank ownership — statement postings must land in the account owner's ledger
  const bankAccts = await db.select().from(bankAccounts);
  const baById = new Map(bankAccts.map((b) => [b.id, b]));
  const stmt = await db.select().from(statementLines);
  const misrouted = stmt.filter((s) => {
    if (!s.entryId) return false;
    const e = entryById.get(s.entryId);
    const b = baById.get(s.bankAccountId);
    return !e || !b || e.companyCode !== b.companyCode;
  });
  checks.push({
    id: "BANK_ROUTING", name: "Statement postings land in the account OWNER's ledger (client, not bank)", severity: "CRITICAL",
    status: misrouted.length ? "FAIL" : "PASS",
    detail: misrouted.length ? `${misrouted.length} statement line(s) routed to the wrong entity.` : `${stmt.length} statement line(s) checked — routing follows account ownership.`,
    affected: misrouted.map((s) => `line#${s.id}`),
  });

  // 6. Invoice arithmetic & status consistency
  const invs = await db.select().from(invoices);
  const badInv = invs.filter((i) => {
    const bal = r2(Number(i.grossTotal) - Number(i.amountPaid));
    const expected = bal < 0.01 ? "PAID" : Number(i.amountPaid) > 0 ? "PARTIALLY_PAID" : "OPEN";
    return Math.abs(bal - Number(i.balance)) > 0.02 || i.status !== expected;
  });
  checks.push({
    id: "INVOICE_MATH", name: "Invoice balances = gross − paid; statuses consistent", severity: "HIGH",
    status: badInv.length ? "FAIL" : "PASS",
    detail: badInv.length ? `${badInv.length} invoice(s) inconsistent.` : `${invs.length} invoice(s) reconcile.`,
    affected: badInv.map((i) => i.invoiceNo),
  });

  // 7. Reversals pair correctly
  const reversed = entries.filter((e) => e.status === "REVERSED");
  const unpaired = reversed.filter((e) => !entries.some((r) => r.reversalOf === e.id));
  checks.push({
    id: "REVERSAL_PAIRS", name: "Every reversed document has its FB08 reversal document", severity: "MEDIUM",
    status: unpaired.length ? "FAIL" : "PASS",
    detail: unpaired.length ? `${unpaired.length} reversal(s) missing pairs.` : `${reversed.length} reversed document(s) correctly paired.`,
    affected: unpaired.map((e) => e.docNumber),
  });

  // 8. Negative bank balances (overdraft warning)
  const negatives: string[] = [];
  for (const c of allClients) {
    const tb = await trialBalance(c.companyCode);
    const bank = tb.rows.find((r) => r.code === "100200");
    if (bank && bank.balance < -0.005) negatives.push(`${c.companyCode}: ${bank.balance.toFixed(2)}`);
  }
  checks.push({
    id: "BANK_OVERDRAFT", name: "Operating bank accounts are not overdrawn", severity: "MEDIUM",
    status: negatives.length ? "WARN" : "PASS",
    detail: negatives.length ? `${negatives.length} ledger(s) show an overdrawn bank GL — fund or review.` : "No overdrafts detected.",
    affected: negatives,
  });

  // 9. Duplicate company codes across clients (root cause of legacy collision)
  const seen = new Map<string, number>();
  for (const c of allClients) seen.set(c.companyCode, (seen.get(c.companyCode) || 0) + 1);
  const dupes = [...seen.entries()].filter(([, n]) => n > 1).map(([code]) => code);
  checks.push({
    id: "UNIQUE_CODES", name: "Each client owns a unique company code", severity: "CRITICAL",
    status: dupes.length ? "FAIL" : "PASS",
    detail: dupes.length ? `Duplicated codes: ${dupes.join(", ")}.` : `${allClients.length} client(s), each with an exclusive company code.`,
    affected: dupes,
  });

  // 10. Segregation of duties — no self-reversals
  const selfReversals = entries.filter((e) => {
    if (!e.reversalOf) return false;
    const orig = entryById.get(e.reversalOf);
    return orig && orig.createdBy === e.createdBy;
  });
  checks.push({
    id: "SOD_REVERSALS", name: "Segregation of duties — preparers never reverse their own documents", severity: "HIGH",
    status: selfReversals.length ? "FAIL" : "PASS",
    detail: selfReversals.length ? `${selfReversals.length} self-reversal(s) found.` : "All reversals were performed by a different user than the preparer (maker–checker).",
    affected: selfReversals.map((e) => `${e.companyCode}/${e.docNumber}`),
  });

  // 11. Period control — nothing posted into a closed OB52 period
  const closedPeriods = (await db.select().from(periods)).filter((p) => p.status === "CLOSED");
  const closedKeys = new Set(closedPeriods.map((p) => `${p.companyCode}:${p.fiscalYear}-${String(p.period).padStart(2, "0")}`));
  const inClosed = entries.filter((e) => closedKeys.has(`${e.companyCode}:${e.postingDate.slice(0, 7)}`));
  checks.push({
    id: "PERIOD_CONTROL", name: "No documents posted into CLOSED periods (OB52)", severity: "CRITICAL",
    status: inClosed.length ? "FAIL" : "PASS",
    detail: inClosed.length ? `${inClosed.length} document(s) inside closed periods.` : `${closedPeriods.length} closed period(s) respected — period lock is airtight.`,
    affected: inClosed.map((e) => `${e.companyCode}/${e.docNumber}`),
  });

  const passed = checks.filter((c) => c.status === "PASS").length;
  const failed = checks.filter((c) => c.status === "FAIL").length;
  const warnings = checks.filter((c) => c.status === "WARN").length;
  const score = Math.round((passed / checks.length) * 100);
  return { checks, passed, failed, warnings, score };
}