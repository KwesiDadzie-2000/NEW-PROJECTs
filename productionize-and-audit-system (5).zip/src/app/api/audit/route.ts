import { db } from "@/db";
import { auditLog } from "@/db/schema";
import { desc } from "drizzle-orm";
import { runSystemAudit } from "@/lib/server/audit";
import { requireUser } from "@/lib/server/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  const auth = await requireUser();
  if (auth instanceof Response) return auth;
  const result = await runSystemAudit();
  const trail = await db.select().from(auditLog).orderBy(desc(auditLog.id)).limit(30);
  return Response.json({ success: true, ...result, trail });
}