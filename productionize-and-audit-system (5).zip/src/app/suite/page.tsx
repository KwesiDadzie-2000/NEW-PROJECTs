"use client";

import { useEffect, useState } from "react";
import { FlaskConical, PlayCircle, CheckCircle2, XCircle, ChevronDown, History, Timer } from "lucide-react";
import { PageHead, api, Badge, Notice } from "@/components/ui";

interface Assertion { name: string; pass: boolean; detail: string }
interface SectorResult { sector: string; name: string; icon: string; companyCode: string; assertions: Assertion[]; passed: number; failed: number }
interface RunRow { id: number; passed: number; failed: number; total: number; durationMs: number; ranAt: string; results?: SectorResult[] }

export default function SuitePage() {
  const [runs, setRuns] = useState<RunRow[]>([]);
  const [results, setResults] = useState<SectorResult[] | null>(null);
  const [summary, setSummary] = useState<{ passed: number; failed: number; total: number; durationMs: number } | null>(null);
  const [running, setRunning] = useState(false);
  const [open, setOpen] = useState<string | null>(null);
  const [error, setError] = useState("");

  const loadHistory = async () => {
    const d = await api("/api/suite");
    if (d.success) {
      setRuns(d.runs);
      if (!results && d.runs.length > 0) { setResults(d.runs[0].results as SectorResult[]); setSummary({ passed: d.runs[0].passed, failed: d.runs[0].failed, total: d.runs[0].total, durationMs: d.runs[0].durationMs }); }
    }
  };
  useEffect(() => { loadHistory(); // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const run = async () => {
    setRunning(true); setError("");
    try {
      const d = await api("/api/suite", "POST");
      if (d.success) { setResults(d.results); setSummary({ passed: d.passed, failed: d.failed, total: d.total, durationMs: d.durationMs }); loadHistory(); }
      else setError(d.error || "Suite failed to run.");
    } catch (e) { setError(String(e)); }
    setRunning(false);
  };

  return (
    <div>
      <PageHead
        tcode="QA-14 · Cross-Sector Regression"
        title="One standard cycle. Every sector."
        sub="Each sector gets an isolated QA ledger and runs the full standard transaction set: capital → AR with sector VAT/WHT → partial & final receipts → AP with 7% VAT withholding → payroll → statement import & routing → bank-code confusion probe → settlement → posting guards → reversal → trial balance. QA ledgers are destroyed afterwards — real books stay untouched."
        actions={<button className="btn btn-gold" onClick={run} disabled={running}><PlayCircle className="w-4 h-4" /> {running ? "Running 14 sector cycles…" : "Run full suite"}</button>}
      />

      {error && <div className="mb-4"><Notice kind="err">{error}</Notice></div>}

      {running && (
        <div className="panel p-8 mb-4 text-center rise relative overflow-hidden">
          <div className="scanline" />
          <FlaskConical className="w-8 h-8 text-leaf mx-auto animate-pulse" />
          <div className="font-display font-bold text-[16px] mt-2">Executing standard transactions across all sectors…</div>
          <p className="text-[12.5px] text-slate-500 mt-1">Provisioning QA ledgers · posting · probing bank-code confusion · verifying guards · cleaning up. This takes under a minute.</p>
        </div>
      )}

      {summary && (
        <div className={`panel p-5 mb-4 rise border-l-4 ${summary.failed === 0 ? "!border-l-leaf" : "!border-l-clay"}`}>
          <div className="flex flex-wrap items-center gap-5">
            <div>
              <div className="font-display font-black text-[24px]">{summary.failed === 0 ? "ALL CHECKS PASSED" : `${summary.failed} FAILURE(S)`}</div>
              <div className="text-[13px] text-slate-600 mt-0.5">{summary.passed} / {summary.total} assertions green across {results?.length || 0} sectors</div>
            </div>
            <div className="flex items-center gap-2 ml-auto">
              <Badge tone="green">{summary.passed} passed</Badge>
              <Badge tone={summary.failed ? "red" : "slate"}>{summary.failed} failed</Badge>
              <Badge tone="slate"><Timer className="w-3 h-3" /> {(summary.durationMs / 1000).toFixed(1)}s</Badge>
            </div>
          </div>
          <div className="w-full h-2 bg-slate-100 rounded-full mt-3 overflow-hidden">
            <div className={`h-full barfill ${summary.failed === 0 ? "bg-leaf" : "bg-clay"}`} style={{ width: `${(summary.passed / Math.max(1, summary.total)) * 100}%` }} />
          </div>
        </div>
      )}

      {!results && !running && (
        <div className="panel p-10 text-center rise">
          <FlaskConical className="w-8 h-8 text-leaf mx-auto" />
          <div className="font-display font-bold text-[16px] mt-2">No suite runs yet</div>
          <p className="text-[13px] text-slate-500 mt-1">Run the full suite to validate every workflow with the standard sector transaction set.</p>
        </div>
      )}

      {results && (
        <div className="grid md:grid-cols-2 gap-3">
          {results.map((r, i) => (
            <div key={r.sector} className={`panel rise rise-${(i % 4) + 1} overflow-hidden ${r.failed ? "!border-[#efc4bb]" : ""}`}>
              <button className="w-full p-4 flex items-center gap-3 text-left hover:bg-[#f8faf7] transition" onClick={() => setOpen(open === r.sector ? null : r.sector)}>
                <span className="text-[22px]">{r.icon}</span>
                <span className="flex-1 min-w-0">
                  <span className="font-bold text-[13.5px] block truncate">{r.name}</span>
                  <span className="font-mono text-[10.5px] text-slate-400">{r.sector} · QA ledger {r.companyCode} (destroyed after run)</span>
                </span>
                <Badge tone={r.failed ? "red" : "green"}>{r.failed ? `${r.failed} FAIL` : `${r.passed} PASS`}</Badge>
                <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${open === r.sector ? "rotate-180" : ""}`} />
              </button>
              {open === r.sector && (
                <div className="border-t border-[#e7ece6] px-4 py-3 space-y-1.5 bg-[#fbfcfa]">
                  {r.assertions.map((a, j) => (
                    <div key={j} className="flex items-start gap-2 text-[12px]">
                      {a.pass ? <CheckCircle2 className="w-3.5 h-3.5 text-leaf shrink-0 mt-0.5" /> : <XCircle className="w-3.5 h-3.5 text-clay shrink-0 mt-0.5" />}
                      <div><b className={a.pass ? "text-ink" : "text-clay"}>{a.name}</b><div className="text-slate-500 font-mono text-[10.5px] break-all">{a.detail}</div></div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {runs.length > 0 && (
        <div className="panel p-5 mt-4 rise rise-3">
          <h2 className="font-display font-bold text-[15px] flex items-center gap-2 mb-3"><History className="w-4 h-4 text-leaf" /> Run history</h2>
          <table className="ledger-table">
            <thead><tr><th>Run</th><th>When</th><th className="!text-right">Passed</th><th className="!text-right">Failed</th><th className="!text-right">Duration</th><th>Verdict</th></tr></thead>
            <tbody>
              {runs.map((r) => (
                <tr key={r.id} className="cursor-pointer" onClick={() => { if (r.results) { setResults(r.results); setSummary({ passed: r.passed, failed: r.failed, total: r.total, durationMs: r.durationMs }); } }}>
                  <td className="font-mono font-semibold">#{r.id}</td>
                  <td className="font-mono text-[11.5px]">{new Date(r.ranAt).toLocaleString("en-GB")}</td>
                  <td className="text-right font-mono tnum text-leaf font-bold">{r.passed}</td>
                  <td className="text-right font-mono tnum text-clay font-bold">{r.failed}</td>
                  <td className="text-right font-mono tnum">{(r.durationMs / 1000).toFixed(1)}s</td>
                  <td><Badge tone={r.failed ? "red" : "green"}>{r.failed ? "FAILURES" : "CLEAN"}</Badge></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}