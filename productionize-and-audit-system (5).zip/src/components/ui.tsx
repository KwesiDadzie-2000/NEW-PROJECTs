"use client";

import { useCallback, useEffect, useState, type ReactNode } from "react";
import { AlertTriangle, CheckCircle2, Loader2, Building2, RefreshCw } from "lucide-react";

export const fmt = (n: number | string | null | undefined, currency = "GHS") =>
  new Intl.NumberFormat("en-GH", { style: "currency", currency, minimumFractionDigits: 2 }).format(Number(n || 0));
export const num = (n: number | string | null | undefined) =>
  new Intl.NumberFormat("en-GH", { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(Number(n || 0));

export interface ClientRow {
  id: number; clientCode: string; companyCode: string; businessName: string; sector: string;
  currency: string; tin: string; status: string; contactPerson?: string; email?: string;
  documents?: number; revenue?: number; openAr?: number; openAp?: number; balanced?: boolean;
}

export function useClients() {
  const [clients, setClients] = useState<ClientRow[]>([]);
  const [loading, setLoading] = useState(true);
  const reload = useCallback(async () => {
    setLoading(true);
    try {
      const r = await fetch("/api/clients");
      const d = await r.json();
      if (d.success) setClients(d.clients);
    } finally { setLoading(false); }
  }, []);
  useEffect(() => { reload(); }, [reload]);
  return { clients, loading, reload };
}

export function PageHead({ tcode, title, sub, actions }: { tcode: string; title: string; sub?: string; actions?: ReactNode }) {
  return (
    <div className="flex flex-wrap items-end justify-between gap-3 mb-5 rise">
      <div>
        <div className="font-mono text-[10.5px] font-bold tracking-[0.2em] text-leaf uppercase flex items-center gap-2">
          <span className="inline-block w-6 h-[2px] bg-gold" /> {tcode}
        </div>
        <h1 className="font-display font-black text-[26px] sm:text-[30px] tracking-tight text-ink leading-tight mt-1">{title}</h1>
        {sub && <p className="text-[13px] text-slate-600 mt-1 max-w-2xl">{sub}</p>}
      </div>
      {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
    </div>
  );
}

export function Stat({ label, value, note, tone = "text-ink", delay = "" }: { label: string; value: ReactNode; note?: string; tone?: string; delay?: string }) {
  return (
    <div className={`panel panel-hover p-4 rise ${delay}`}>
      <div className="text-[10.5px] uppercase tracking-[0.08em] font-extrabold text-slate-500">{label}</div>
      <div className={`font-mono font-bold text-[21px] mt-1 tnum ${tone}`}>{value}</div>
      {note && <div className="text-[11.5px] text-slate-500 mt-0.5">{note}</div>}
    </div>
  );
}

export function Badge({ children, tone = "slate" }: { children: ReactNode; tone?: "green" | "gold" | "red" | "slate" | "blue" }) {
  const map = {
    green: "bg-leaf-soft text-leaf border-leaf/30",
    gold: "bg-gold-soft text-[#8a6a08] border-gold/40",
    red: "bg-[#fbeae6] text-[#a33322] border-[#efc4bb]",
    slate: "bg-slate-100 text-slate-600 border-slate-200",
    blue: "bg-sky-50 text-sky-800 border-sky-200",
  };
  return <span className={`badge ${map[tone]}`}>{children}</span>;
}

export function ClientPicker({ clients, value, onChange, allowAll = false }: { clients: ClientRow[]; value: string; onChange: (v: string) => void; allowAll?: boolean }) {
  return (
    <label className="flex items-center gap-2">
      <Building2 className="w-4 h-4 text-leaf" />
      <select className="field !w-auto min-w-[240px] font-semibold" value={value} onChange={(e) => onChange(e.target.value)}>
        {allowAll && <option value="">All client ledgers</option>}
        {!allowAll && !value && <option value="">Select client…</option>}
        {clients.map((c) => (
          <option key={c.companyCode} value={c.companyCode}>
            {c.companyCode} — {c.businessName}
          </option>
        ))}
      </select>
    </label>
  );
}

export function Notice({ kind, children, onClose }: { kind: "ok" | "err" | "info"; children: ReactNode; onClose?: () => void }) {
  if (!children) return null;
  const map = {
    ok: "bg-leaf-soft border-leaf/40 text-[#0d4a35]",
    err: "bg-[#fbeae6] border-[#efc4bb] text-[#8f2c1d]",
    info: "bg-gold-soft border-gold/50 text-[#6d5406]",
  };
  return (
    <div className={`rise border rounded-lg px-4 py-3 text-[13px] font-medium flex items-start gap-2 ${map[kind]}`}>
      {kind === "ok" ? <CheckCircle2 className="w-4 h-4 mt-0.5 shrink-0" /> : <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" />}
      <div className="flex-1">{children}</div>
      {onClose && <button onClick={onClose} className="font-bold opacity-60 hover:opacity-100">✕</button>}
    </div>
  );
}

export function Busy({ label = "Working…" }: { label?: string }) {
  return (
    <div className="flex items-center justify-center gap-2 py-10 text-slate-500 text-[13px] font-semibold">
      <Loader2 className="w-4 h-4 animate-spin text-leaf" /> {label}
    </div>
  );
}

export function Empty({ icon, title, sub, action }: { icon?: ReactNode; title: string; sub?: string; action?: ReactNode }) {
  return (
    <div className="panel p-10 text-center rise">
      <div className="mx-auto w-12 h-12 rounded-xl bg-leaf-soft text-leaf flex items-center justify-center mb-3">{icon || <Building2 className="w-5 h-5" />}</div>
      <div className="font-display font-bold text-[16px] text-ink">{title}</div>
      {sub && <p className="text-[13px] text-slate-500 mt-1 max-w-md mx-auto">{sub}</p>}
      {action && <div className="mt-4 flex justify-center">{action}</div>}
    </div>
  );
}

export function RefreshBtn({ onClick, busy }: { onClick: () => void; busy?: boolean }) {
  return (
    <button onClick={onClick} className="btn btn-ghost" disabled={busy}>
      <RefreshCw className={`w-3.5 h-3.5 ${busy ? "animate-spin" : ""}`} /> Refresh
    </button>
  );
}

export function useToast() {
  const [toast, setToast] = useState<{ kind: "ok" | "err"; text: string } | null>(null);
  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 6000);
    return () => clearTimeout(t);
  }, [toast]);
  const node = toast ? (
    <div className="fixed bottom-5 right-5 z-50 max-w-md rise">
      <Notice kind={toast.kind} onClose={() => setToast(null)}>{toast.text}</Notice>
    </div>
  ) : null;
  return { ok: (text: string) => setToast({ kind: "ok", text }), err: (text: string) => setToast({ kind: "err", text }), node };
}

/** Never throws: network errors, timeouts and non-JSON (HTML 500) responses become structured failures. */
export async function api(path: string, method = "GET", body?: unknown, timeoutMs = 20000) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const r = await fetch(path, { method, headers: { "Content-Type": "application/json" }, body: body ? JSON.stringify(body) : undefined, signal: ctrl.signal, cache: "no-store" });
    const text = await r.text();
    try {
      return JSON.parse(text);
    } catch {
      return { success: false, code: "BAD_RESPONSE", status: r.status, error: `Server returned HTTP ${r.status} without JSON — the API crashed before it could respond.`, hint: "Open /api/health on your deployment for the exact cause." };
    }
  } catch (e) {
    const aborted = (e as Error)?.name === "AbortError";
    return { success: false, code: aborted ? "TIMEOUT" : "NETWORK", error: aborted ? `No response from ${path} after ${timeoutMs / 1000}s.` : "Network error — the server could not be reached.", hint: aborted ? "The database is probably unreachable from the server. Check DATABASE_URL and use a pooled connection string." : "Check your connection and that the deployment is live." };
  } finally {
    clearTimeout(timer);
  }
}