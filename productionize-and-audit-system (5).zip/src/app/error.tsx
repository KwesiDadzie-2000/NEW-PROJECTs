"use client";

import { AlertTriangle, RotateCcw } from "lucide-react";

export default function GlobalError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <div className="min-h-[70vh] flex items-center justify-center p-6">
      <div className="panel p-8 max-w-md w-full text-center rise border-l-4 !border-l-clay">
        <div className="mx-auto w-12 h-12 rounded-xl bg-[#fbeae6] text-clay flex items-center justify-center"><AlertTriangle className="w-6 h-6" /></div>
        <div className="font-mono text-[10px] tracking-[0.25em] text-slate-400 uppercase mt-4">Posting interrupted</div>
        <h1 className="font-display font-black text-[22px] mt-1">Something broke mid-entry.</h1>
        <p className="text-[13px] text-slate-600 mt-2 leading-relaxed">
          The ledger is safe — every document commits atomically, so nothing was half-posted. Retry the view; if it persists, run the System Audit.
        </p>
        {error.digest && <p className="font-mono text-[10.5px] text-slate-400 mt-2">ref {error.digest}</p>}
        <button onClick={reset} className="btn btn-primary mt-5 mx-auto"><RotateCcw className="w-4 h-4" /> Retry</button>
      </div>
    </div>
  );
}