"use client";

import { useEffect, useState } from "react";
import { ScanSearch, ShieldX, Landmark, FileCheck2, Fingerprint, History, BookOpenCheck, AlertTriangle } from "lucide-react";
import { PageHead, useClients, useToast, api, fmt, Badge, ClientPicker, Notice } from "@/components/ui";

interface Extraction {
  docType: string; companyCode: string | null; clientCode: string | null; clientName: string | null;
  confidence: number; date: string | null; partner: string | null; netAmount: number | null; vatAmount: number | null;
  grossAmount: number | null; vatTreatment: string;
  bankInfo: { bankName: string; sortCode: string | null; accountNumber: string | null } | null;
  evidence: Array<{ kind: string; detail: string; weight: number }>;
  rejectedCodes: Array<{ code: string; reason: string }>;
  suggestedLines: Array<{ accountCode: string; side: "D" | "C"; amount: number; itemText?: string }>;
  warnings: string[];
}
interface DocRow { id: number; companyCode: string | null; docType: string; status: string; confidence: number; createdAt: string }

export default function ProcessingPage() {
  const { clients } = useClients();
  const toast = useToast();
  const [text, setText] = useState("");
  const [samples, setSamples] = useState<Record<string, string>>({});
  const [history, setHistory] = useState<DocRow[]>([]);
  const [analyzing, setAnalyzing] = useState(false);
  const [posting, setPosting] = useState(false);
  const [docId, setDocId] = useState<number | null>(null);
  const [ex, setEx] = useState<Extraction | null>(null);
  const [override, setOverride] = useState("");

  const loadHistory = async () => {
    const d = await api("/api/documents");
    if (d.success) { setHistory(d.docs); setSamples(d.samples); }
  };
  useEffect(() => { loadHistory(); }, []);

  const analyze = async () => {
    setAnalyzing(true); setEx(null); setDocId(null);
    const d = await api("/api/documents", "POST", { action: "ANALYZE", text });
    setAnalyzing(false);
    if (d.success) { setEx(d.extraction); setDocId(d.doc.id); setOverride(d.extraction.companyCode || ""); loadHistory(); }
    else toast.err(d.error);
  };

  const post = async () => {
    if (!docId) return;
    setPosting(true);
    const d = await api("/api/documents", "POST", { action: "POST", docId, companyCode: override || undefined });
    setPosting(false);
    if (d.success) { toast.ok(d.message); setEx(null); setDocId(null); setText(""); loadHistory(); }
    else toast.err(d.error);
  };

  return (
    <div>
      {toast.node}
      <PageHead
        tcode="DOC-AI · Document Intelligence"
        title="Process documents without code confusion."
        sub="Bank sort codes, SWIFT/BIC and bank account numbers are detected first and quarantined as counterparty metadata. The company code can only resolve to a registered CLIENT ledger — via label, TIN, owned bank account or name."
      />

      <div className="grid lg:grid-cols-2 gap-4">
        <div className="panel p-5 rise rise-1">
          <div className="flex items-center justify-between mb-2">
            <h2 className="font-display font-bold text-[15px] flex items-center gap-2"><ScanSearch className="w-4 h-4 text-leaf" /> Source document</h2>
            <div className="flex gap-1.5">
              {Object.entries(samples).map(([k, v]) => (
                <button key={k} onClick={() => { setText(v); setEx(null); }} className="btn btn-ghost !px-2.5 !py-1 !text-[11px] capitalize">{k}</button>
              ))}
            </div>
          </div>
          <p className="text-[11.5px] text-slate-500 mb-2">Samples target the demo client <b>Adom Farms & Produce Ltd</b> — load the demo practice on the overview first, or paste any real client document.</p>
          <div className="relative rounded-lg overflow-hidden border border-[#cfd8cf]">
            {analyzing && <div className="scanline z-10" />}
            <textarea
              value={text} onChange={(e) => setText(e.target.value)} rows={14}
              placeholder={"Paste an invoice, payment advice, receipt or bank statement…\n\nThe engine will resolve the owning client and show every rejected bank code with the reason."}
              className="w-full font-mono text-[12px] p-3 bg-[#fbfcfa] resize-y border-0 focus:!shadow-none"
            />
          </div>
          <div className="flex items-center justify-between mt-3">
            <span className="text-[11.5px] text-slate-500">{text.length.toLocaleString()} characters</span>
            <button className="btn btn-gold" onClick={analyze} disabled={analyzing || text.trim().length < 10}>
              <ScanSearch className="w-4 h-4" /> {analyzing ? "Analysing…" : "Analyse document"}
            </button>
          </div>
        </div>

        <div className="space-y-3">
          {!ex && !analyzing && (
            <div className="panel p-6 rise rise-2">
              <h3 className="font-display font-bold text-[15px] flex items-center gap-2 mb-2"><Fingerprint className="w-4 h-4 text-leaf" /> How resolution works</h3>
              <ol className="text-[13px] text-slate-600 space-y-2 list-none">
                {[
                  ["1", "Bank identifiers first", "Sort codes, SWIFT/BIC and bank names are matched against the bank registry and quarantined — even if the document mislabels them as “Company Code”."],
                  ["2", "Client evidence scoring", "Explicit client company code (60) → TIN (55) → the client's own bank account (50) → client reference (45) → business name (40)."],
                  ["3", "Guarded posting", "Unresolved documents cannot post. Every posting is validated: balanced lines, valid accounts, open period, registered client."],
                ].map(([n, t, d]) => (
                  <li key={n} className="flex gap-3">
                    <span className="w-6 h-6 rounded-full bg-ink text-gold font-mono text-[11px] font-bold flex items-center justify-center shrink-0 mt-0.5">{n}</span>
                    <span><b className="text-ink">{t}.</b> {d}</span>
                  </li>
                ))}
              </ol>
            </div>
          )}
          {analyzing && <div className="panel p-8 text-center rise"><div className="font-mono text-[12px] text-leaf animate-pulse">RESOLVING ENTITY · SCORING EVIDENCE · QUARANTINING BANK CODES…</div></div>}

          {ex && (
            <>
              <div className={`panel p-5 rise border-l-4 ${ex.companyCode ? "!border-l-leaf" : "!border-l-clay"}`}>
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="text-[10.5px] uppercase tracking-widest font-extrabold text-slate-500">Resolved ledger owner</div>
                    {ex.companyCode ? (
                      <>
                        <div className="font-display font-black text-[20px] text-ink mt-1">{ex.clientName}</div>
                        <div className="mt-1 flex items-center gap-2">
                          <span className="font-mono font-bold text-leaf bg-leaf-soft px-2 py-0.5 rounded">{ex.companyCode}</span>
                          <span className="font-mono text-[11.5px] text-slate-500">{ex.clientCode}</span>
                          <Badge tone="blue">{ex.docType.replace(/_/g, " ")}</Badge>
                        </div>
                      </>
                    ) : (
                      <div className="font-display font-bold text-[16px] text-clay mt-1">No client resolved — select manually below</div>
                    )}
                  </div>
                  <div className="text-right shrink-0">
                    <div className="font-mono font-black text-[22px] tnum">{ex.confidence}%</div>
                    <div className="text-[10px] uppercase font-bold text-slate-400">confidence</div>
                    <div className="w-24 h-1.5 bg-slate-100 rounded-full mt-1 overflow-hidden"><div className={`h-full barfill ${ex.confidence > 60 ? "bg-leaf" : "bg-gold"}`} style={{ width: `${ex.confidence}%` }} /></div>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-2 mt-3 text-center">
                  {[["Net", ex.netAmount], ["VAT + levies", ex.vatAmount], ["Gross", ex.grossAmount]].map(([l, v]) => (
                    <div key={l as string} className="bg-[#f6f8f5] rounded-lg py-2">
                      <div className="text-[10px] uppercase font-bold text-slate-500">{l}</div>
                      <div className="font-mono font-bold text-[13.5px] tnum">{v == null ? "—" : fmt(v as number)}</div>
                    </div>
                  ))}
                </div>
                <div className="text-[11.5px] text-slate-500 mt-2">Date {ex.date} · Treatment {ex.vatTreatment} · Partner {ex.partner || "—"}</div>
              </div>

              {ex.bankInfo && (
                <div className="panel p-4 rise rise-1 bg-[#fffdf5]">
                  <div className="flex items-center gap-2 font-bold text-[13px] text-[#8a6a08]"><Landmark className="w-4 h-4" /> {ex.bankInfo.bankName} — counterparty bank</div>
                  <div className="text-[12px] text-slate-600 mt-1 font-mono">Sort {ex.bankInfo.sortCode || "—"} · A/C {ex.bankInfo.accountNumber || "—"} · role COUNTERPARTY_BANK</div>
                </div>
              )}

              {ex.rejectedCodes.length > 0 && (
                <div className="panel p-4 rise rise-2">
                  <div className="flex items-center gap-2 font-bold text-[13px] text-clay mb-2"><ShieldX className="w-4 h-4" /> Rejected identifiers ({ex.rejectedCodes.length})</div>
                  <div className="space-y-1.5">
                    {ex.rejectedCodes.map((r, i) => (
                      <div key={i} className="flex items-start gap-2 text-[12px]">
                        <span className="font-mono font-bold bg-[#fbeae6] text-[#a33322] px-1.5 py-0.5 rounded line-through shrink-0">{r.code}</span>
                        <span className="text-slate-600">{r.reason}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {ex.evidence.length > 0 && (
                <div className="panel p-4 rise rise-3">
                  <div className="font-bold text-[13px] text-leaf mb-2 flex items-center gap-2"><FileCheck2 className="w-4 h-4" /> Resolution evidence</div>
                  {ex.evidence.map((e, i) => (
                    <div key={i} className="flex items-start gap-2 text-[12px] py-0.5">
                      <span className="font-mono text-[10px] font-bold bg-leaf-soft text-leaf px-1.5 py-0.5 rounded shrink-0">+{e.weight}</span>
                      <span className="text-slate-600">{e.detail}</span>
                    </div>
                  ))}
                </div>
              )}

              {ex.warnings.map((w, i) => <Notice key={i} kind="info">{w}</Notice>)}

              <div className="panel p-4 rise rise-4">
                <div className="font-bold text-[13px] mb-2 flex items-center gap-2"><BookOpenCheck className="w-4 h-4 text-leaf" /> Post to ledger</div>
                {ex.suggestedLines.length > 0 && (
                  <table className="ledger-table mb-3">
                    <thead><tr><th>Account</th><th>Dr/Cr</th><th className="!text-right">Amount</th><th>Item</th></tr></thead>
                    <tbody>
                      {ex.suggestedLines.map((l, i) => (
                        <tr key={i}><td className="font-mono font-semibold">{l.accountCode}</td><td><Badge tone={l.side === "D" ? "blue" : "gold"}>{l.side === "D" ? "Debit" : "Credit"}</Badge></td><td className="text-right font-mono tnum">{fmt(l.amount)}</td><td className="text-slate-500">{l.itemText}</td></tr>
                      ))}
                    </tbody>
                  </table>
                )}
                <div className="flex flex-wrap items-end gap-2">
                  <div className="flex-1 min-w-[220px]">
                    <label className="flabel">Client ledger {ex.companyCode ? "(confirmed)" : "(required)"}</label>
                    <ClientPicker clients={clients} value={override} onChange={setOverride} />
                  </div>
                  <button className="btn btn-primary" onClick={post} disabled={posting || !override || ex.suggestedLines.length === 0}>
                    {posting ? "Posting…" : "Post document"}
                  </button>
                </div>
                {!override && <p className="text-[11.5px] text-clay mt-2 flex items-center gap-1"><AlertTriangle className="w-3.5 h-3.5" /> Posting is locked until a registered client ledger is selected.</p>}
              </div>
            </>
          )}
        </div>
      </div>

      <div className="panel p-5 mt-4 rise rise-3">
        <h2 className="font-display font-bold text-[15px] flex items-center gap-2 mb-3"><History className="w-4 h-4 text-leaf" /> Processing history</h2>
        {history.length === 0 ? <p className="text-[13px] text-slate-500 text-center py-4">Nothing processed yet.</p> : (
          <table className="ledger-table">
            <thead><tr><th>Doc</th><th>Type</th><th>Resolved ledger</th><th>Confidence</th><th>Status</th><th>Processed</th></tr></thead>
            <tbody>
              {history.slice(0, 12).map((h) => (
                <tr key={h.id}>
                  <td className="font-mono">DOC-{h.id}</td>
                  <td>{h.docType.replace(/_/g, " ")}</td>
                  <td>{h.companyCode ? <Badge tone="blue">{h.companyCode}</Badge> : <span className="text-slate-400">unresolved</span>}</td>
                  <td className="font-mono">{h.confidence}%</td>
                  <td><Badge tone={h.status === "POSTED" ? "green" : h.status === "REJECTED" ? "red" : "gold"}>{h.status}</Badge></td>
                  <td className="text-slate-500 text-[12px]">{new Date(h.createdAt).toLocaleString("en-GB")}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}