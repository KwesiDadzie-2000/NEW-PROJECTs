CREATE TABLE "accounts" (
	"id" serial PRIMARY KEY NOT NULL,
	"company_code" text NOT NULL,
	"code" text NOT NULL,
	"name" text NOT NULL,
	"type" text NOT NULL,
	"is_bank" boolean DEFAULT false NOT NULL
);
--> statement-breakpoint
CREATE TABLE "audit_log" (
	"id" serial PRIMARY KEY NOT NULL,
	"company_code" text,
	"actor" text DEFAULT 'owner' NOT NULL,
	"action" text NOT NULL,
	"detail" text DEFAULT '' NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "bank_accounts" (
	"id" serial PRIMARY KEY NOT NULL,
	"company_code" text NOT NULL,
	"bank_name" text NOT NULL,
	"sort_code" text DEFAULT '' NOT NULL,
	"account_number" text NOT NULL,
	"account_name" text NOT NULL,
	"currency" text DEFAULT 'GHS' NOT NULL,
	"gl_account" text DEFAULT '100200' NOT NULL
);
--> statement-breakpoint
CREATE TABLE "clients" (
	"id" serial PRIMARY KEY NOT NULL,
	"client_code" text NOT NULL,
	"company_code" text NOT NULL,
	"business_name" text NOT NULL,
	"sector" text DEFAULT 'SERVICES' NOT NULL,
	"currency" text DEFAULT 'GHS' NOT NULL,
	"tin" text DEFAULT '' NOT NULL,
	"contact_person" text DEFAULT '' NOT NULL,
	"email" text DEFAULT '' NOT NULL,
	"phone" text DEFAULT '' NOT NULL,
	"status" text DEFAULT 'ACTIVE' NOT NULL,
	"monthly_fee" numeric(14, 2) DEFAULT '0' NOT NULL,
	"is_test" boolean DEFAULT false NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "invoices" (
	"id" serial PRIMARY KEY NOT NULL,
	"company_code" text NOT NULL,
	"invoice_no" text NOT NULL,
	"kind" text NOT NULL,
	"partner" text NOT NULL,
	"invoice_date" text NOT NULL,
	"due_date" text NOT NULL,
	"net_amount" numeric(16, 2) NOT NULL,
	"vat_amount" numeric(16, 2) DEFAULT '0' NOT NULL,
	"nhil_amount" numeric(16, 2) DEFAULT '0' NOT NULL,
	"getfund_amount" numeric(16, 2) DEFAULT '0' NOT NULL,
	"wht_rate" numeric(6, 2) DEFAULT '0' NOT NULL,
	"wht_amount" numeric(16, 2) DEFAULT '0' NOT NULL,
	"vat_withheld" numeric(16, 2) DEFAULT '0' NOT NULL,
	"gross_total" numeric(16, 2) NOT NULL,
	"amount_paid" numeric(16, 2) DEFAULT '0' NOT NULL,
	"balance" numeric(16, 2) NOT NULL,
	"status" text DEFAULT 'OPEN' NOT NULL,
	"entry_id" integer,
	"description" text DEFAULT '' NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "journal_entries" (
	"id" serial PRIMARY KEY NOT NULL,
	"company_code" text NOT NULL,
	"doc_number" text NOT NULL,
	"doc_type" text NOT NULL,
	"posting_date" text NOT NULL,
	"header_text" text DEFAULT '' NOT NULL,
	"reference" text DEFAULT '' NOT NULL,
	"total_debit" numeric(16, 2) NOT NULL,
	"total_credit" numeric(16, 2) NOT NULL,
	"status" text DEFAULT 'POSTED' NOT NULL,
	"reversal_of" integer,
	"source" text DEFAULT 'MANUAL' NOT NULL,
	"created_by" text DEFAULT 'owner' NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "journal_lines" (
	"id" serial PRIMARY KEY NOT NULL,
	"entry_id" integer NOT NULL,
	"account_code" text NOT NULL,
	"side" text NOT NULL,
	"amount" numeric(16, 2) NOT NULL,
	"item_text" text DEFAULT '' NOT NULL
);
--> statement-breakpoint
CREATE TABLE "periods" (
	"id" serial PRIMARY KEY NOT NULL,
	"company_code" text NOT NULL,
	"fiscal_year" integer NOT NULL,
	"period" integer NOT NULL,
	"status" text DEFAULT 'OPEN' NOT NULL,
	"closed_by" text DEFAULT '' NOT NULL,
	"closed_at" timestamp
);
--> statement-breakpoint
CREATE TABLE "processed_docs" (
	"id" serial PRIMARY KEY NOT NULL,
	"company_code" text,
	"doc_type" text DEFAULT 'UNKNOWN' NOT NULL,
	"source_text" text NOT NULL,
	"extraction" jsonb NOT NULL,
	"status" text DEFAULT 'EXTRACTED' NOT NULL,
	"confidence" integer DEFAULT 0 NOT NULL,
	"entry_id" integer,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "sessions" (
	"id" serial PRIMARY KEY NOT NULL,
	"token_hash" text NOT NULL,
	"user_id" integer NOT NULL,
	"expires_at" timestamp NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "statement_lines" (
	"id" serial PRIMARY KEY NOT NULL,
	"bank_account_id" integer NOT NULL,
	"line_date" text NOT NULL,
	"description" text DEFAULT '' NOT NULL,
	"debit" numeric(16, 2) DEFAULT '0' NOT NULL,
	"credit" numeric(16, 2) DEFAULT '0' NOT NULL,
	"suggested_account" text DEFAULT '100200' NOT NULL,
	"status" text DEFAULT 'UNMATCHED' NOT NULL,
	"entry_id" integer
);
--> statement-breakpoint
CREATE TABLE "test_runs" (
	"id" serial PRIMARY KEY NOT NULL,
	"passed" integer DEFAULT 0 NOT NULL,
	"failed" integer DEFAULT 0 NOT NULL,
	"total" integer DEFAULT 0 NOT NULL,
	"duration_ms" integer DEFAULT 0 NOT NULL,
	"results" jsonb NOT NULL,
	"ran_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "users" (
	"id" serial PRIMARY KEY NOT NULL,
	"username" text NOT NULL,
	"full_name" text NOT NULL,
	"role" text NOT NULL,
	"password_hash" text NOT NULL,
	"status" text DEFAULT 'ACTIVE' NOT NULL,
	"failed_attempts" integer DEFAULT 0 NOT NULL,
	"locked_until" timestamp,
	"last_login" timestamp,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX "accounts_company_code_uq" ON "accounts" USING btree ("company_code","code");--> statement-breakpoint
CREATE UNIQUE INDEX "clients_client_code_uq" ON "clients" USING btree ("client_code");--> statement-breakpoint
CREATE UNIQUE INDEX "clients_company_code_uq" ON "clients" USING btree ("company_code");--> statement-breakpoint
CREATE UNIQUE INDEX "je_company_doc_uq" ON "journal_entries" USING btree ("company_code","doc_number");--> statement-breakpoint
CREATE UNIQUE INDEX "periods_company_year_period_uq" ON "periods" USING btree ("company_code","fiscal_year","period");--> statement-breakpoint
CREATE UNIQUE INDEX "users_username_uq" ON "users" USING btree ("username");