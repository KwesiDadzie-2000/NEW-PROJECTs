import { ensureSeedUsers, login, logout, currentUser, changePassword } from "@/lib/server/auth";
import { dbGuard } from "@/db/ensure";

export const dynamic = "force-dynamic";

const fail = (err: unknown) =>
  Response.json({ success: false, code: "SERVER_ERROR", error: err instanceof Error ? err.message : String(err), hint: "Open /api/health for a full diagnosis." }, { status: 500 });

export async function GET() {
  try {
    const blocked = await dbGuard();
    if (blocked) return blocked;
    await ensureSeedUsers();
    const user = await currentUser();
    if (!user) return Response.json({ success: false, code: "UNAUTHENTICATED" }, { status: 401 });
    return Response.json({ success: true, user });
  } catch (err) {
    return fail(err);
  }
}

export async function POST(req: Request) {
  try {
    const blocked = await dbGuard();
    if (blocked) return blocked;
    const body = await req.json().catch(() => ({}));
    if (body.action === "LOGOUT") {
      await logout();
      return Response.json({ success: true });
    }
    if (body.action === "CHANGE_PASSWORD") {
      const me = await currentUser();
      if (!me) return Response.json({ success: false, error: "Authentication required." }, { status: 401 });
      const res = await changePassword(me.id, String(body.currentPassword || ""), String(body.newPassword || ""));
      return Response.json(res.ok ? { success: true } : { success: false, error: res.error }, { status: res.ok ? 200 : 400 });
    }
    if (!body.username || !body.password) return Response.json({ success: false, error: "Username and password are required." }, { status: 400 });
    const res = await login(String(body.username), String(body.password));
    return Response.json(res.ok ? { success: true, user: res.user } : { success: false, error: res.error }, { status: res.ok ? 200 : 401 });
  } catch (err) {
    return fail(err);
  }
}