import { db } from "@/db";
import { invoices } from "@/db/schema";
import { eq } from "drizzle-orm";
import { requireUser } from "@/lib/server/auth";
import { trialBalance } from "@/lib/server/ledger";
import { getClientByCompany } from "@/lib/server/coa";
import { r2 } from "@/lib/server/ghana-tax";

export const dynamic = "force-dynamic";

const DAY = 86400000;
function agingBuckets(rows: Array<{ partner: string; invoiceNo: string; dueDate: string; balance: string; kind: string }>, asOf: string) {
  const t = new Date(asOf).getTime();
  const out = new Map<string, { partner: string; current: number; d30: number; d60: number; d90: number; d90plus: number; total: number; items: number }>();
  for (const r of rows) {
    const bal = Number(r.balance);
    if (bal < 0.01) continue;
    const days = Math.floor((t - new Date(r.dueDate).getTime()) / DAY);
    const e = out.get(r.partner) || { partner: r.partner, current: 0, d30: 0, d60: 0, d90: 0, d90plus: 0, total: 0, items: 0 };
    if (days <= 0) e.current += bal; else if (days <= 30) e.d30 += bal; else if (days <= 60) e.d60 += bal; else if (days <= 90) e.d90 += bal; else e.d90plus += bal;
    e.total += bal; e.items += 1;
    out.set(r.partner, e);
  }
  return [...out.values()].map((e) => ({ ...e, current: r2(e.current), d30: r2(e.d30), d60: r2(e.d60), d90: r2(e.d90), d90plus: r2(e.d90plus), total: r2(e.total) })).sort((a, b) => b.total - a.total);
}

export async function GET(req: Request) {
  const auth = await requireUser();
  if (auth instanceof Response) return auth;
  const url = new URL(req.url);
  const cc = url.searchParams.get("companyCode");
  const asOf = url.searchParams.get("asOf") || "2026-02-28";
  if (!cc) return Response.json({ success: false, error: "companyCode required." }, { status: 400 });
  const client = await getClientByCompany(cc);
  if (!client) return Response.json({ success: false, error: "Unknown client ledger." }, { status: 404 });
  const tb = await trialBalance(cc);

  const active = tb.rows.filter((r) => r.balance !== 0);
  const assets = active.filter((r) => r.type === "ASSET").map((r) => ({ code: r.code, name: r.name, amount: r.balance }));
  const liabilities = active.filter((r) => r.type === "LIABILITY").map((r) => ({ code: r.code, name: r.name, amount: r2(-r.balance) }));
  const equity = active.filter((r) => r.type === "EQUITY").map((r) => ({ code: r.code, name: r.name, amount: r2(-r.balance) }));
  const totalAssets = r2(assets.reduce((t, r) => t + r.amount, 0));
  const totalLiabilities = r2(liabilities.reduce((t, r) => t + r.amount, 0));
  const totalEquity = r2(equity.reduce((t, r) => t + r.amount, 0));
  const revenueLines = active.filter((r) => r.type === "REVENUE").map((r) => ({ code: r.code, name: r.name, amount: r2(-r.balance) }));
  const expenseLines = active.filter((r) => r.type === "EXPENSE").map((r) => ({ code: r.code, name: r.name, amount: r.balance }));

  const invs = await db.select().from(invoices).where(eq(invoices.companyCode, cc));
  const balanceSheet = {
    assets, liabilities, equity, profitForPeriod: tb.profit,
    totalAssets, totalLiabilities, totalEquity,
    totalEquityAndProfit: r2(totalEquity + tb.profit),
    balances: Math.abs(totalAssets - r2(totalLiabilities + totalEquity + tb.profit)) < 0.01,
  };
  const incomeStatement = { revenueLines, expenseLines, revenue: tb.revenue, expense: tb.expense, profit: tb.profit, margin: tb.revenue > 0 ? r2((tb.profit / tb.revenue) * 100) : 0 };
  return Response.json({
    success: true, client: { businessName: client.businessName, companyCode: cc, currency: client.currency, sector: client.sector },
    asOf, balanceSheet, incomeStatement,
    arAging: agingBuckets(invs.filter((i) => i.kind === "AR"), asOf),
    apAging: agingBuckets(invs.filter((i) => i.kind === "AP"), asOf),
    preparedBy: auth.fullName, trialBalance: tb,
  });
}