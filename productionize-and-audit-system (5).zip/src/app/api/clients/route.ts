import { db } from "@/db";
import { clients, invoices, journalEntries, auditLog } from "@/db/schema";
import { eq } from "drizzle-orm";
import { provisionClient, SECTORS } from "@/lib/server/coa";
import { postEntry, trialBalance, listClients } from "@/lib/server/ledger";
import { createInvoice } from "@/lib/server/operations";
import { requireUser, CONTROL_ROLES } from "@/lib/server/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  const auth = await requireUser();
  if (auth instanceof Response) return auth;
  const rows = await listClients();
  const summaries = await Promise.all(rows.map(async (c) => {
    const tb = await trialBalance(c.companyCode);
    const invs = await db.select().from(invoices).where(eq(invoices.companyCode, c.companyCode));
    const entries = await db.select().from(journalEntries).where(eq(journalEntries.companyCode, c.companyCode));
    return {
      ...c,
      documents: entries.length,
      revenue: tb.revenue,
      openAr: invs.filter((i) => i.kind === "AR").reduce((t, i) => t + Number(i.balance), 0),
      openAp: invs.filter((i) => i.kind === "AP").reduce((t, i) => t + Number(i.balance), 0),
      balanced: tb.isBalanced,
    };
  }));
  return Response.json({ success: true, clients: summaries, sectors: SECTORS });
}

export async function POST(req: Request) {
  const auth = await requireUser(CONTROL_ROLES);
  if (auth instanceof Response) return auth;
  const body = await req.json().catch(() => ({}));
  if (body.action === "SEED_DEMO") {
    const existing = await listClients();
    if (existing.length > 0) return Response.json({ success: false, error: "Demo practice already loaded — real client ledgers exist." }, { status: 400 });
    const demo = [
      { businessName: "Adom Farms & Produce Ltd", sector: "AGRI", tin: "C0012345678", contactPerson: "Akosua Adom", email: "accounts@adomfarms.gh", bankName: "GCB Bank PLC", sortCode: "040", accountNumber: "1400015838", capital: 350000 },
      { businessName: "Tema Steelworks Ltd", sector: "MANUF", tin: "C0023456789", contactPerson: "Kwame Asante", email: "finance@temasteel.gh", bankName: "Ecobank Ghana PLC", sortCode: "130", accountNumber: "1300088214", capital: 900000 },
      { businessName: "Accra Advisory Partners", sector: "SERVICES", tin: "C0034567890", contactPerson: "Efua Mensimah", email: "billing@accraadvisory.gh", bankName: "Stanbic Bank Ghana", sortCode: "190", accountNumber: "1900045577", capital: 150000 },
    ];
    const created = [];
    for (const d of demo) {
      const c = await provisionClient(d);
      await postEntry({ companyCode: c.companyCode, docType: "SA", postingDate: "2026-01-02", headerText: "Opening capital", lines: [{ accountCode: "100200", side: "D", amount: d.capital }, { accountCode: "300000", side: "C", amount: d.capital }], source: "MANUAL", createdBy: auth.username });
      created.push(c);
    }
    await createInvoice({ companyCode: created[1].companyCode, kind: "AR", partner: "Volta Construction Consortium", invoiceDate: "2026-02-04", dueDate: "2026-03-06", netAmount: 84000, whtRate: 3, description: "Fabricated steel sections — works supply" });
    await createInvoice({ companyCode: created[2].companyCode, kind: "AR", partner: "Coastal Hotels Group", invoiceDate: "2026-02-06", dueDate: "2026-03-08", netAmount: 42000, whtRate: 7.5, description: "IFRS readiness advisory — February retainer" });
    await createInvoice({ companyCode: created[0].companyCode, kind: "AP", partner: "AgroChem Supplies Ghana", invoiceDate: "2026-02-08", netAmount: 18000, whtRate: 3, description: "Fertiliser & crop protection inputs" });
    return Response.json({ success: true, message: "Demo practice loaded: 3 client ledgers with opening balances and live invoices.", clients: created });
  }
  if (!body.businessName || !body.sector) return Response.json({ success: false, error: "businessName and sector are required." }, { status: 400 });
  const client = await provisionClient(body);
  return Response.json({ success: true, client, message: `Client ${client.clientCode} provisioned with its OWN company code ${client.companyCode} (ledger, COA and bank account ready).` });
}

export async function PATCH(req: Request) {
  const auth = await requireUser(CONTROL_ROLES);
  if (auth instanceof Response) return auth;
  const body = await req.json().catch(() => ({}));
  const [c] = await db.select().from(clients).where(eq(clients.clientCode, body.clientCode || ""));
  if (!c) return Response.json({ success: false, error: "Client not found." }, { status: 404 });
  if (!["ACTIVE", "ONBOARDING", "SUSPENDED"].includes(body.status)) return Response.json({ success: false, error: "Invalid status." }, { status: 400 });
  await db.update(clients).set({ status: body.status }).where(eq(clients.id, c.id));
  await db.insert(auditLog).values({ companyCode: c.companyCode, action: "CLIENT_STATUS", detail: `${c.clientCode} → ${body.status}` });
  return Response.json({ success: true });
}