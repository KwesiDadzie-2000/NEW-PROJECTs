# BPZ Fiscal Ledger — Practice Edition

Production-grade, multi-client accounting for Ghanaian statutory practice: double-entry ledgers in PostgreSQL, document intelligence that **never confuses a bank's codes with the client's company code**, Act 1151 VAT / Act 1178 PAYE / SSNIT / WHT engines, role-based access with segregation of duties, OB52 period locks, financial statements, an 11-check system audit and a **357-assertion cross-sector regression suite**.

Built with **Next.js (App Router) · PostgreSQL · Drizzle ORM · Tailwind CSS · Chart.js**.

---

## Quick start (local)

```bash
npm install
cp .env.example .env            # point DATABASE_URL at your PostgreSQL
npx drizzle-kit migrate         # apply versioned migrations (or: npx drizzle-kit push)
npm run dev                     # http://localhost:3000
```

First sign-in seeds four personas (rotate them in **Access Control** before real use):

| Persona | Username | Password | Powers |
|---|---|---|---|
| System Owner | `owner` | `BpzOwner#2026` (or `ADMIN_PASSWORD`) | everything + user management + backups |
| Controller | `controller` | `Control#2026` | reversals, period close, QA suite |
| Accountant | `accountant` | `Accounts#2026` | posting, billing, banking |
| External Auditor | `auditor` | `Audit#2026` | read-only assurance |

Load the demo practice from the overview page, then run **Sector Test Suite → Run full suite** (357 assertions, 14 sectors, isolated QA ledgers destroyed afterwards) and **System Audit** (11 checks).

---

## Deploy

The app is a standard Next.js server with one dependency: `DATABASE_URL`.
Schema changes ship as versioned SQL in `drizzle/` — apply with `npx drizzle-kit migrate`.

> **Zero-touch schema:** on first request the app creates any missing tables/indexes itself (idempotent bootstrap in `src/db/bootstrap-sql.ts`). Running `drizzle-kit migrate` is optional.
> **Env var names accepted:** `DATABASE_URL`, `POSTGRES_URL`, `POSTGRES_PRISMA_URL`, `NEON_DATABASE_URL`, `SUPABASE_DB_URL`, so Vercel's Neon/Postgres integration works without renaming.
> **Diagnose any deployment:** open `https://<your-app>/api/health`. It reports `DB_NOT_CONFIGURED`, `DB_UNREACHABLE` or `DB_SCHEMA_FAILED` with the fix. The UI shows the same diagnosis instead of spinning.

### ▲ Vercel
1. Vercel → project → **Storage → Create Database → Neon (Postgres)** → connect it to the project (injects `POSTGRES_URL`/`DATABASE_URL` automatically). Or paste your own pooled URL (Neon `-pooler` host / Supabase port `6543`, with `?sslmode=require`) as `DATABASE_URL`.
2. Make sure the variable is enabled for **Production** (and Preview).
3. Optional: `ADMIN_PASSWORD` (strong), `PGPOOL_MAX=1`.
4. **Redeploy** (env changes only apply to new deployments). Visit `/api/health` and expect `"ok":true`.

### ◆ Netlify
1. Same database step as above.
2. Import the repo — `netlify.toml` wires the Next.js runtime (Node 22) automatically.
3. Set `DATABASE_URL`, `ADMIN_PASSWORD`, `PGPOOL_MAX=1` in Site settings → Environment.
4. Deploy; apply migrations as above.

### ● Render (one-click blueprint)
`render.yaml` provisions a Docker web service **and** a managed Postgres, wires `DATABASE_URL`, and health-checks `/api/health`. Push the repo, create a Blueprint, set `ADMIN_PASSWORD`, then run migrations from the Render shell: `npx drizzle-kit migrate`.

### 🐳 Docker / any VPS (Hetzner, DigitalOcean, Fly.io, Railway…)
```bash
docker compose up -d --build
```
Compose starts PostgreSQL 16, runs migrations as a one-shot job, then launches the hardened standalone image (non-root, ~small footprint) on port 3000. Put it behind Caddy/Nginx with TLS. Set `POSTGRES_PASSWORD` and `ADMIN_PASSWORD` in the shell or an `.env` file next to the compose file.

### Backups & DR
- In-app: **System Audit → Backup (owner)** downloads a full JSON export (credentials/sessions excluded).
- Database: schedule `pg_dump $DATABASE_URL` (or your provider's PITR). Test restores quarterly.

---

## Security model
- scrypt salted password hashes; hashed session tokens; httpOnly/SameSite cookies; 12-hour expiry.
- **DB-backed lockout**: 5 failed sign-ins → 15-minute lock (survives serverless recycling).
- RBAC enforced server-side on every route; auditors are read-only.
- **Segregation of duties**: a preparer can never reverse their own document.
- OB52 period locks per client; FY2025 and earlier permanently closed.
- Atomic postings (header + lines + audit trail in one transaction), race-safe document numbers.
- Security headers (X-Frame-Options, nosniff, Referrer-Policy, Permissions-Policy), `X-Powered-By` disabled.
- Immutable audit trail with named actors; CSV export for working papers.

**Before public exposure:** rotate all demo passwords, enable provider-level DDoS/WAF, schedule backups, and commission a penetration test. SSO/SAML + MFA and SOC 2 evidence are the enterprise roadmap.

## Changing the schema
Edit `src/db/schema.ts` → `npx drizzle-kit generate` → regenerate `src/db/bootstrap-sql.ts` from the new SQL (or add `ADD COLUMN IF NOT EXISTS` statements to it) so existing deployments self-upgrade on boot.

## Quality gates
```bash
npx next typegen && npx tsc --noEmit && npm run build
```
Then in-app: **Sector Test Suite** (357 assertions across AGRI, MINING, OILGAS, MANUF, CONST, TRADING, SERVICES, FINANCE, HEALTH, EDUC, TRANSPORT, HOSPITALITY, ICT, NGO) and **System Audit** (11 checks incl. COMPANY_CODE_INTEGRITY, BANK_ROUTING, SOD_REVERSALS, PERIOD_CONTROL).

## Statutory engine (Ghana, current law)
- **VAT Act 1151 (2026):** unified 20% on one base — 15% VAT + 2.5% NHIL + 2.5% GETFund; COVID levy abolished; levies deductible; no flat rate; 7% VAT withholding for appointed agents.
- **PAYE Act 1178:** first GH¢588/month tax-free, graduated to 35%; casual 5% final; non-resident 25%.
- **SSNIT:** 5.5% employee / 13% employer, GH¢69,000 monthly cap.
- **WHT:** 3% goods · 5% works · 7.5% services · 8/15% rent · 10% royalties · 20% NR/directors.
- GSL note: 2.5% PBT (5% banks/telecom) to 2028.