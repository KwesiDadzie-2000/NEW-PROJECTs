import { db } from "@/db";
import { bankAccounts, clients } from "@/db/schema";
import { calcVAT, vatFromInclusive, r2, type VatTreatment } from "./ghana-tax";
import type { PostLine } from "./ledger";

// ---------------------------------------------------------------------------
// DOCUMENT INTELLIGENCE — company code resolution
//
// BUG FIXED (reported): when processing documents the engine "picked the codes
// of the banks and not the actual clients". Root causes in the legacy build:
//   1. Clients were provisioned with a shared parent code ("BPZ3") — the same
//      code space used for bank/GL routing — so codes collided.
//   2. The parser grabbed the FIRST code-like token in the text. On bank
//      statements / payment advices that token is the BANK's sort code or the
//      bank's own institution code, so documents posted to the wrong entity.
//
// The fix below: bank identifiers are recognised FIRST and quarantined as
// counterparty metadata. The company code can only ever resolve to a
// registered CLIENT ledger, via (in priority order): explicit client company
// code label → client TIN → client's own bank account number → client name.
// ---------------------------------------------------------------------------

export interface BankDef { name: string; aliases: string[]; sortCodes: string[]; swift: string }
export const BANK_REGISTRY: BankDef[] = [
  { name: "GCB Bank PLC", aliases: ["gcb", "ghana commercial bank"], sortCodes: ["040", "04"], swift: "GHCBGHAC" },
  { name: "Ecobank Ghana PLC", aliases: ["ecobank"], sortCodes: ["130", "13"], swift: "ECOCGHAC" },
  { name: "Absa Bank Ghana", aliases: ["absa", "barclays"], sortCodes: ["030", "03"], swift: "BARBGHAC" },
  { name: "Stanbic Bank Ghana", aliases: ["stanbic"], sortCodes: ["190", "19"], swift: "SBICGHAC" },
  { name: "Fidelity Bank Ghana", aliases: ["fidelity"], sortCodes: ["240", "24"], swift: "FIDEGHAC" },
  { name: "CalBank PLC", aliases: ["calbank", "cal bank"], sortCodes: ["140", "14"], swift: "ACCCGHAC" },
  { name: "ADB Bank Limited", aliases: ["adb", "agricultural development bank"], sortCodes: ["080", "08"], swift: "ADNTGHAC" },
  { name: "Zenith Bank Ghana", aliases: ["zenith"], sortCodes: ["120", "12"], swift: "ZEBLGHAC" },
  { name: "UBA Ghana", aliases: ["uba", "united bank for africa"], sortCodes: ["060", "06"], swift: "STBLGHAC" },
  { name: "GTBank Ghana", aliases: ["gtbank", "guaranty trust", "gtco"], sortCodes: ["230", "23"], swift: "GTBIGHAC" },
  { name: "Bank of Ghana", aliases: ["bank of ghana", "bog"], sortCodes: ["010", "01"], swift: "BAGHGHAC" },
  { name: "JPMorgan Chase", aliases: ["jpmorgan", "chase"], sortCodes: ["021"], swift: "CHASUS33" },
];

export interface Evidence { kind: string; detail: string; weight: number }
export interface RejectedCode { code: string; reason: string }

export interface Extraction {
  docType: "TAX_INVOICE" | "BANK_STATEMENT_LINE" | "RECEIPT" | "PAYMENT_ADVICE" | "UNKNOWN";
  companyCode: string | null;
  clientCode: string | null;
  clientName: string | null;
  confidence: number;
  date: string | null;
  partner: string | null;
  netAmount: number | null;
  vatAmount: number | null;
  grossAmount: number | null;
  vatTreatment: VatTreatment;
  bankInfo: { bankName: string; sortCode: string | null; accountNumber: string | null; role: "COUNTERPARTY_BANK" } | null;
  evidence: Evidence[];
  rejectedCodes: RejectedCode[];
  suggestedLines: PostLine[];
  warnings: string[];
}

const DEFAULT_DATE = "2026-02-15";

function findBank(text: string) {
  const lower = text.toLowerCase();
  for (const b of BANK_REGISTRY) {
    if (b.aliases.some((a) => lower.includes(a)) || lower.includes(b.swift.toLowerCase())) {
      const sort = b.sortCodes.find((s) => new RegExp(`\\b${s}\\d{3}\\b|sort\\s*code[:\\s]*${s}\\b`, "i").test(text)) || null;
      return { bank: b, sortCode: sort };
    }
  }
  // sort code pattern without a recognised name
  const m = text.match(/sort\s*code[:\s]*([0-9]{3,6})/i);
  if (m) {
    const bank = BANK_REGISTRY.find((b) => b.sortCodes.some((s) => m[1].startsWith(s)));
    if (bank) return { bank, sortCode: m[1] };
    return { bank: { name: "Unrecognised bank", aliases: [], sortCodes: [m[1]], swift: "" }, sortCode: m[1] };
  }
  return null;
}

function parseAmounts(text: string) {
  const grab = (label: RegExp): number | null => {
    const m = text.match(label);
    if (!m) return null;
    const v = parseFloat(m[1].replace(/,/g, ""));
    return Number.isFinite(v) ? r2(v) : null;
  };
  const cur = "(?:gh[s¢c]?|ghc)?";
  const amt = "([\\d,]+\\.?\\d*)";
  const net = grab(new RegExp(`(?:\\bsub\\s*-?\\s*total|\\bnet\\s*(?:amount|value)?|\\bamount\\s*(?:excl\\.?|exclusive)[^:\\d]*|\\btaxable\\s*value)[:\\s]*${cur}\\s*${amt}`, "i"));
  const vat = grab(new RegExp(`(?:\\bvat\\s*(?:\\+?\\s*levies)?(?:\\s*@\\s*20\\s*%)?|\\boutput\\s*vat|\\btax\\s*amount)[:\\s]*${cur}\\s*${amt}`, "i"));
  // Word boundaries prevent "Subtotal" from being read as the gross "Total";
  // explicit grand-total labels win over any earlier generic "Total".
  const gross =
    grab(new RegExp(`\\bgrand\\s*total[:\\s]*${cur}\\s*${amt}`, "i")) ??
    grab(new RegExp(`\\b(?:invoice\\s*total|total\\s*(?:due|amount|payable)|amount\\s*due)[:\\s]*${cur}\\s*${amt}`, "i")) ??
    grab(new RegExp(`\\btotal[:\\s]*${cur}\\s*${amt}`, "i")) ??
    grab(new RegExp(`\\bamount[:\\s]*${cur}\\s*${amt}`, "i"));
  return { net, vat, gross };
}

function parseDate(text: string): string | null {
  const iso = text.match(/\b(20\d{2})-(\d{2})-(\d{2})\b/);
  if (iso) return `${iso[1]}-${iso[2]}-${iso[3]}`;
  const dmy = text.match(/\b(\d{1,2})[\/.](\d{1,2})[\/.](20\d{2})\b/);
  if (dmy) return `${dmy[3]}-${dmy[2].padStart(2, "0")}-${dmy[1].padStart(2, "0")}`;
  const months: Record<string, string> = { jan: "01", feb: "02", mar: "03", apr: "04", may: "05", jun: "06", jul: "07", aug: "08", sep: "09", oct: "10", nov: "11", dec: "12" };
  const dm = text.match(/\b(\d{1,2})\s+(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\s+(20\d{2})\b/i);
  if (dm) return `${dm[3]}-${months[dm[2].toLowerCase()]}-${dm[1].padStart(2, "0")}`;
  return null;
}

export async function extractDocument(sourceText: string): Promise<Extraction> {
  const text = sourceText.trim();
  const lower = text.toLowerCase();
  const allClients = (await db.select().from(clients)).filter((c) => c.status !== "SUSPENDED");
  const allBankAccounts = await db.select().from(bankAccounts);
  const evidence: Evidence[] = [];
  const rejectedCodes: RejectedCode[] = [];
  const warnings: string[] = [];

  // STEP 1 — quarantine bank identifiers BEFORE any company-code matching.
  const bankHit = findBank(text);
  const bankAccountDigits = text.match(/(?:a\/c|acct?|account)\s*(?:no\.?|number)?[:\s]*([\d][\d\s-]{7,20}\d)/i);
  const accountNumber = bankAccountDigits ? bankAccountDigits[1].replace(/[\s-]/g, "") : null;
  if (bankHit) {
    const sc = bankHit.sortCode || bankHit.bank.sortCodes[0];
    rejectedCodes.push({ code: sc, reason: `Sort code of ${bankHit.bank.name} — the bank is a counterparty, never the client company code.` });
    if (bankHit.bank.swift) rejectedCodes.push({ code: bankHit.bank.swift, reason: `SWIFT/BIC of ${bankHit.bank.name} — bank routing identifier, not a company code.` });
  }
  const bankAccountNumber = accountNumber && bankHit ? accountNumber : null;
  if (bankAccountNumber && !allBankAccounts.some((a) => a.accountNumber.replace(/\s/g, "") === bankAccountNumber)) {
    rejectedCodes.push({ code: bankAccountNumber, reason: `Bank account number at ${bankHit?.bank.name} — account identifiers are not company codes.` });
  }

  // STEP 2 — resolve the CLIENT ledger. Only registered client company codes qualify.
  let resolved: (typeof allClients)[number] | null = null;
  let bestScore = 0;

  const explicit = text.match(/(?:company\s*code|client\s*company|entity\s*code|bukrs)[:\s]*([A-Z][A-Z0-9]{1,7})\b/i);
  if (explicit) {
    const code = explicit[1].toUpperCase();
    const isBankCode = BANK_REGISTRY.some((b) =>
      b.sortCodes.includes(code) || b.swift === code ||
      b.aliases.some((a) => a.length >= 3 && code.toLowerCase().startsWith(a.replace(/\s/g, "")))
    );
    const match = allClients.find((c) => c.companyCode.toUpperCase() === code);
    if (isBankCode) {
      rejectedCodes.push({ code, reason: "Labelled as company code but belongs to a BANK institution — rejected to protect the ledger." });
      warnings.push(`The document labels "${code}" as company code, but it is a bank identifier. Resolving the true client by other evidence.`);
    } else if (match) {
      resolved = match; bestScore = 60;
      evidence.push({ kind: "COMPANY_CODE_LABEL", detail: `Explicit company code "${code}" matches client ${match.businessName} (${match.clientCode}).`, weight: 60 });
    } else {
      rejectedCodes.push({ code, reason: "Company code label not found in the client registry — posting would create an orphan ledger." });
      warnings.push(`Company code "${code}" is not a registered client.`);
    }
  }

  const score = (w: number, kind: string, detail: string, c: (typeof allClients)[number]) => {
    evidence.push({ kind, detail, weight: w });
    if (w > bestScore) { bestScore = w; resolved = c; }
  };

  for (const c of allClients) {
    if (c.tin && c.tin.length >= 6 && lower.includes(c.tin.toLowerCase())) {
      score(55, "TIN_MATCH", `TIN ${c.tin} on the document belongs to ${c.businessName}.`, c);
    }
    if (accountNumber) {
      const owned = allBankAccounts.find((a) => a.companyCode === c.companyCode && a.accountNumber.replace(/\s/g, "") === accountNumber);
      if (owned) score(50, "OWNED_BANK_ACCOUNT", `Account ${accountNumber} is ${c.businessName}'s own ${owned.bankName} account — the ledger owner is ${c.companyCode}, the bank remains counterparty.`, c);
    }
    const nameWords = c.businessName.toLowerCase().replace(/\b(ltd|limited|plc|ghana|inc|llc|company)\b/g, "").trim();
    if (nameWords.length >= 4 && lower.includes(nameWords)) {
      score(40, "CLIENT_NAME", `Client name "${c.businessName}" appears on the document.`, c);
    }
    if (lower.includes(c.clientCode.toLowerCase())) {
      score(45, "CLIENT_CODE", `Client reference ${c.clientCode} appears on the document.`, c);
    }
  }

  // STEP 3 — document classification & amounts.
  let docType: Extraction["docType"] = "UNKNOWN";
  if (/tax\s*invoice|invoice\s*(no|#|number)|bill\s*to/i.test(text)) docType = "TAX_INVOICE";
  else if (/payment\s*advice|remittance|transfer\s*confirmation|credit\s*advice/i.test(text)) docType = "PAYMENT_ADVICE";
  else if (/statement|opening\s*balance|closing\s*balance|value\s*date/i.test(text)) docType = "BANK_STATEMENT_LINE";
  else if (/receipt|received\s*(with\s*thanks|from)|paid\s*(by|via)/i.test(text)) docType = "RECEIPT";

  const { net, vat, gross } = parseAmounts(text);
  let treatment: VatTreatment = "STANDARD";
  if (/zero[-\s]?rated/i.test(text)) treatment = "ZERO";
  else if (/vat\s*exempt|exempt\s*(supply|from\s*vat)/i.test(text)) treatment = "EXEMPT";

  let netAmount = net; let vatAmount = vat; let grossAmount = gross;
  if (netAmount != null && treatment === "STANDARD") {
    const calc = calcVAT(netAmount);
    if (vatAmount == null) vatAmount = calc.leviesTotal;
    if (grossAmount == null) grossAmount = calc.gross;
  } else if (netAmount == null && grossAmount != null && treatment === "STANDARD" && /inclusive|incl\.?\s*vat/i.test(text)) {
    const calc = vatFromInclusive(grossAmount);
    netAmount = calc.base; vatAmount = calc.leviesTotal;
  } else if (netAmount == null && grossAmount != null) {
    netAmount = r2(grossAmount - (vatAmount || 0));
  }
  if (treatment !== "STANDARD") vatAmount = 0;

  // Reconciliation guard: net + levies must equal gross; repair and flag drift.
  if (netAmount != null && vatAmount != null && grossAmount != null && Math.abs(r2(netAmount + vatAmount) - grossAmount) > 0.02) {
    warnings.push(`Document totals did not reconcile (net ${netAmount} + VAT ${vatAmount} ≠ gross ${grossAmount}); gross recomputed as ${r2(netAmount + vatAmount)}.`);
    grossAmount = r2(netAmount + vatAmount);
  }

  const date = parseDate(text);
  const partnerMatch = text.match(/(?:bill\s*to|customer|client|supplier|from|payee)[:\s]*([A-Z][A-Za-z0-9&.,' -]{3,60})/);
  let partner = partnerMatch ? partnerMatch[1].trim().replace(/\s{2,}/g, " ") : null;
  if (partner && BANK_REGISTRY.some((b) => b.aliases.some((a) => partner!.toLowerCase().includes(a)))) {
    warnings.push(`"${partner}" is a bank — recorded as counterparty, not as the client.`);
  }

  // STEP 4 — suggested posting lines (revenue-side heuristic; user confirms).
  const suggestedLines: PostLine[] = [];
  if (netAmount != null && netAmount > 0) {
    if (docType === "TAX_INVOICE") {
      suggestedLines.push({ accountCode: "110000", side: "D", amount: r2(netAmount + (vatAmount || 0)), itemText: "Trade receivable" });
      suggestedLines.push({ accountCode: "400000", side: "C", amount: netAmount, itemText: "Revenue" });
      if ((vatAmount || 0) > 0) suggestedLines.push({ accountCode: "220000", side: "C", amount: vatAmount!, itemText: "Output VAT + levies (Act 1151)" });
    } else if (docType === "RECEIPT" || docType === "PAYMENT_ADVICE") {
      suggestedLines.push({ accountCode: "100200", side: "D", amount: grossAmount ?? netAmount, itemText: "Bank receipt" });
      suggestedLines.push({ accountCode: "110000", side: "C", amount: grossAmount ?? netAmount, itemText: "Clear receivable" });
    } else if (docType === "BANK_STATEMENT_LINE") {
      suggestedLines.push({ accountCode: "100200", side: "D", amount: grossAmount ?? netAmount, itemText: "Bank movement" });
      suggestedLines.push({ accountCode: "410000", side: "C", amount: grossAmount ?? netAmount, itemText: "Other operating income (review)" });
    }
  }

  const confidence = resolved ? Math.min(98, bestScore + (date ? 5 : 0) + (netAmount != null || grossAmount != null ? 10 : 0) + (docType !== "UNKNOWN" ? 10 : 0)) : Math.min(30, evidence.length * 5);
  if (!resolved) warnings.push("No registered client could be resolved from this document. Select the client manually before posting — the system will never guess a bank's code.");
  if (!date) warnings.push(`No date detected — defaulting to ${DEFAULT_DATE} for preview; confirm before posting.`);

  return {
    docType,
    companyCode: resolved ? resolved.companyCode : null,
    clientCode: resolved ? resolved.clientCode : null,
    clientName: resolved ? resolved.businessName : null,
    confidence,
    date: date || DEFAULT_DATE,
    partner, netAmount, vatAmount, grossAmount,
    vatTreatment: treatment,
    bankInfo: bankHit ? { bankName: bankHit.bank.name, sortCode: bankHit.sortCode, accountNumber: bankAccountNumber, role: "COUNTERPARTY_BANK" } : null,
    evidence, rejectedCodes, suggestedLines, warnings,
  };
}

export const SAMPLE_DOCS = {
  invoice: `TAX INVOICE
From: Adom Farms & Produce Ltd
TIN: C0012345678
Company Code: GCB040
Bill To: Melcom Trading Chain
Invoice No: INV-2026-0142
Date: 2026-02-10
Supply of processed cassava flour (standard rated)
Subtotal: GHS 25,000.00
VAT @ 20%: GHS 5,000.00
Grand Total: GHS 30,000.00
Payment to: GCB Bank PLC, Sort Code 040119, A/C No: 1400015838, SWIFT GHCBGHAC`,
  advice: `PAYMENT ADVICE — CREDIT CONFIRMATION
Beneficiary: Adom Farms & Produce Ltd
Bank: Ecobank Ghana PLC — Sort Code: 130205
Account No: 1400015838
Value Date: 12/02/2026
Amount: GHS 30,000.00
Reference: SETTLEMENT INV-2026-0142
Remitting Bank: Stanbic Bank Ghana (190)`,
  statement: `BANK STATEMENT — GCB BANK PLC (SORT CODE 040119)
Account Name: Adom Farms & Produce Ltd
A/C No: 1400015838
Statement Date: 2026-02-18
2026-02-18 | E-VAT SALES RECEIPT — Melcom Trading | Total: GHS 12,500.00`,
};