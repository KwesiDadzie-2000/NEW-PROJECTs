import { db } from "@/db";
import { journalLines, journalEntries, accounts, clients, invoices } from "@/db/schema";
import { eq, and, sql } from "drizzle-orm";
import { requireUser } from "@/lib/server/auth";
import { r2 } from "@/lib/server/ghana-tax";

export const dynamic = "force-dynamic";

export async function GET() {
  const auth = await requireUser();
  if (auth instanceof Response) return auth;

  // Monthly revenue vs expense across all real client ledgers (posted documents only).
  const rows = await db
    .select({
      month: sql<string>`substr(${journalEntries.postingDate}, 1, 7)`,
      type: accounts.type,
      amount: sql<string>`sum(case when ${journalLines.side} = 'D' then ${journalLines.amount}::numeric else -${journalLines.amount}::numeric end)`,
    })
    .from(journalLines)
    .innerJoin(journalEntries, eq(journalLines.entryId, journalEntries.id))
    .innerJoin(accounts, and(eq(accounts.companyCode, journalEntries.companyCode), eq(accounts.code, journalLines.accountCode)))
    .innerJoin(clients, eq(clients.companyCode, journalEntries.companyCode))
    .where(and(eq(clients.isTest, false), sql`${accounts.type} in ('REVENUE','EXPENSE')`))
    .groupBy(sql`substr(${journalEntries.postingDate}, 1, 7)`, accounts.type);

  const months = [...new Set(rows.map((r) => r.month))].sort();
  const series = months.map((m) => {
    const rev = rows.filter((r) => r.month === m && r.type === "REVENUE").reduce((t, r) => t - Number(r.amount), 0);
    const exp = rows.filter((r) => r.month === m && r.type === "EXPENSE").reduce((t, r) => t + Number(r.amount), 0);
    return { month: m, revenue: r2(rev), expense: r2(exp), profit: r2(rev - exp) };
  });

  // Revenue & open AR by client (sector mix).
  const allClients = (await db.select().from(clients)).filter((c) => !c.isTest);
  const invs = await db.select().from(invoices);
  const revByClient = await db
    .select({
      companyCode: journalEntries.companyCode,
      amount: sql<string>`sum(case when ${journalLines.side} = 'C' then ${journalLines.amount}::numeric else -${journalLines.amount}::numeric end)`,
    })
    .from(journalLines)
    .innerJoin(journalEntries, eq(journalLines.entryId, journalEntries.id))
    .innerJoin(accounts, and(eq(accounts.companyCode, journalEntries.companyCode), eq(accounts.code, journalLines.accountCode)))
    .where(eq(accounts.type, "REVENUE"))
    .groupBy(journalEntries.companyCode);
  const revMap = new Map(revByClient.map((r) => [r.companyCode, r2(Number(r.amount))]));
  const byClient = allClients.map((c) => ({
    companyCode: c.companyCode, name: c.businessName, sector: c.sector,
    revenue: revMap.get(c.companyCode) || 0,
    openAr: r2(invs.filter((i) => i.companyCode === c.companyCode && i.kind === "AR").reduce((t, i) => t + Number(i.balance), 0)),
  })).sort((a, b) => b.revenue - a.revenue);

  return Response.json({ success: true, series, byClient });
}