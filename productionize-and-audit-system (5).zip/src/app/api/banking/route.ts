import { db } from "@/db";
import { bankAccounts, invoices, statementLines } from "@/db/schema";
import { eq } from "drizzle-orm";
import { createBankAccount, importStatement, postStatementLine, settleInvoiceFromLine } from "@/lib/server/operations";
import { accountBalance } from "@/lib/server/ledger";
import { BANK_REGISTRY } from "@/lib/server/extract";
import { requireUser, POSTING_ROLES } from "@/lib/server/auth";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const auth = await requireUser();
  if (auth instanceof Response) return auth;
  const cc = new URL(req.url).searchParams.get("companyCode");
  if (!cc) return Response.json({ success: false, error: "companyCode required." }, { status: 400 });
  const accts = await db.select().from(bankAccounts).where(eq(bankAccounts.companyCode, cc));
  const withBalances = await Promise.all(accts.map(async (a) => ({ ...a, ledgerBalance: await accountBalance(cc, a.glAccount) })));
  const lines = [];
  for (const a of accts) {
    const ls = await db.select().from(statementLines).where(eq(statementLines.bankAccountId, a.id));
    lines.push(...ls);
  }
  const openInvoices = (await db.select().from(invoices).where(eq(invoices.companyCode, cc))).filter((i) => Number(i.balance) > 0.01 && i.kind === "AR");
  return Response.json({ success: true, accounts: withBalances, lines: lines.sort((x, y) => y.id - x.id), openInvoices, banks: BANK_REGISTRY.map((b) => ({ name: b.name, sortCodes: b.sortCodes })) });
}

export async function POST(req: Request) {
  const auth = await requireUser(POSTING_ROLES);
  if (auth instanceof Response) return auth;
  const body = await req.json().catch(() => ({}));
  body.createdBy = auth.username;
  const act = body.action;
  const res =
    act === "CREATE_ACCOUNT" ? await createBankAccount(body) :
    act === "IMPORT" ? await importStatement(body) :
    act === "POST_LINE" ? await postStatementLine(body) :
    act === "SETTLE" ? await settleInvoiceFromLine(body) :
    { ok: false as const, error: "Unknown banking action." };
  return Response.json(res.ok ? { success: true, ...res } : { success: false, error: res.error }, { status: res.ok ? 200 : 400 });
}