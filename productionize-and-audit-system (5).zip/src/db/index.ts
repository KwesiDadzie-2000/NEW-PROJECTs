import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";
import * as schema from "./schema";

// Every name hosts commonly inject: Vercel Marketplace Neon / Vercel Postgres,
// Neon, Supabase, Render, Railway, Heroku-style. Checked in priority order.
export const ENV_CANDIDATES = [
  "DATABASE_URL", "POSTGRES_URL", "POSTGRES_PRISMA_URL", "NEON_DATABASE_URL", "SUPABASE_DB_URL",
  "DATABASE_POSTGRES_URL", "STORAGE_URL", "POSTGRESQL_URL", "PG_URL", "DB_URL",
  "DATABASE_URL_UNPOOLED", "POSTGRES_URL_NON_POOLING", "POSTGRES_URL_NO_SSL",
];

/** Strip whitespace and accidental surrounding quotes, which are common paste mistakes in dashboards. */
const clean = (v: string | undefined) => (v || "").trim().replace(/^['"`]+|['"`]+$/g, "").trim();
const isPgUrl = (v: string) => /^postgres(ql)?:\/\//i.test(v);

interface Resolved { url: string | null; source: string | null; problem: string | null }

function resolve(): Resolved {
  // 1) Known names, plus any name ending in _DATABASE_URL / _POSTGRES_URL (Vercel adds custom prefixes).
  const dynamic = Object.keys(process.env).filter((k) => /(_DATABASE_URL|_POSTGRES_URL)$/.test(k) && !ENV_CANDIDATES.includes(k)).sort();
  let invalid: string | null = null;
  for (const k of [...ENV_CANDIDATES, ...dynamic]) {
    const v = clean(process.env[k]);
    if (!v) continue;
    if (isPgUrl(v)) return { url: v, source: k, problem: null };
    invalid ||= k;
  }
  // 2) Discrete libpq variables (Vercel/Neon integrations also inject PGHOST etc.).
  const host = clean(process.env.PGHOST || process.env.POSTGRES_HOST);
  const user = clean(process.env.PGUSER || process.env.POSTGRES_USER);
  const pass = clean(process.env.PGPASSWORD || process.env.POSTGRES_PASSWORD);
  const name = clean(process.env.PGDATABASE || process.env.POSTGRES_DATABASE);
  if (host && user && name) {
    const port = clean(process.env.PGPORT) || "5432";
    const local = /^(127\.0\.0\.1|localhost)$/.test(host);
    return { url: `postgresql://${encodeURIComponent(user)}:${encodeURIComponent(pass)}@${host}:${port}/${name}${local ? "" : "?sslmode=require"}`, source: "PGHOST/PGUSER/PGPASSWORD/PGDATABASE", problem: null };
  }
  if (invalid) return { url: null, source: invalid, problem: `${invalid} is set but is not a PostgreSQL URL (it must start with postgresql:// or postgres://). Re-copy the full connection string.` };
  return { url: null, source: null, problem: null };
}

const resolved = resolve();
export const databaseEnvVar: string | null = resolved.url ? resolved.source : null;

/** Names only (never values) of env vars that look database-related, to catch typos like "DATABASE-URL" or "database_url". */
export const similarEnvNames: string[] = Object.keys(process.env)
  .filter((k) => /DATABASE|POSTGRES|^PG|NEON|SUPABASE|DB_?URL/i.test(k))
  .filter((k) => !/^(PGPOOL_MAX)$/.test(k))
  .sort();

/** Identifies WHICH deployment is answering, so separate projects or branches can't be confused. */
export const deploymentInfo = {
  platform: process.env.VERCEL ? "vercel" : process.env.NETLIFY ? "netlify" : process.env.RENDER ? "render" : "server",
  environment: process.env.VERCEL_ENV || process.env.CONTEXT || process.env.NODE_ENV || null,
  url: process.env.VERCEL_URL || process.env.URL || null,
  project: process.env.VERCEL_PROJECT_PRODUCTION_URL || null,
  commit: (process.env.VERCEL_GIT_COMMIT_SHA || process.env.COMMIT_REF || process.env.RENDER_GIT_COMMIT || "").slice(0, 7) || null,
  branch: process.env.VERCEL_GIT_COMMIT_REF || process.env.BRANCH || null,
  repo: process.env.VERCEL_GIT_REPO_SLUG ? `${process.env.VERCEL_GIT_REPO_OWNER}/${process.env.VERCEL_GIT_REPO_SLUG}` : null,
  app: "bpz-fiscal-ledger",
};

export const dbConfigError: string | null = resolved.url
  ? null
  : resolved.problem ||
    (similarEnvNames.length
      ? `No usable connection string. Database-like variables exist on this deployment (${similarEnvNames.join(", ")}) but none matched. Rename yours to exactly DATABASE_URL (all caps, underscore), then redeploy.`
      : `No database connection string found on this deployment${deploymentInfo.environment ? ` (${deploymentInfo.environment} environment)` : ""}. Add DATABASE_URL, then redeploy.`);

const databaseUrl = resolved.url || "postgresql://unconfigured:unconfigured@127.0.0.1:1/unconfigured";

const globalForDb = globalThis as typeof globalThis & { __arenaNextJsPostgresqlPool?: Pool };

const isLocal = /@(127\.0\.0\.1|localhost|db|postgres)(:\d+)?\//.test(databaseUrl);
const needsSsl = !isLocal && (/sslmode=(require|verify|prefer)/.test(databaseUrl) || /neon\.tech|supabase\.(co|com)|render\.com|vercel-storage\.com|amazonaws\.com|azure\.com|aivencloud\.com|railway\.app|prisma\.io/.test(databaseUrl));

export const pool =
  globalForDb.__arenaNextJsPostgresqlPool ??
  new Pool({
    connectionString: databaseUrl,
    max: Number(process.env.PGPOOL_MAX || 3),
    idleTimeoutMillis: 10_000,
    connectionTimeoutMillis: 8_000,
    ssl: needsSsl ? { rejectUnauthorized: false } : undefined,
  });

globalForDb.__arenaNextJsPostgresqlPool = pool;

export const db = drizzle(pool, { schema });