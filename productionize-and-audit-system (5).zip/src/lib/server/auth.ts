import { db } from "@/db";
import { users, sessions, auditLog } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { cookies } from "next/headers";
import { randomBytes, scryptSync, timingSafeEqual, createHash } from "node:crypto";
import { dbGuard } from "@/db/ensure";

export type Role = "SYSTEM_OWNER" | "CONTROLLER" | "ACCOUNTANT" | "AUDITOR";
export const ROLES: Role[] = ["SYSTEM_OWNER", "CONTROLLER", "ACCOUNTANT", "AUDITOR"];
export const POSTING_ROLES: Role[] = ["SYSTEM_OWNER", "CONTROLLER", "ACCOUNTANT"];
export const CONTROL_ROLES: Role[] = ["SYSTEM_OWNER", "CONTROLLER"];

export const COOKIE_NAME = "bpz_session";
const SESSION_HOURS = 12;

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}
export function verifyPassword(password: string, stored: string): boolean {
  const [salt, hash] = stored.split(":");
  if (!salt || !hash) return false;
  const candidate = scryptSync(password, salt, 64);
  const expected = Buffer.from(hash, "hex");
  return candidate.length === expected.length && timingSafeEqual(candidate, expected);
}
const tokenHash = (t: string) => createHash("sha256").update(t).digest("hex");

/** Seed the practice personas once. Owner password may be overridden via ADMIN_PASSWORD. */
export async function ensureSeedUsers() {
  const [{ count }] = await db.select({ count: sql<number>`count(*)::int` }).from(users);
  if (count > 0) return;
  const seed: Array<{ username: string; fullName: string; role: Role; password: string }> = [
    { username: "owner", fullName: "Kwesi Dadzie (System Owner)", role: "SYSTEM_OWNER", password: process.env.ADMIN_PASSWORD || "BpzOwner#2026" },
    { username: "controller", fullName: "Sarah Jenkins (Financial Controller)", role: "CONTROLLER", password: "Control#2026" },
    { username: "accountant", fullName: "Ama Mensah (Senior Accountant)", role: "ACCOUNTANT", password: "Accounts#2026" },
    { username: "auditor", fullName: "Marcus Sterling, CPA (External Audit Partner)", role: "AUDITOR", password: "Audit#2026" },
  ];
  await db.insert(users).values(seed.map((u) => ({ username: u.username, fullName: u.fullName, role: u.role, passwordHash: hashPassword(u.password) })));
}

const MAX_FAILED = 5;
const LOCK_MINUTES = 15;

export async function login(username: string, password: string) {
  await ensureSeedUsers();
  const [user] = await db.select().from(users).where(eq(users.username, username.trim().toLowerCase()));
  if (!user || user.status !== "ACTIVE") {
    return { ok: false as const, error: "Invalid credentials or inactive account." };
  }
  // DB-backed brute-force lockout — survives serverless instance recycling.
  if (user.lockedUntil && user.lockedUntil.getTime() > Date.now()) {
    const mins = Math.ceil((user.lockedUntil.getTime() - Date.now()) / 60000);
    return { ok: false as const, error: `Account locked after ${MAX_FAILED} failed attempts. Try again in ${mins} minute(s) or ask the owner to reset.` };
  }
  if (!verifyPassword(password, user.passwordHash)) {
    const failed = (user.failedAttempts || 0) + 1;
    const lock = failed >= MAX_FAILED;
    await db.update(users).set({ failedAttempts: lock ? 0 : failed, lockedUntil: lock ? new Date(Date.now() + LOCK_MINUTES * 60000) : null }).where(eq(users.id, user.id));
    await db.insert(auditLog).values({ actor: user.username, action: lock ? "ACCOUNT_LOCKED" : "LOGIN_FAILED", detail: lock ? `Locked ${LOCK_MINUTES} min after ${MAX_FAILED} failed attempts` : `Failed sign-in attempt ${failed}/${MAX_FAILED}` });
    return { ok: false as const, error: lock ? `Too many failed attempts — account locked for ${LOCK_MINUTES} minutes.` : "Invalid credentials or inactive account." };
  }
  await db.update(users).set({ failedAttempts: 0, lockedUntil: null }).where(eq(users.id, user.id));
  const token = randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + SESSION_HOURS * 3600 * 1000);
  await db.insert(sessions).values({ tokenHash: tokenHash(token), userId: user.id, expiresAt });
  await db.update(users).set({ lastLogin: new Date() }).where(eq(users.id, user.id));
  await db.insert(auditLog).values({ actor: user.username, action: "LOGIN", detail: `${user.fullName} signed in (${user.role})` });
  const jar = await cookies();
  jar.set(COOKIE_NAME, token, { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", path: "/", maxAge: SESSION_HOURS * 3600 });
  return { ok: true as const, user: publicUser(user) };
}

export async function logout() {
  const jar = await cookies();
  const token = jar.get(COOKIE_NAME)?.value;
  if (token) {
    const s = await currentUser();
    await db.delete(sessions).where(eq(sessions.tokenHash, tokenHash(token)));
    if (s) await db.insert(auditLog).values({ actor: s.username, action: "LOGOUT", detail: `${s.fullName} signed out` });
  }
  jar.delete(COOKIE_NAME);
}

export interface SessionUser { id: number; username: string; fullName: string; role: Role }
export const publicUser = (u: { id: number; username: string; fullName: string; role: string }): SessionUser =>
  ({ id: u.id, username: u.username, fullName: u.fullName, role: u.role as Role });

export async function currentUser(): Promise<SessionUser | null> {
  const jar = await cookies();
  const token = jar.get(COOKIE_NAME)?.value;
  if (!token) return null;
  const [row] = await db
    .select({ id: users.id, username: users.username, fullName: users.fullName, role: users.role, status: users.status, expiresAt: sessions.expiresAt })
    .from(sessions)
    .innerJoin(users, eq(sessions.userId, users.id))
    .where(eq(sessions.tokenHash, tokenHash(token)));
  if (!row || row.status !== "ACTIVE" || row.expiresAt.getTime() < Date.now()) return null;
  return publicUser(row);
}

/** Self-service password change: requires the current password. */
export async function changePassword(userId: number, currentPassword: string, newPassword: string) {
  const [user] = await db.select().from(users).where(eq(users.id, userId));
  if (!user) return { ok: false as const, error: "User not found." };
  if (!verifyPassword(currentPassword, user.passwordHash)) return { ok: false as const, error: "Current password is incorrect." };
  if (newPassword.length < 10 || !/[0-9]/.test(newPassword) || !/[A-Za-z]/.test(newPassword)) {
    return { ok: false as const, error: "New password must be at least 10 characters with letters and numbers." };
  }
  if (verifyPassword(newPassword, user.passwordHash)) return { ok: false as const, error: "New password must differ from the current one." };
  await db.update(users).set({ passwordHash: hashPassword(newPassword) }).where(eq(users.id, user.id));
  await db.insert(auditLog).values({ actor: user.username, action: "PASSWORD_CHANGED", detail: `${user.username} changed their own password` });
  return { ok: true as const };
}

/** Route guard: returns the session user, or a ready-to-return 401/403 Response. */
export async function requireUser(roles?: Role[]): Promise<SessionUser | Response> {
  const blocked = await dbGuard();
  if (blocked) return blocked;
  const user = await currentUser();
  if (!user) return Response.json({ success: false, error: "Authentication required.", code: "UNAUTHENTICATED" }, { status: 401 });
  if (roles && !roles.includes(user.role)) {
    return Response.json({ success: false, error: `Role ${user.role} is not permitted to perform this action (segregation of duties).`, code: "FORBIDDEN" }, { status: 403 });
  }
  return user;
}