import { db } from "@/db";
import { invoices } from "@/db/schema";
import { eq } from "drizzle-orm";
import { computePayrollLine, calcVAT, r2 } from "@/lib/server/ghana-tax";
import { trialBalance } from "@/lib/server/ledger";
import { requireUser } from "@/lib/server/auth";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const auth = await requireUser();
  if (auth instanceof Response) return auth;
  const url = new URL(req.url);
  const cc = url.searchParams.get("companyCode");
  const period = url.searchParams.get("period") || "2026-02";
  if (!cc) return Response.json({ success: false, error: "companyCode required." }, { status: 400 });
  const invs = (await db.select().from(invoices).where(eq(invoices.companyCode, cc))).filter((i) => i.invoiceDate.startsWith(period));
  const sum = (f: (i: (typeof invs)[number]) => number) => r2(invs.reduce((t, i) => t + f(i), 0));
  const ar = invs.filter((i) => i.kind === "AR");
  const ap = invs.filter((i) => i.kind === "AP");
  const lev = (i: (typeof invs)[number]) => Number(i.vatAmount) + Number(i.nhilAmount) + Number(i.getfundAmount);
  const outputVat = sum((i) => i.kind === "AR" ? lev(i) : 0);
  const inputVat = sum((i) => i.kind === "AP" ? lev(i) : 0);
  const standardSales = r2(ar.filter((i) => lev(i) > 0).reduce((t, i) => t + Number(i.netAmount), 0));
  const reliefSales = r2(ar.filter((i) => lev(i) === 0).reduce((t, i) => t + Number(i.netAmount), 0));
  const whtCredits = sum((i) => i.kind === "AR" ? Number(i.whtAmount) : 0);
  const whtPayable = sum((i) => i.kind === "AP" ? Number(i.whtAmount) : 0);
  const vatWithheld = sum((i) => Number(i.vatWithheld));
  const tb = await trialBalance(cc);
  const vatGl = tb.rows.find((r) => r.code === "220000");
  return Response.json({
    success: true, period, regime: "ACT1151",
    standardSales, reliefSales, outputVat, inputVat,
    netPayable: r2(outputVat - inputVat),
    vatGlBalance: vatGl ? r2(-vatGl.balance) : 0,
    whtCredits, whtPayable, vatWithheld,
    invoiceCount: invs.length,
    dueNote: "VAT return + payment due by the last working day of the following month; WHT by the 15th.",
  });
}

export async function POST(req: Request) {
  const auth = await requireUser();
  if (auth instanceof Response) return auth;
  const body = await req.json().catch(() => ({}));
  if (body.action === "PAYROLL") {
    const result = computePayrollLine({
      basic: Number(body.basic || 0), allowances: Number(body.allowances || 0), tier3: Number(body.tier3 || 0),
      casual: !!body.casual, nonResident: !!body.nonResident, ssnitExempt: !!body.ssnitExempt,
    });
    return Response.json({ success: true, result, regime: "Act 1178 (first GH¢588 tax-free)" });
  }
  if (body.action === "VAT") {
    const calc = calcVAT(Number(body.base || 0), body.treatment || "STANDARD");
    return Response.json({ success: true, calc, regime: "Act 1151 — 20% unified, no cascade" });
  }
  return Response.json({ success: false, error: "Unknown tax action." }, { status: 400 });
}